package kr.or.anyid.auth;


import java.io.IOException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.raonsecure.security.exception.CmvpException;

import jakarta.servlet.http.Cookie;
//# 이용기관 WAS가 jakarta 기반
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import kr.or.anyid.adaptor.Sso;
import kr.or.anyid.adaptor.agency.interfaces.SsoLoginCallback;
import kr.or.anyid.adaptor.core.exception.AdaptorErrorCode;
import kr.or.anyid.adaptor.core.exception.AdaptorException;


/**
 * anyid adaptor 로그인시 호출됩니다.
 * 본 클래스(AnyidHandler.class)의 패키지경로는 sso-adaptor-conf-{서버모드}.properties 의 anyid.adaptor.agency.handler에 명시되야합니다.
 * 아래 메소드에 있는 소스들은 예제 소스들입니다.
 * 에제 소스들을 참고해서 이용기관에서 필요한 부분 사용하면 됩니다.
 * {이용기관코딩영역} 확인 필수
 * 
 * onSsoLoginSuccess -> 로그인시 호출되는 메소드
 * onSsoError -> 에러발생시 호출되는 메소드
 */
public class AnyidHandler implements SsoLoginCallback {
    private Sso sso = new Sso();
    
    /**
     * anyid adaptor 로그인시 호출됩니다.
     * 
     * 1. accessToken으로 리소스서버에서 사용자 정보 조회 예제
     * 2. refreshToken으로 accessToken 재발급 예제
     * 3. idToken으로 acrValues, certGroupCd 추출
     *    certGroupCd : 01(모바일) 02(금융) 03(민간인증) 04(민간ID) 05(공동) -> 로그인 인증 수단입니다.
     *    acrValues : 01 = 1, 02,03,05 = 2, 04 = 3 -> 현재 로그인한 사용자의 certGroupCd의 그룹입니다.
     *                acrValues는 이후 다른 로직에도 사용하기에 세션 또는 레디스 와 같이 이용기관 자체적으로 현재 로그인한 사용자별로 보관해야합니다.
     *                
     * 4. 이용기관 자체 로그인 로직 코딩영역 -> 본클래스 or 이용기관 클래스 호출 등 로그인로직 개발하면 됩니다.
     * 
     * 유의사항 : accessToken, refreshToken, acrValues, certGroupCd는
     *          이용기관 상황에 맞춰 저장하여 관리.
     *          위 4가지 값은 사용자 로그아웃 전까지는 유출 될 시 보안 사고로 이어질 수 있으므로,
     *          보관에 유의 할 것
     * 
     * @param accessToken : 리소스서버에서 사용자 정보 조회시 필요
     * @param refreshToken : accessToken 재발급시 필요
     * @param idToken : acrValues, certGroupCd 추출시 필요
     * 
     */
    @Override
    public void onSsoLoginSuccess(HttpServletRequest request,HttpServletResponse response, String accessToken, String refreshToken, String idToken, String endPoint) {
        System.out.println("onSsoLoginSuccess");
        
        //1. accessToken으로 리소스서버에서 사용자 정보 조회 예제
        /*
            개인사용자 user_se_cd = 01
        NI            : Any-ID 식별 값 
        CI            : 사용자 CI 값 
        DN            : 사용자 인증서 DN 값 LIST (복수인 경우가 있음)
        TELNO         : 사용자 연락처 
        LFNR_SE_CD    : 사용자 내/외국인 구분 내국인 : 01 , 외국인 : 02
        PIDK_NO       : 사용자 주민등록번호 
        SEXDSTN_SE_CD : 사용자 성별 남성 : 01 , 여성 : 02
        USER_NM       : 사용자 성명 
        BRDT          : 사용자 생년월일 yyyyMMdd
        */
        
        
        /*
            법인사용자 user_se_cd=02
        NI         : Any-ID 식별 값 
        DN         : 사업자 인증서 DN 값 LIST (복수인 경우가 있음)
        BRNO       : 사업자 등록 번호 
        RPRSV_NM   : 사업자 대표자명 
        OPBIZ_YMD  : 사업자 개업 일자 
        CRNO       : 사업자 법인등록번호 
        BZMN_SE_CD : 사업자 구분 코드 01: 개인사업자, 02: 법인사업자
        */
        Map<String, Object> userInfo = new HashMap<String, Object>();

        try {
            Map<String, Object> resultMap = sso.getUserInfoByAccessToken(accessToken);
            String resultCode = (String)resultMap.get("resultCode");
            System.out.println("getUserInfo resultCode: " + resultCode);
            System.out.println("getUserInfo resultMap: " + resultMap);
            if("0".equals(resultCode)) {
                Map<String, Object> anyidSession = new HashMap<String, Object>();
                anyidSession.put("sso", resultMap.get("userInfo"));
                request.getSession().setAttribute("anyid", anyidSession);
                System.out.println("userInfo 세션 저장 완료: " + resultMap.get("userInfo"));
            }
            Map<String, Object> userInfoMap = (Map<String, Object>) resultMap.get("userInfo");
            // CI 추출 (SDK가 이미 복호화해서 줌)
            String ci = (String) userInfoMap.get("CI");
            System.out.println("CI: " + ci);
        } catch (AdaptorException e) {
            System.out.println(e.getAdaptorErrorCode().getCodeMessage());
            
            if(e.getErrorCode() == -1012 || e.getErrorCode() == -803) {
                //{이용기관코딩영역}
                //accessToken 만료 -> refreshToken으로 accessToken재발급받아서 다시 요청
                //String newAccessToken = sso.refreshAccessToken(request, refreshToken);
            }else {
                //{이용기관코딩영역}
                //재로그인 처리
            }
        } catch (Exception e) {
            System.err.println(e.getLocalizedMessage());
            //{이용기관코딩영역}
            //재로그인 처리
        }
        
        
        //2. refreshToken으로 accessToken 재발급 (필요 시에만 주석 해제)
        /*
        try {
            String newAccessToken = sso.refreshAccessToken(request, refreshToken);
            System.out.println("refreshToken - > New accessToken : " + newAccessToken);
        } catch (AdaptorException e) {
            System.out.println(e.getAdaptorErrorCode().getCodeMessage());
        } catch (Exception e) {
            System.err.println(e.getLocalizedMessage());
        }
        */
        
        
        //3. idToken으로 acrValues, certGroupCd 추출
        Map<String, Object> idTokenPayload = new HashMap<String, Object>();
        
        String acrValues = "";
        String certGroupCd = "";
        String userSeCd = "";
        try {
            idTokenPayload = sso.extractIdTokenPayload(idToken);
            acrValues = (String)idTokenPayload.get("acr_values");
            certGroupCd = (String)idTokenPayload.get("cert_group_cd");
            userSeCd = (String)idTokenPayload.get("user_se_cd"); 
            System.out.println("idTokenPayload : " + idTokenPayload);
        } catch (AdaptorException e) {
            System.out.println(e.getErrorCode());
            //재로그인
        } catch (Exception e) {
            System.err.println(e.getLocalizedMessage());
            //재로그인
        }
        
        //4. 이용기관 자체 로그인 로직 코딩영역 -> 본클래스 or 이용기관 클래스 호출 등 로그인로직 개발하면 됩니다.
        //{이용기관코딩영역}












        
        

        //System.out.println("success endPoint : " + endPoint);
        //로그인후 endPoint로 리다이렉트
        onSsoSendRedirect(response, endPoint);
        //데모용 코드 끝

    }
    
    
    /**
     * anyid adaptor 에러 발생 시 호출됩니다.
     * 에러 발생 시 로그 처리 하고 에러 처리 및 이동할 페이지 코딩하면 됩니다.
     * 
     * @param errorCode : adaptorErrorCode -> adaptor에서 인지 가능한 에러코드, 가이드문서에 명시 되어있습니다.
     *                    Exception -> 기본자바 에러코드. e애서 정보 추출하면 됩니다.
     */
    @Override
    public void onSsoError(HttpServletResponse response, Exception exception) {
        System.out.println("onSsoError");
        String errorMsg = ""; //에러 메세지
        
        if(exception instanceof AdaptorException){
            int adaptorErrorCode = ((AdaptorException) exception).getErrorCode(); 
            errorMsg = AdaptorErrorCode.fromCode(adaptorErrorCode).getCodeMessage();
            //System.out.println(adaptorErrorCode.getCodeMessage());
            
        }else if(exception instanceof CmvpException) {
            errorMsg = exception.getLocalizedMessage();
        }else if(exception instanceof Exception) {
            errorMsg = (String)exception.getMessage();
        }else {
            errorMsg = AdaptorErrorCode.EXCEPTION_FAIL.getCodeMessage();
            //System.out.println(AdaptorErrorCode.EXCEPTION_FAIL);
        }
        //{이용기관코딩영역}
        // 자체 로그 처리
        System.out.println("errorMsg : " + errorMsg);
        
        
        //Cookie cookie = new Cookie("userinfo", null);
        //cookie.setMaxAge(0);
        //response.addCookie(cookie);
        onSsoSendRedirect(response, "/"); 
        return;
    }
    
    
    /**
     * anyid adaptor SsoLogout시 호출됩니다.
     * 이용기관 자체적으로 로그아웃 로직을 연결 or 로직구현 하면 됩니다.
     * 
     */
    @Override
    public void onSsoLogout(HttpServletRequest request) {
        System.out.println("onSsoLogout");
        //아래 session.invalidate();는 예시입니다.
        // 이용기관에 맞게 로그아웃 로직을 연결 or 로직구현 하면 됩니다.
        HttpSession session = request.getSession();
        session.invalidate();
    }

    /**
     * anyid adaptor svc to svc시 호출됩니다.
     * 타 이용기관에서 본 이용기관으로 SSO로그인 + 해당페이지 접근 하기 위한 기능입니다.
     * 
     * validation 순서
     * 1. 넘겨받은 endPoint가 본 이용기관이 관리하는 endPoint인지 체크
     *    - 관리하는 endPoint가 아니면 이용기관 자체 예외처리
     * 2. 넘겨받은 endPoint의 acrValues(CheckCcrValues) 요구치와 로그인한 사용자의 acrValues(sessionAcrValues) 비교
     *    - CheckCcrValues >= sessionAcrValues : 페이지 이동
     *    - CheckCcrValues < sessionAcrValues : 재인증 이동
     * 
     * 이용기관에서 수정 할 영역은 {이용기관코딩영역} Start ~ {이용기관코딩영역} End 입니다.
     * 이용기관 상황에 맞게 관리할 endPoint와 acrValues를 맵핑시켜놓고 CheckCcrValues, sessionAcrValues에 세팅만 하면 됩니다.
     * 
     * @param endPoint : 최종 도착지의 contextpath
     *        ReAuthLevelUrl : 
     */
    @Override
    public void onSsoSvcToSvc(HttpServletRequest request, HttpServletResponse response, String endPoint) {
        
        //sessionAcrValues = 로그인한 사용자의 acrValues 값 세팅
        
        
        
        
        //{이용기관코딩영역} End
        int result = acrValuesCheck(request, endPoint);
        if(result == 0) {
            //endPointCheck true, acrValuesCheck true -> endPoint로 Redirect
            onSsoSendRedirect(response, endPoint);
        }else if(result == 1){
            //endPointCheck true, acrValuesCheck false -> endPoint로 Redirect
            //인증레벨 변경 필요함, 재로그인 이동
          //{이용기관코딩영역} Start
            //이동하려는 화면의 acrValues 세팅
            String acrValues = ""; 
          //{이용기관코딩영역} End
            onSsoSendRedirect(response, sso.getReAuthLevelUri(endPoint, acrValues));
        }else {
            //{이용기관코딩영역} Start
            //화이트리스트에 포함되지 않은 endPoint, 이용기관 자체 예외처리 
            //{이용기관코딩영역} End
        }
    }
    @Override
    public void onSsoSendRedirect(HttpServletResponse response, String endPoint) {
        String redirectUrl = endPoint.replaceAll("[\\r\\n]", "");

        try {
            if(endPointCheck(redirectUrl)) {
                //endPointCheck true, acrValuesCheck true -> endPoint로 Redirect
                if (!response.isCommitted()) {
                    response.sendRedirect(redirectUrl);
                }
            }else{
                //{이용기관코딩영역} Start
                //화이트리스트에 포함되지 않은 endPoint, 이용기관 자체 예외처리 
                //{이용기관코딩영역} End
            }
            
        } catch (IllegalStateException e) {
            System.err.println("Failed to send redirect. Response might already be committed. Called by: " + e);
        } catch (IOException e) {
            System.err.println("Failed to send redirect due to an I/O error. Called by: " + e);
        }
    }
    /**
     * endPoint 검증시 사용될 메소드입니다.
     * 이용기관자체적으로 endPoint 화이트 리스트를 관리하면 됩니다.
     * 아래 구현방법은 자유롭게 하시면 되고 @param endPoint 와 검증 하는 로직 구현 하시면 됩니다.
     * 만약 endPoint에 endPoint?ddd=ddd 와 같이 파라미터가 붙은 경우 알아서 비교로직 만들면 됩니다.
     * @param endPoint : 최종 도착지의 contextpath
     */
    public boolean endPointCheck(String endPoint) {
        String contextPath = getContextPath(endPoint);
        //{이용기관코딩영역} Start
        //이용기관에서 관리하는 자체 endPoint url과 인증 레벨을 아래와 같이 HashMap<String, Integer>()에 세팅
        Map<String, Integer> endPointCheck = new HashMap<String, Integer>();
        endPointCheck.put("/login", 3);
        endPointCheck.put("/index2.jsp", 1);
        endPointCheck.put("/index3.jsp", 2);
        endPointCheck.put("/", 3);
        //{이용기관코딩영역} End
       return true;
        /*
        if(endPointCheck.containsKey(contextPath)) {
            return true;
        }
        return false;
        */
    }
    /**
     * endPoint의 acrValues 와 사용자의 sessionAcrValues 검증시 사용될 메소드입니다.
     * 이용기관자체적으로 endPoint와 acrValues를  화이트 리스트로 관리하면 됩니다.
     * 아래 구현방법은 자유롭게 하시면 되고 @param endPoint 와 로그인한 사용자의 acrValues 검증 하는 로직 구현 하시면 됩니다.
     * endPointCheck 이후 acrValues 아래와 같은 결과를 리턴하면 됩니다.
     *    0 : [정상]이동하려는 화면의 acrValues 보다 로그인한 사용자의 acrValues가 높아서 화면 이동가능
     *    1 : [재인증필요]이동하려는 화면의 acrValues 보다 로그인한 사용자의 acrValues가 높아서 화면 이동가능 불가능
     *        상위 인증수단을 통해 재로그인 필요함 -> 재로그인 페이지로 이동
     *  999 : [등록 필요 or 검증]화이트리스트에 endPoint 없어서 화면 이동 불가능
     * @param endPoint : 최종 도착지의 contextpath
     * @param sessionAcrValues : 현재 로그인한 사용자의 acrValues
     */
    public int acrValuesCheck(HttpServletRequest request, String endPoint) {
        String contextPath = getContextPath(endPoint);
        //{이용기관코딩영역} Start
        //이용기관에서 관리하는 자체 endPoint url과 인증 레벨을 세팅. 아래는 자유롭게 구현 가능하며 아래의 로직에 부합되게끔 커스텀 가능
        Map<String, Integer> endPointCheck = new HashMap<String, Integer>();
        endPointCheck.put("/login", 3);
        endPointCheck.put("/index2.jsp", 1); 
        endPointCheck.put("/index3.jsp", 2);
        endPointCheck.put("/", 3);
        
        HttpSession session = request.getSession();
        int sessionAcrValues = Integer.parseInt((String)session.getAttribute("acrValues"));
        
        
        if(endPointCheck(contextPath)) {
            int CheckAcrValues = endPointCheck.get(contextPath);
            if(CheckAcrValues >= sessionAcrValues){
                //이동하려는 화면의 acrValues 보다 로그인한 사용자의 acrValues가 높아서 화면 이동가능
                return 0;
                
            }else {
                //이동하려는 화면의 acrValues 보다 로그인한 사용자의 acrValues가 높아서 화면 이동가능 불가능
                //상위 인증수단을 통해 재로그인 필요함 -> 재로그인 페이지로 이동
                return 1;
            }
        }else {
            //화이트리스트에 endPoint 없어서 화면 이동 불가능
            return 999;
        }
        
    }
    

  //{이용기관코딩영역} End
    public static String getContextPath(String url) {
        try {
            if (url.startsWith("http://") || url.startsWith("https://")) {
                URL parsedUrl = new URL(url);
                return parsedUrl.getPath();
            } else {
                int paramIndex = url.indexOf("?");
                return paramIndex > -1 ? url.substring(0, paramIndex) : url;
            }
        } catch (Exception e) {
            System.err.println(e.getLocalizedMessage());
            return null;
        }
    }
}

