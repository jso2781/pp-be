INSERT INTO kids_own.tb_pp_m_bbs (bbs_id,bbs_nm,bbs_atrb_cd,bbs_expln,bbs_smry_cn,cmnt_use_yn,inq_cnt_expsr_yn,dept_expsr_yn,file_atch_yn,atch_psblty_file_cnt,lang_se_cd,use_yn,rgtr_id,reg_dt,mdfr_id,mdfcn_dt) VALUES
	 ('1','테스트 게시판','GNR','테스트입니다','게시판 요약','Y','Y','Y','Y',10,'KOR','Y','admin','2026-02-03 18:21:58.685','admin','2026-02-03 18:21:58.685');
