INSERT INTO kids_own.tb_pp_d_menu (menu_sn,menu_url_addr,menu_npag_nm,prvc_incl_yn,dgstfn_exmn_yn,menu_expsr_yn,dept_info_expsr_yn,pic_info_expsr_yn,mobl_aplcn_yn,lgn_yn,encpt_pic_telno,menu_kogl_cprgt_type_cd,menu_pic_id,menu_tkcg_dept_no,rgtr_id,reg_dt,mdfr_id,mdfcn_dt) VALUES
	 (7,'https://nedrug.mfds.go.kr/CCCBA03F010/getReport',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157'),
	 (8,'https://nedrug.mfds.go.kr/CCCBA03F010/getReportQuasiDrug',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157'),
	 (9,'/maintask/adverse/AdverseOffline',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157'),
	 (10,'/maintask/adverse/AdverseDataRoom',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157'),
	 (13,'/maintask/sideeffects/Report1',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157'),
	 (20,'/maintask/linkage/analysis1',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157'),
	 (21,'https://open.drugsafe.or.kr/analyze/opendatab/List.jsp',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157'),
	 (24,'/maintask/dur/DurSearchRoom',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157'),
	 (25,'/maintask/dur/MyDrugInfo',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157'),
	 (26,'/maintask/dur/ApprUseBook',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157');
INSERT INTO kids_own.tb_pp_d_menu (menu_sn,menu_url_addr,menu_npag_nm,prvc_incl_yn,dgstfn_exmn_yn,menu_expsr_yn,dept_info_expsr_yn,pic_info_expsr_yn,mobl_aplcn_yn,lgn_yn,encpt_pic_telno,menu_kogl_cprgt_type_cd,menu_pic_id,menu_tkcg_dept_no,rgtr_id,reg_dt,mdfr_id,mdfcn_dt) VALUES
	 (28,'/maintask/dur/DurProposal',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157'),
	 (30,'/maintask/relief/ReliefIntro',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157'),
	 (31,'/maintask/relief/ReliefApply',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157'),
	 (32,'/maintask/relief/ReliefNews',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157'),
	 (33,'https://nedrug.mfds.go.kr',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157'),
	 (39,'https://open.go.kr',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157'),
	 (41,'/open/open/BizExpsDetails',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157'),
	 (44,'/open/disclosure/CorruptionStatus',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157'),
	 (51,'/news/NewsFaqNotice',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157'),
	 (55,'/news/NewsLeaflet',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157');
INSERT INTO kids_own.tb_pp_d_menu (menu_sn,menu_url_addr,menu_npag_nm,prvc_incl_yn,dgstfn_exmn_yn,menu_expsr_yn,dept_info_expsr_yn,pic_info_expsr_yn,mobl_aplcn_yn,lgn_yn,encpt_pic_telno,menu_kogl_cprgt_type_cd,menu_pic_id,menu_tkcg_dept_no,rgtr_id,reg_dt,mdfr_id,mdfcn_dt) VALUES
	 (71,'/about/ethics/AboutCleanCenter',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157'),
	 (72,'/about/ethics/AboutCleanForm',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157'),
	 (4,'/cms/CmsPage/cms0002',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157'),
	 (49,'/board/general/',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','admin','2026-02-04 16:12:46.122902'),
	 (53,'/board/general/',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','admin','2026-02-04 16:12:46.129278'),
	 (52,'/cms/CmsPage/',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','admin','2026-02-04 16:12:46.143014'),
	 (57,'/board/video/',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','admin','2026-02-04 16:12:46.170454'),
	 (38,'/cms/CmsPage/',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','admin','2026-02-04 16:12:46.177074'),
	 (58,'/board/general/BBS_COM_005',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157'),
	 (70,'/cms/CmsPage/',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','admin','2026-02-04 16:12:46.285577');
INSERT INTO kids_own.tb_pp_d_menu (menu_sn,menu_url_addr,menu_npag_nm,prvc_incl_yn,dgstfn_exmn_yn,menu_expsr_yn,dept_info_expsr_yn,pic_info_expsr_yn,mobl_aplcn_yn,lgn_yn,encpt_pic_telno,menu_kogl_cprgt_type_cd,menu_pic_id,menu_tkcg_dept_no,rgtr_id,reg_dt,mdfr_id,mdfcn_dt) VALUES
	 (5,'/cms/CmsPage/',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','admin','2026-02-04 16:06:55.765184'),
	 (11,'/board/general/',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','admin','2026-02-04 16:10:21.620857'),
	 (14,'https://open.drugsafe.or.kr/original/guidelines/List.jsp',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','admin','2026-02-04 16:12:46.084206'),
	 (16,'/cms/CmsPage/',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','admin','2026-02-04 16:12:46.090792'),
	 (17,'/cms/CmsPage/',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','admin','2026-02-04 16:12:46.097357'),
	 (18,'/cms/CmsPage/',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','admin','2026-02-04 16:12:46.10422'),
	 (27,'/board/general/',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','admin','2026-02-04 16:12:46.116125'),
	 (50,'/board/general/',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','admin','2026-02-04 16:12:46.135865'),
	 (54,'/board/general/',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','admin','2026-02-04 16:12:46.150127'),
	 (56,'/board/gallery/',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','admin','2026-02-04 16:12:46.163594');
INSERT INTO kids_own.tb_pp_d_menu (menu_sn,menu_url_addr,menu_npag_nm,prvc_incl_yn,dgstfn_exmn_yn,menu_expsr_yn,dept_info_expsr_yn,pic_info_expsr_yn,mobl_aplcn_yn,lgn_yn,encpt_pic_telno,menu_kogl_cprgt_type_cd,menu_pic_id,menu_tkcg_dept_no,rgtr_id,reg_dt,mdfr_id,mdfcn_dt) VALUES
	 (40,'/board/general/',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','admin','2026-02-04 16:12:46.191082'),
	 (42,'/cms/CmsPage/',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','admin','2026-02-04 16:12:46.197992'),
	 (47,'/board/general/',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','admin','2026-02-04 16:12:46.211666'),
	 (60,'/cms/CmsPage/',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','admin','2026-02-04 16:12:46.218822'),
	 (61,'/cms/CmsPage/',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','admin','2026-02-04 16:12:46.225411'),
	 (62,'/cms/CmsPage/',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','admin','2026-02-04 16:12:46.231974'),
	 (63,'/cms/CmsPage/',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','admin','2026-02-04 16:12:46.238863'),
	 (64,'/cms/CmsPage/',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','admin','2026-02-04 16:12:46.245983'),
	 (65,'/cms/CmsPage/',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','admin','2026-02-04 16:12:46.252829'),
	 (66,'/cms/CmsPage/',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','admin','2026-02-04 16:12:46.259435');
INSERT INTO kids_own.tb_pp_d_menu (menu_sn,menu_url_addr,menu_npag_nm,prvc_incl_yn,dgstfn_exmn_yn,menu_expsr_yn,dept_info_expsr_yn,pic_info_expsr_yn,mobl_aplcn_yn,lgn_yn,encpt_pic_telno,menu_kogl_cprgt_type_cd,menu_pic_id,menu_tkcg_dept_no,rgtr_id,reg_dt,mdfr_id,mdfcn_dt) VALUES
	 (67,'/board/general/',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','admin','2026-02-04 16:12:46.266743'),
	 (68,'/cms/CmsPage/',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','admin','2026-02-04 16:12:46.273402'),
	 (23,'/cms/CmsPage/cms0001',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','admin','2026-02-04 15:50:35.011404'),
	 (73,'/cms/CmsPage/',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','admin','2026-02-04 16:12:46.280265'),
	 (74,'/cms/CmsPage/',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','admin','2026-02-04 16:12:46.292483');
