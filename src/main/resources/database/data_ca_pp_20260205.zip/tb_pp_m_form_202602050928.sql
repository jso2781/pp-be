INSERT INTO kids_own.tb_pp_m_form (form_sn,task_cd,form_nm,form_path_nm,use_yn,rgtr_id,reg_dt,mdfr_id,mdfcn_dt) VALUES
	 (3,'MBR','테스트 템플릿 1',NULL,'Y','','2026-02-03 17:53:50.86157','','2026-02-03 17:53:50.86157'),
	 (4,'SMS','테스트 템플릿 2',NULL,'Y','','2026-02-03 17:55:45.981254','','2026-02-03 17:55:45.981254');
