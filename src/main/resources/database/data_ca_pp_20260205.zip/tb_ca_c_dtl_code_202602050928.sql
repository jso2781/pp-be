INSERT INTO kids_own.tb_ca_c_dtl_code (com_dtl_cd,com_group_cd,com_dtl_cd_nm,dgt,sort_seq,rsvt_cn_1,rsvt_cn_2,rsvt_cn_3,rsvt_cn_4,rsvt_cn_5,rsvt_cn_6,rsvt_cn_7,rsvt_cn_8,rsvt_cn_9,rsvt_cn_10,use_yn,reg_dt,rgtr_id,mdfcn_dt,mdfr_id) VALUES
	 ('G','PP000001','일반회원',1,1,'','','','','','','','','','','Y','2026-02-02 19:13:01.392709','admin','2026-02-02 19:13:01.392709','admin'),
	 ('Y','PP000001','14세미만회원',1,2,'','','','','','','','','','','Y','2026-02-02 19:13:01.392709','admin','2026-02-02 19:13:01.392709','admin'),
	 ('E','PP000001','전문가회원',1,3,'','','','','','','','','','','Y','2026-02-02 19:13:01.392709','admin','2026-02-02 19:13:01.392709','admin'),
	 ('N','PP000002','정상',1,1,'','','','','','','','','','','Y','2026-02-02 19:13:01.392709','admin','2026-02-02 19:13:01.392709','admin'),
	 ('W','PP000002','탈회',1,2,'','','','','','','','','','','Y','2026-02-02 19:13:01.392709','admin','2026-02-02 19:13:01.392709','admin'),
	 ('1','PP000003','재직',1,1,'','','','','','','','','','','Y','2026-02-02 19:13:01.392709','admin','2026-02-02 19:13:01.392709','admin'),
	 ('2','PP000003','휴직',1,2,'','','','','','','','','','','Y','2026-02-02 19:13:01.392709','admin','2026-02-02 19:13:01.392709','admin'),
	 ('3','PP000003','퇴직',1,3,'','','','','','','','','','','Y','2026-02-02 19:13:01.392709','admin','2026-02-02 19:13:01.392709','admin'),
	 ('W','PP000004','대기',1,1,'','','','','','','','','','','Y','2026-02-02 19:13:01.392709','admin','2026-02-02 19:13:01.392709','admin'),
	 ('A','PP000004','승인',1,2,'','','','','','','','','','','Y','2026-02-02 19:13:01.392709','admin','2026-02-02 19:13:01.392709','admin');
INSERT INTO kids_own.tb_ca_c_dtl_code (com_dtl_cd,com_group_cd,com_dtl_cd_nm,dgt,sort_seq,rsvt_cn_1,rsvt_cn_2,rsvt_cn_3,rsvt_cn_4,rsvt_cn_5,rsvt_cn_6,rsvt_cn_7,rsvt_cn_8,rsvt_cn_9,rsvt_cn_10,use_yn,reg_dt,rgtr_id,mdfcn_dt,mdfr_id) VALUES
	 ('R','PP000004','반려',1,3,'','','','','','','','','','','Y','2026-02-02 19:13:01.392709','admin','2026-02-02 19:13:01.392709','admin'),
	 ('C','PP000004','회수',1,4,'','','','','','','','','','','Y','2026-02-02 19:13:01.392709','admin','2026-02-02 19:13:01.392709','admin'),
	 ('R','PP000005','접수',1,1,'','','','','','','','','','','Y','2026-02-02 19:13:01.392709','admin','2026-02-02 19:13:01.392709','admin'),
	 ('P','PP000005','처리중',1,2,'','','','','','','','','','','Y','2026-02-02 19:13:01.392709','admin','2026-02-02 19:13:01.392709','admin'),
	 ('C','PP000005','완료',1,3,'','','','','','','','','','','Y','2026-02-02 19:13:01.392709','admin','2026-02-02 19:13:01.392709','admin'),
	 ('M','PP000006','관리자',1,1,'','','','','','','','','','','Y','2026-02-02 19:13:01.392709','admin','2026-02-02 19:13:01.392709','admin'),
	 ('E','PP000006','전문가',1,2,'','','','','','','','','','','Y','2026-02-02 19:13:01.392709','admin','2026-02-02 19:13:01.392709','admin'),
	 ('U','PP000006','사용자',1,3,'','','','','','','','','','','Y','2026-02-02 19:13:01.392709','admin','2026-02-02 19:13:01.392709','admin'),
	 ('KOR','PP000007','한글',3,1,'','','','','','','','','','','Y','2026-02-02 19:13:01.392709','admin','2026-02-02 19:13:01.392709','admin'),
	 ('ENG','PP000007','영어',3,2,'','','','','','','','','','','Y','2026-02-02 19:13:01.392709','admin','2026-02-02 19:13:01.392709','admin');
INSERT INTO kids_own.tb_ca_c_dtl_code (com_dtl_cd,com_group_cd,com_dtl_cd_nm,dgt,sort_seq,rsvt_cn_1,rsvt_cn_2,rsvt_cn_3,rsvt_cn_4,rsvt_cn_5,rsvt_cn_6,rsvt_cn_7,rsvt_cn_8,rsvt_cn_9,rsvt_cn_10,use_yn,reg_dt,rgtr_id,mdfcn_dt,mdfr_id) VALUES
	 ('1','PP000008','제1유형',1,1,'','','','','','','','','','','Y','2026-02-02 19:13:01.392709','admin','2026-02-02 19:13:01.392709','admin'),
	 ('2','PP000008','제2유형',1,2,'','','','','','','','','','','Y','2026-02-02 19:13:01.392709','admin','2026-02-02 19:13:01.392709','admin'),
	 ('3','PP000008','제3유형',1,3,'','','','','','','','','','','Y','2026-02-02 19:13:01.392709','admin','2026-02-02 19:13:01.392709','admin'),
	 ('4','PP000008','제4유형',1,4,'','','','','','','','','','','Y','2026-02-02 19:13:01.392709','admin','2026-02-02 19:13:01.392709','admin'),
	 ('GNR','PP000009','일반',3,1,'','','','','','','','','','','Y','2026-02-02 19:13:01.392709','admin','2026-02-02 19:13:01.392709','admin'),
	 ('GLY','PP000009','갤러리',3,2,'','','','','','','','','','','Y','2026-02-02 19:13:01.392709','admin','2026-02-02 19:13:01.392709','admin'),
	 ('VDO','PP000009','동영상',3,3,'','','','','','','','','','','Y','2026-02-02 19:13:01.392709','admin','2026-02-02 19:13:01.392709','admin'),
	 ('O','PP000011','운영',1,1,'','','','','','','','','','','Y','2026-02-02 19:13:01.392709','admin','2026-02-02 19:13:01.392709','admin'),
	 ('W','PP000011','대기',1,2,'','','','','','','','','','','Y','2026-02-02 19:13:01.392709','admin','2026-02-02 19:13:01.392709','admin'),
	 ('E','PP000011','오류',1,3,'','','','','','','','','','','Y','2026-02-02 19:13:01.392709','admin','2026-02-02 19:13:01.392709','admin');
INSERT INTO kids_own.tb_ca_c_dtl_code (com_dtl_cd,com_group_cd,com_dtl_cd_nm,dgt,sort_seq,rsvt_cn_1,rsvt_cn_2,rsvt_cn_3,rsvt_cn_4,rsvt_cn_5,rsvt_cn_6,rsvt_cn_7,rsvt_cn_8,rsvt_cn_9,rsvt_cn_10,use_yn,reg_dt,rgtr_id,mdfcn_dt,mdfr_id) VALUES
	 ('1','PP000010','부',1,1,'','','','','','','','','','','Y','2026-02-02 19:13:01.392709','admin','2026-02-02 19:13:01.392709','admin'),
	 ('2','PP000010','모',1,2,'','','','','','','','','','','Y','2026-02-02 19:13:01.392709','admin','2026-02-02 19:13:01.392709','admin'),
	 ('3','PP000010','형제자매',1,3,'','','','','','','','','','','Y','2026-02-02 19:13:01.392709','admin','2026-02-02 19:13:01.392709','admin'),
	 ('4','PP000010','조부(외조부)',1,4,'','','','','','','','','','','Y','2026-02-02 19:13:01.392709','admin','2026-02-02 19:13:01.392709','admin'),
	 ('5','PP000010','조모(외조모)',1,5,'','','','','','','','','','','Y','2026-02-02 19:13:01.392709','admin','2026-02-02 19:13:01.392709','admin'),
	 ('6','PP000010','친척',1,6,'','','','','','','','','','','Y','2026-02-02 19:13:01.392709','admin','2026-02-02 19:13:01.392709','admin'),
	 ('PP','PP000012','대국민서비스포털',2,1,'','','','','','','','','','','Y','2026-02-02 19:13:01.392709','admin','2026-02-02 19:13:01.392709','admin'),
	 ('BO','PP000012','안전정보업무',2,2,'','','','','','','','','','','Y','2026-02-02 19:13:01.392709','admin','2026-02-02 19:13:01.392709','admin'),
	 ('CR','PP000012','부작용포털(eCRF)',2,3,'','','','','','','','','','','Y','2026-02-02 19:13:01.392709','admin','2026-02-02 19:13:01.392709','admin'),
	 ('CM','PP000012','통합분석시스템(CDM)',2,4,'','','','','','','','','','','Y','2026-02-02 19:13:01.392709','admin','2026-02-02 19:13:01.392709','admin');
INSERT INTO kids_own.tb_ca_c_dtl_code (com_dtl_cd,com_group_cd,com_dtl_cd_nm,dgt,sort_seq,rsvt_cn_1,rsvt_cn_2,rsvt_cn_3,rsvt_cn_4,rsvt_cn_5,rsvt_cn_6,rsvt_cn_7,rsvt_cn_8,rsvt_cn_9,rsvt_cn_10,use_yn,reg_dt,rgtr_id,mdfcn_dt,mdfr_id) VALUES
	 ('EX','PP000012','전문가관리',2,5,'','','','','','','','','','','Y','2026-02-02 19:13:01.392709','admin','2026-02-02 19:13:01.392709','admin'),
	 ('DR','PP000012','전자문서고',2,6,'','','','','','','','','','','Y','2026-02-02 19:13:01.392709','admin','2026-02-02 19:13:01.392709','admin'),
	 ('SV','PP000012','설문',2,7,'','','','','','','','','','','Y','2026-02-02 19:13:01.392709','admin','2026-02-02 19:13:01.392709','admin'),
	 ('ED','PP000012','교육플랫폼',2,8,'','','','','','','','','','','Y','2026-02-02 19:13:01.392709','admin','2026-02-02 19:13:01.392709','admin'),
	 ('CC','PP000012','통합상담',2,9,'','','','','','','','','','','Y','2026-02-02 19:13:01.392709','admin','2026-02-02 19:13:01.392709','admin'),
	 ('CR','PP000013','부작용포털(eCRF)',2,1,'','','','','','','','','','','Y','2026-02-02 19:13:01.392709','admin','2026-02-02 19:13:01.392709','admin'),
	 ('CM','PP000013','통합분석시스템(CDM)',2,2,'','','','','','','','','','','Y','2026-02-02 19:13:01.392709','admin','2026-02-02 19:13:01.392709','admin'),
	 ('A','PP000014','추가',1,1,'','','','','','','','','','','Y','2026-02-02 19:13:01.392709','admin','2026-02-02 19:13:01.392709','admin'),
	 ('C','PP000014','변경',1,2,'','','','','','','','','','','Y','2026-02-02 19:13:01.392709','admin','2026-02-02 19:13:01.392709','admin'),
	 ('D','PP000014','삭제',1,3,'','','','','','','','','','','Y','2026-02-02 19:13:01.392709','admin','2026-02-02 19:13:01.392709','admin');
INSERT INTO kids_own.tb_ca_c_dtl_code (com_dtl_cd,com_group_cd,com_dtl_cd_nm,dgt,sort_seq,rsvt_cn_1,rsvt_cn_2,rsvt_cn_3,rsvt_cn_4,rsvt_cn_5,rsvt_cn_6,rsvt_cn_7,rsvt_cn_8,rsvt_cn_9,rsvt_cn_10,use_yn,reg_dt,rgtr_id,mdfcn_dt,mdfr_id) VALUES
	 ('ADEF_DEFN','PP000015','의약품부작용 정의',9,1,'','','','','','','','','','','Y','2026-02-02 19:13:01.392709','admin','2026-02-02 19:13:01.392709','admin'),
	 ('ADEF_DCLR','PP000015','의약품부작용 신고방법',9,2,'','','','','','','','','','','Y','2026-02-02 19:13:01.392709','admin','2026-02-02 19:13:01.392709','admin'),
	 ('DOC','PP000016','의사',3,1,'','','','','','','','','','','Y','2026-02-02 19:13:01.392709','admin','2026-02-02 19:13:01.392709','admin'),
	 ('NRS','PP000016','간호사',3,2,'','','','','','','','','','','Y','2026-02-02 19:13:01.392709','admin','2026-02-02 19:13:01.392709','admin'),
	 ('PHA','PP000016','약사',3,3,'','','','','','','','','','','Y','2026-02-02 19:13:01.392709','admin','2026-02-02 19:13:01.392709','admin'),
	 ('CNS','PP000016','소비자',3,4,'','','','','','','','','','','Y','2026-02-02 19:13:01.392709','admin','2026-02-02 19:13:01.392709','admin'),
	 ('ETC','PP000016','기타',3,5,'','','','','','','','','','','Y','2026-02-02 19:13:01.392709','admin','2026-02-02 19:13:01.392709','admin'),
	 ('1','PP000017','급여',1,1,'','','','','','','','','','','Y','2026-02-02 19:13:01.392709','admin','2026-02-02 19:13:01.392709','admin'),
	 ('2','PP000017','비급여',1,2,'','','','','','','','','','','Y','2026-02-02 19:13:01.392709','admin','2026-02-02 19:13:01.392709','admin'),
	 ('02','EX0002','해촉',NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-01-27 08:45:30.8584','exdev01','2026-01-27 08:45:30.8584','exdev01');
INSERT INTO kids_own.tb_ca_c_dtl_code (com_dtl_cd,com_group_cd,com_dtl_cd_nm,dgt,sort_seq,rsvt_cn_1,rsvt_cn_2,rsvt_cn_3,rsvt_cn_4,rsvt_cn_5,rsvt_cn_6,rsvt_cn_7,rsvt_cn_8,rsvt_cn_9,rsvt_cn_10,use_yn,reg_dt,rgtr_id,mdfcn_dt,mdfr_id) VALUES
	 ('03','EX0002','면직',NULL,3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-01-27 08:45:30.8584','exdev01','2026-01-27 08:45:30.8584','exdev01'),
	 ('04','EX0002','예비',NULL,4,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-01-27 08:45:30.8584','exdev01','2026-01-27 08:45:30.8584','exdev01'),
	 ('01','EX0003','서울시',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-01-27 08:45:30.8584','exdev01','2026-01-27 08:45:30.8584','exdev01'),
	 ('02','EX0003','경기도',NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-01-27 08:45:30.8584','exdev01','2026-01-27 08:45:30.8584','exdev01'),
	 ('03','EX0003','인천시',NULL,3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-01-27 08:45:30.8584','exdev01','2026-01-27 08:45:30.8584','exdev01'),
	 ('04','EX0003','부산시',NULL,4,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-01-27 08:45:30.8584','exdev01','2026-01-27 08:45:30.8584','exdev01'),
	 ('05','EX0003','대구시',NULL,5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-01-27 08:45:30.8584','exdev01','2026-01-27 08:45:30.8584','exdev01'),
	 ('06','EX0003','광주시',NULL,6,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-01-27 08:45:30.8584','exdev01','2026-01-27 08:45:30.8584','exdev01'),
	 ('07','EX0003','대전시',NULL,7,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-01-27 08:45:30.8584','exdev01','2026-01-27 08:45:30.8584','exdev01'),
	 ('01','EX0007','온라인',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-01-27 08:45:30.8584','exdev01','2026-01-27 08:45:30.8584','exdev01');
INSERT INTO kids_own.tb_ca_c_dtl_code (com_dtl_cd,com_group_cd,com_dtl_cd_nm,dgt,sort_seq,rsvt_cn_1,rsvt_cn_2,rsvt_cn_3,rsvt_cn_4,rsvt_cn_5,rsvt_cn_6,rsvt_cn_7,rsvt_cn_8,rsvt_cn_9,rsvt_cn_10,use_yn,reg_dt,rgtr_id,mdfcn_dt,mdfr_id) VALUES
	 ('02','EX0007','오프라인',NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-01-27 08:45:30.8584','exdev01','2026-01-27 08:45:30.8584','exdev01'),
	 ('01','EX0008','일반',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-01-27 08:45:30.8584','exdev01','2026-01-27 08:45:30.8584','exdev01'),
	 ('02','EX0008','부연설명',NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-01-27 08:45:30.8584','exdev01','2026-01-27 08:45:30.8584','exdev01'),
	 ('03','EX0008','선택조건',NULL,3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-01-27 08:45:30.8584','exdev01','2026-01-27 08:45:30.8584','exdev01'),
	 ('01','EX0009','단일',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-01-27 08:45:30.8584','exdev01','2026-01-27 08:45:30.8584','exdev01'),
	 ('02','EX0009','다건',NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-01-27 08:45:30.8584','exdev01','2026-01-27 08:45:30.8584','exdev01'),
	 ('01','EX0010','대기',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-01-27 08:45:30.8584','exdev01','2026-01-27 08:45:30.8584','exdev01'),
	 ('02','EX0010','발송중',NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-01-27 08:45:30.8584','exdev01','2026-01-27 08:45:30.8584','exdev01'),
	 ('03','EX0010','성공',NULL,3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-01-27 08:45:30.8584','exdev01','2026-01-27 08:45:30.8584','exdev01'),
	 ('04','EX0010','실패',NULL,4,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-01-27 08:45:30.8584','exdev01','2026-01-27 08:45:30.8584','exdev01');
INSERT INTO kids_own.tb_ca_c_dtl_code (com_dtl_cd,com_group_cd,com_dtl_cd_nm,dgt,sort_seq,rsvt_cn_1,rsvt_cn_2,rsvt_cn_3,rsvt_cn_4,rsvt_cn_5,rsvt_cn_6,rsvt_cn_7,rsvt_cn_8,rsvt_cn_9,rsvt_cn_10,use_yn,reg_dt,rgtr_id,mdfcn_dt,mdfr_id) VALUES
	 ('01','EX0011','자문요청완료',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-01-27 08:45:30.8584','exdev01','2026-01-27 08:45:30.8584','exdev01'),
	 ('02','EX0011','작성',NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-01-27 08:45:30.8584','exdev01','2026-01-27 08:45:30.8584','exdev01'),
	 ('01','EX0001','남',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-01-27 08:45:30.8584','exdev01','2026-01-27 08:45:30.8584','exdev01'),
	 ('08','EX0003','울산시',NULL,8,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-01-27 08:45:30.8584','exdev01','2026-01-27 08:45:30.8584','exdev01'),
	 ('09','EX0003','세종시',NULL,9,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-01-27 08:45:30.8584','exdev01','2026-01-27 08:45:30.8584','exdev01'),
	 ('10','EX0003','강원도',NULL,10,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-01-27 08:45:30.8584','exdev01','2026-01-27 08:45:30.8584','exdev01'),
	 ('03','EX0011','제출',NULL,3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-01-27 08:45:30.8584','exdev01','2026-01-27 08:45:30.8584','exdev01'),
	 ('04','EX0011','완료',NULL,4,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-01-27 08:45:30.8584','exdev01','2026-01-27 08:45:30.8584','exdev01'),
	 ('11','EX0003','충청북도',NULL,11,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-01-27 08:45:30.8584','exdev01','2026-01-27 08:45:30.8584','exdev01'),
	 ('12','EX0003','충청남도',NULL,12,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-01-27 08:45:30.8584','exdev01','2026-01-27 08:45:30.8584','exdev01');
INSERT INTO kids_own.tb_ca_c_dtl_code (com_dtl_cd,com_group_cd,com_dtl_cd_nm,dgt,sort_seq,rsvt_cn_1,rsvt_cn_2,rsvt_cn_3,rsvt_cn_4,rsvt_cn_5,rsvt_cn_6,rsvt_cn_7,rsvt_cn_8,rsvt_cn_9,rsvt_cn_10,use_yn,reg_dt,rgtr_id,mdfcn_dt,mdfr_id) VALUES
	 ('13','EX0003','전라북도',NULL,13,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-01-27 08:45:30.8584','exdev01','2026-01-27 08:45:30.8584','exdev01'),
	 ('14','EX0003','전라남도',NULL,14,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-01-27 08:45:30.8584','exdev01','2026-01-27 08:45:30.8584','exdev01'),
	 ('15','EX0003','경상북도',NULL,15,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-01-27 08:45:30.8584','exdev01','2026-01-27 08:45:30.8584','exdev01'),
	 ('16','EX0003','경상남도',NULL,16,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-01-27 08:45:30.8584','exdev01','2026-01-27 08:45:30.8584','exdev01'),
	 ('17','EX0003','제주도',NULL,17,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-01-27 08:45:30.8584','exdev01','2026-01-27 08:45:30.8584','exdev01'),
	 ('18','EX0003','기타',NULL,18,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-01-27 08:45:30.8584','exdev01','2026-01-27 08:45:30.8584','exdev01'),
	 ('02','EX0001','여',NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-01-27 08:45:30.8584','exdev01','2026-01-27 08:45:30.8584','exdev01'),
	 ('01','EX0002','위촉',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-01-27 08:45:30.8584','exdev01','2026-01-27 08:45:30.8584','exdev01'),
	 ('01','EX0004','전문',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-01-27 08:45:30.8584','exdev01','2026-01-27 08:45:30.8584','exdev01'),
	 ('02','EX0004','상임',NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-01-27 08:45:30.8584','exdev01','2026-01-27 08:45:30.8584','exdev01');
INSERT INTO kids_own.tb_ca_c_dtl_code (com_dtl_cd,com_group_cd,com_dtl_cd_nm,dgt,sort_seq,rsvt_cn_1,rsvt_cn_2,rsvt_cn_3,rsvt_cn_4,rsvt_cn_5,rsvt_cn_6,rsvt_cn_7,rsvt_cn_8,rsvt_cn_9,rsvt_cn_10,use_yn,reg_dt,rgtr_id,mdfcn_dt,mdfr_id) VALUES
	 ('01','EX0005','회의록',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-01-27 08:45:30.8584','exdev01','2026-01-27 08:45:30.8584','exdev01'),
	 ('02','EX0005','기타',NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-01-27 08:45:30.8584','exdev01','2026-01-27 08:45:30.8584','exdev01'),
	 ('01','EX0006','위촉장',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-01-27 08:45:30.8584','exdev01','2026-01-27 08:45:30.8584','exdev01'),
	 ('02','EX0006','섭외요청',NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-01-27 08:45:30.8584','exdev01','2026-01-27 08:45:30.8584','exdev01'),
	 ('03','EX0006','자문요청',NULL,3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-01-27 08:45:30.8584','exdev01','2026-01-27 08:45:30.8584','exdev01'),
	 ('04','EX0006','자문요청리마인드(3일전)',NULL,4,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-01-27 08:45:30.8584','exdev01','2026-01-27 08:45:30.8584','exdev01'),
	 ('05','EX0006','자문요청리마인드(1일후)',NULL,5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-01-27 08:45:30.8584','exdev01','2026-01-27 08:45:30.8584','exdev01'),
	 ('06','EX0006','자문요청종료(7일후)',NULL,6,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-01-27 08:45:30.8584','exdev01','2026-01-27 08:45:30.8584','exdev01'),
	 ('07','EX0006','자문결과제재출요청',NULL,7,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-01-27 08:45:30.8584','exdev01','2026-01-27 08:45:30.8584','exdev01'),
	 ('08','EX0006','참석확인서재작성요청',NULL,8,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-01-27 08:45:30.8584','exdev01','2026-01-27 08:45:30.8584','exdev01');
INSERT INTO kids_own.tb_ca_c_dtl_code (com_dtl_cd,com_group_cd,com_dtl_cd_nm,dgt,sort_seq,rsvt_cn_1,rsvt_cn_2,rsvt_cn_3,rsvt_cn_4,rsvt_cn_5,rsvt_cn_6,rsvt_cn_7,rsvt_cn_8,rsvt_cn_9,rsvt_cn_10,use_yn,reg_dt,rgtr_id,mdfcn_dt,mdfr_id) VALUES
	 ('09','EX0006','안내메일발송',NULL,9,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-01-27 08:45:30.8584','exdev01','2026-01-27 08:45:30.8584','exdev01');
