INSERT INTO kids_own.tb_pp_m_conts (conts_sn,conts_ver_no,conts_ttl,conts_cn,conts_use_yn,rgtr_id,reg_dt,mdfr_id,mdfcn_dt) VALUES
	 ('cms0001',1,'DUR 이해','                <section class="pageCont-dur-intro">
                  <div class="info-summary-box">
                    <h3 class="info-summary-box__title">DUR (Drug Utilization Review)이란?</h3>
                    <div class="info-summary-box__desc">
                      <p>
                        의약품 적정사용(Drug Utilization Review, 이하 DUR)은 <strong>의약품을 병용하거나 소아·노인·임부·수유부에게 투여 시 
                        주의해야 할 정보를 사전에 알리고, 정해진 기준에 따라 약물 사용이 적절하게 이뤄지는지 점검하고 평가하는 
                        제도</strong>입니다.
                      </p>
                      <p>
                        부적절한 약물 사용을 사전에 방지함으로써 <strong>부작용을 예방</strong>하고 환자에게 제공하는 <strong>의료서비스의 질을 향상</strong>시키며
                        의약품을 <strong>안전하게 사용</strong>할 수 있는 환경을 조성하는데 그 목적이 있습니다.
                      </p>
                    </div>
                  </div> 

                  <h3 class="section-title">DUR 정보 제공 흐름</h3>
                  <p class="section-desc">
                    현재 한국의약품안전관리원에서 개발한 DUR 정보는 식품의약품안전처 고시 및 공고 등의 형태로 전 국민에게 제공되고, 
                    건강보험심사평가원 DUR 전산시스템(의약품안전사용서비스)를 통해 의료현장에 제공됩니다.
                  </p>

                  <div class="img-switcher">
                    
                    <img 
                      src="/img/dur_intro_img01.png" 
                      alt="한국의약품안전관리원 개발 정보가 식약처 고시를 거쳐 심평원 DUR 시스템으로 의료현장에 제공되는 과정 (PC)" 
                      class="responsive-img pc-only"
                    />
                    
                    <img 
                      src="/img/dur_intro_img01_m.png" 
                      alt="한국의약품안전관리원 개발 정보가 식약처 고시를 거쳐 심평원 DUR 시스템으로 의료현장에 제공되는 과정 (모바일)" 
                      class="responsive-img mo-only"
                    />
                  </div>

                  <h3 class="section-title">DUR 정보 정의</h3>
                  <ul class="definition-list">
                    
                    <li class="definition-list__item">
                      <div class="definition-list__icon">
                        <img src="/img/ico_dur_01.png" alt="병용금기 성분 아이콘" />
                      </div>
                      <div class="definition-list__text">
                        <span class="definition-list__title">1. 병용금기 성분</span>
                        <span class="definition-list__desc">
                          <strong>두 가지 이상의 의약품</strong>을 함께 사용하는 경우, 치료 효과의 변화 또는 심각한 부작용 발생 등의 우려가 있어 동시에 사용하지 않아야 하는 유효성분의 조합
                        </span>
                      </div>
                    </li>

                    
                    <li class="definition-list__item">
                      <div class="definition-list__icon">
                        <img src="/img/ico_dur_02.png" alt="특정연령대 금기 성분 아이콘" />
                      </div>
                      <div class="definition-list__text">
                        <span class="definition-list__title">2. 특정연령대 금기 성분</span>
                        <span class="definition-list__desc">
                          소아, 노인 등 특정연령대의 환자가 사용함에 있어 안전성이 확보되지 않았거나 심각한 부작용 발생 등의 우려가 있어 사용하지 않아야 하는 유효성분
                        </span>
                      </div>
                    </li>

                    
                    <li class="definition-list__item">
                      <div class="definition-list__icon">
                        <img src="/img/ico_dur_03.png" alt="임부금기 성분 아이콘" />
                      </div>
                      <div class="definition-list__text">
                        <span class="definition-list__title">3. 임부금기 성분</span>
                        <span class="definition-list__desc">
                          태아에게 매우 심각한 위해성(태아기형 또는 태아독성 등)을 유발하거나 유발할 가능성이 높아 임부에게 사용하는 것이 권장되지 않는 유효성분
                        </span>
                      </div>
                    </li>

                    
                    <li class="definition-list__item">
                      <div class="definition-list__icon">
                        <img src="/img/ico_dur_04.png" alt="용량주의 성분 아이콘" />
                      </div>
                      <div class="definition-list__text">
                        <span class="definition-list__title">4. 용량주의 성분</span>
                        <span class="definition-list__desc">
                          성인에게 특정 용량 초과 시 효과의 증가는 기대하기 어렵고 용량의존적 부작용 발생 가능성이 높아져 1일 최대용량에 대한 주의가 필요한 유효성분
                        </span>
                      </div>
                    </li>

                    
                    <li class="definition-list__item">
                      <div class="definition-list__icon">
                        <img src="/img/ico_dur_05.png" alt="투여기간주의 성분 아이콘" />
                      </div>
                      <div class="definition-list__text">
                        <span class="definition-list__title">5. 투여기간주의 성분</span>
                        <span class="definition-list__desc">
                          특정 투여기간 초과 시 효과의 증가는 기대하기 어렵고 부작용 발생 가능성이 높아져 1회 최대 투여기간에 대한 주의가 필요한 유효성분
                        </span>
                      </div>
                    </li>

                    
                    <li class="definition-list__item">
                      <div class="definition-list__icon">
                        <img src="/img/ico_dur_06.png" alt="효능군중복주의 성분 아이콘" />
                      </div>
                      <div class="definition-list__text">
                        <span class="definition-list__title">6. 효능군중복주의 성분</span>
                        <span class="definition-list__desc">
                          약리기전이 동일하거나 유사한 효능군 내에서 중복 투여할 때 추가적인 효과의 증가는 기대하기 어렵고 부작용 발생 가능성이 높아져 주의가 필요한 유효성분
                        </span>
                      </div>
                    </li>

                    
                    <li class="definition-list__item">
                      <div class="definition-list__icon">
                        <img src="/img/ico_dur_07.png" alt="노인주의 성분 아이콘" />
                      </div>
                      <div class="definition-list__text">
                        <span class="definition-list__title">7. 노인주의 성분</span>
                        <span class="definition-list__desc">
                          노인에서 부작용 발생 빈도 증가 등의 우려가 있어 주의가 필요한 유효성분
                        </span>
                      </div>
                    </li>

                    
                    <li class="definition-list__item">
                      <div class="definition-list__icon">
                        <img src="/img/ico_dur_08.png" alt="수유부주의 성분 아이콘" />
                      </div>
                      <div class="definition-list__text">
                        <span class="definition-list__title">8. 수유부주의 성분</span>
                        <span class="definition-list__desc">
                          수유 중의 소아에게 부작용 발생 등의 우려가 있어 수유부에게 사용 시 주의가 필요한 유효성분
                        </span>
                      </div>
                    </li>

                    
                    <li class="definition-list__item">
                      <div class="definition-list__icon">
                        <img src="/img/ico_dur_09.png" alt="분할주의 의약품 아이콘" />
                      </div>
                      <div class="definition-list__text">
                        <span class="definition-list__title">9. 분할주의 의약품</span>
                        <span class="definition-list__desc">
                          단위의 제형을 분할하여 복용할 경우 약효를 기대하기 어려운 의약품
                        </span>
                      </div>
                    </li>
                  </ul>

                  <h3 class="section-title">DUR 정보 현황</h3>
                  <div class="base-table-container">
                    <div class="base-table-meta">
                      <p class="update-date">(2025.07.14 기준)</p>
                    </div>
                    
                    <div class="table-responsive">
                      <table class="base-table">
                        <caption class="sr-only">DUR 정보 유형별 건수 및 고시/공고 현황</caption>
                        <colgroup>
                          <col style={{ width: ''25%'' }} />
                          <col style={{ width: ''45%'' }} />
                          <col style={{ width: ''30%'' }} />
                        </colgroup>
                        <thead>
                          <tr>
                            <th scope="col" colspan=''2''>정보 유형</th>
                            <th scope="col">정보 건수</th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr>
                            <th scope="row" rowspan=''3''>금기성분 고시</th>
                            <td>병용금기 (2004년~)</td>
                            <td>1,450</td>
                          </tr>
                          <tr>
                            <td>특정연령대금기 (2004년~)</td>
                            <td>207</td>
                          </tr>
                          <tr>
                            <td>임부금기 (2008년~)</td>
                            <td>1,210</td>
                          </tr>

                          <tr>
                            <th scope="row" rowspan=''6''>주의성분 공고</th>
                            <td>효능군중복주의 (2013년~)</td>
                            <td>392</td>
                          </tr>
                          <tr>
                            <td>용량주의 (2014년~)</td>
                            <td>331</td>
                          </tr>
                          <tr>
                            <td>투여기간주의 (2014년~)</td>
                            <td>60</td>
                          </tr>
                          <tr>
                            <td>노인주의 (2015년~)</td>
                            <td>108</td>
                          </tr>
                          <tr>
                            <td>수유부주의 (2024년~)</td>
                            <td>180</td>
                          </tr>
                          <tr>
                            <td>분할주의 (2015년~)</td>
                            <td>2,262(품목기준)</td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>

                  <h3 class="section-title">의약품 적정사용 자료 개발 및 홍보</h3>
                  <div class="info-action-list">
                    <div class="info-action-item">
                      <div class="info-action-item__text-group">
                        <strong class="info-action-item__title">
                          <span class="info-action-item__tag">[전문가 대상]</span> 의약품 적정사용 정보집
                        </strong>
                        <p class="info-action-item__desc">
                          전문가를 위한 의약품 안전사용 정보집을 발간하고 의약품 처방 조제 시 참고자료로 활용하도록 하고 있습니다.
                        </p>
                      </div>
                      <div className="info-action__btn">
	                  	<button type="button" className="btn-link-html">바로가기</button>
	                  </div>
                    </div>

                    <div class="info-action-item">
                      <div class="info-action-item__text-group">
                        <strong class="info-action-item__title">
                          <span class="info-action-item__tag">[대국민 대상]</span> 의약품 안전사용 교육자료
                        </strong>
                        <p class="info-action-item__desc">
                          전문가뿐 아니라 대국민 대상으로 다양한 주제의 의약품 안전사용 교육자료를 개발 배포함으로써 안전한 의약품 사용문화 조성에 이바지하고 있습니다.
                        </p>
                      </div>
                    </div>
                  </div>
                </section> ','Y','system','2026-02-04 09:56:32.280183','system','2026-02-04 09:56:32.280183'),
	 ('cms0002',1,'이상사례란?','                <section class="pageCont-dur-intro">
                  <div class="info-summary-box">
                    <h3 class="info-summary-box__title">DUR (Drug Utilization Review)이란?</h3>
                    <div class="info-summary-box__desc">
                      <p>
                        의약품 적정사용(Drug Utilization Review, 이하 DUR)은 <strong>의약품을 병용하거나 소아·노인·임부·수유부에게 투여 시 
                        주의해야 할 정보를 사전에 알리고, 정해진 기준에 따라 약물 사용이 적절하게 이뤄지는지 점검하고 평가하는 
                        제도</strong>입니다.
                      </p>
                      <p>
                        부적절한 약물 사용을 사전에 방지함으로써 <strong>부작용을 예방</strong>하고 환자에게 제공하는 <strong>의료서비스의 질을 향상</strong>시키며
                        의약품을 <strong>안전하게 사용</strong>할 수 있는 환경을 조성하는데 그 목적이 있습니다.
                      </p>
                    </div>
                  </div> 

                  <h3 class="section-title">DUR 정보 제공 흐름</h3>
                  <p class="section-desc">
                    현재 한국의약품안전관리원에서 개발한 DUR 정보는 식품의약품안전처 고시 및 공고 등의 형태로 전 국민에게 제공되고, 
                    건강보험심사평가원 DUR 전산시스템(의약품안전사용서비스)를 통해 의료현장에 제공됩니다.
                  </p>

                  <div class="img-switcher">
                    
                    <img 
                      src="/img/dur_intro_img01.png" 
                      alt="한국의약품안전관리원 개발 정보가 식약처 고시를 거쳐 심평원 DUR 시스템으로 의료현장에 제공되는 과정 (PC)" 
                      class="responsive-img pc-only"
                    />
                    
                    <img 
                      src="/img/dur_intro_img01_m.png" 
                      alt="한국의약품안전관리원 개발 정보가 식약처 고시를 거쳐 심평원 DUR 시스템으로 의료현장에 제공되는 과정 (모바일)" 
                      class="responsive-img mo-only"
                    />
                  </div>

                  <h3 class="section-title">DUR 정보 정의</h3>
                  <ul class="definition-list">
                    
                    <li class="definition-list__item">
                      <div class="definition-list__icon">
                        <img src="/img/ico_dur_01.png" alt="병용금기 성분 아이콘" />
                      </div>
                      <div class="definition-list__text">
                        <span class="definition-list__title">1. 병용금기 성분</span>
                        <span class="definition-list__desc">
                          <strong>두 가지 이상의 의약품</strong>을 함께 사용하는 경우, 치료 효과의 변화 또는 심각한 부작용 발생 등의 우려가 있어 동시에 사용하지 않아야 하는 유효성분의 조합
                        </span>
                      </div>
                    </li>

                    
                    <li class="definition-list__item">
                      <div class="definition-list__icon">
                        <img src="/img/ico_dur_02.png" alt="특정연령대 금기 성분 아이콘" />
                      </div>
                      <div class="definition-list__text">
                        <span class="definition-list__title">2. 특정연령대 금기 성분</span>
                        <span class="definition-list__desc">
                          소아, 노인 등 특정연령대의 환자가 사용함에 있어 안전성이 확보되지 않았거나 심각한 부작용 발생 등의 우려가 있어 사용하지 않아야 하는 유효성분
                        </span>
                      </div>
                    </li>

                    
                    <li class="definition-list__item">
                      <div class="definition-list__icon">
                        <img src="/img/ico_dur_03.png" alt="임부금기 성분 아이콘" />
                      </div>
                      <div class="definition-list__text">
                        <span class="definition-list__title">3. 임부금기 성분</span>
                        <span class="definition-list__desc">
                          태아에게 매우 심각한 위해성(태아기형 또는 태아독성 등)을 유발하거나 유발할 가능성이 높아 임부에게 사용하는 것이 권장되지 않는 유효성분
                        </span>
                      </div>
                    </li>

                    
                    <li class="definition-list__item">
                      <div class="definition-list__icon">
                        <img src="/img/ico_dur_04.png" alt="용량주의 성분 아이콘" />
                      </div>
                      <div class="definition-list__text">
                        <span class="definition-list__title">4. 용량주의 성분</span>
                        <span class="definition-list__desc">
                          성인에게 특정 용량 초과 시 효과의 증가는 기대하기 어렵고 용량의존적 부작용 발생 가능성이 높아져 1일 최대용량에 대한 주의가 필요한 유효성분
                        </span>
                      </div>
                    </li>

                    
                    <li class="definition-list__item">
                      <div class="definition-list__icon">
                        <img src="/img/ico_dur_05.png" alt="투여기간주의 성분 아이콘" />
                      </div>
                      <div class="definition-list__text">
                        <span class="definition-list__title">5. 투여기간주의 성분</span>
                        <span class="definition-list__desc">
                          특정 투여기간 초과 시 효과의 증가는 기대하기 어렵고 부작용 발생 가능성이 높아져 1회 최대 투여기간에 대한 주의가 필요한 유효성분
                        </span>
                      </div>
                    </li>

                    
                    <li class="definition-list__item">
                      <div class="definition-list__icon">
                        <img src="/img/ico_dur_06.png" alt="효능군중복주의 성분 아이콘" />
                      </div>
                      <div class="definition-list__text">
                        <span class="definition-list__title">6. 효능군중복주의 성분</span>
                        <span class="definition-list__desc">
                          약리기전이 동일하거나 유사한 효능군 내에서 중복 투여할 때 추가적인 효과의 증가는 기대하기 어렵고 부작용 발생 가능성이 높아져 주의가 필요한 유효성분
                        </span>
                      </div>
                    </li>

                    
                    <li class="definition-list__item">
                      <div class="definition-list__icon">
                        <img src="/img/ico_dur_07.png" alt="노인주의 성분 아이콘" />
                      </div>
                      <div class="definition-list__text">
                        <span class="definition-list__title">7. 노인주의 성분</span>
                        <span class="definition-list__desc">
                          노인에서 부작용 발생 빈도 증가 등의 우려가 있어 주의가 필요한 유효성분
                        </span>
                      </div>
                    </li>

                    
                    <li class="definition-list__item">
                      <div class="definition-list__icon">
                        <img src="/img/ico_dur_08.png" alt="수유부주의 성분 아이콘" />
                      </div>
                      <div class="definition-list__text">
                        <span class="definition-list__title">8. 수유부주의 성분</span>
                        <span class="definition-list__desc">
                          수유 중의 소아에게 부작용 발생 등의 우려가 있어 수유부에게 사용 시 주의가 필요한 유효성분
                        </span>
                      </div>
                    </li>

                    
                    <li class="definition-list__item">
                      <div class="definition-list__icon">
                        <img src="/img/ico_dur_09.png" alt="분할주의 의약품 아이콘" />
                      </div>
                      <div class="definition-list__text">
                        <span class="definition-list__title">9. 분할주의 의약품</span>
                        <span class="definition-list__desc">
                          단위의 제형을 분할하여 복용할 경우 약효를 기대하기 어려운 의약품
                        </span>
                      </div>
                    </li>
                  </ul>

                  <h3 class="section-title">DUR 정보 현황</h3>
                  <div class="base-table-container">
                    <div class="base-table-meta">
                      <p class="update-date">(2025.07.14 기준)</p>
                    </div>
                    
                    <div class="table-responsive">
                      <table class="base-table">
                        <caption class="sr-only">DUR 정보 유형별 건수 및 고시/공고 현황</caption>
                        <colgroup>
                          <col style={{ width: ''25%'' }} />
                          <col style={{ width: ''45%'' }} />
                          <col style={{ width: ''30%'' }} />
                        </colgroup>
                        <thead>
                          <tr>
                            <th scope="col" colspan=''2''>정보 유형</th>
                            <th scope="col">정보 건수</th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr>
                            <th scope="row" rowspan=''3''>금기성분 고시</th>
                            <td>병용금기 (2004년~)</td>
                            <td>1,450</td>
                          </tr>
                          <tr>
                            <td>특정연령대금기 (2004년~)</td>
                            <td>207</td>
                          </tr>
                          <tr>
                            <td>임부금기 (2008년~)</td>
                            <td>1,210</td>
                          </tr>

                          <tr>
                            <th scope="row" rowspan=''6''>주의성분 공고</th>
                            <td>효능군중복주의 (2013년~)</td>
                            <td>392</td>
                          </tr>
                          <tr>
                            <td>용량주의 (2014년~)</td>
                            <td>331</td>
                          </tr>
                          <tr>
                            <td>투여기간주의 (2014년~)</td>
                            <td>60</td>
                          </tr>
                          <tr>
                            <td>노인주의 (2015년~)</td>
                            <td>108</td>
                          </tr>
                          <tr>
                            <td>수유부주의 (2024년~)</td>
                            <td>180</td>
                          </tr>
                          <tr>
                            <td>분할주의 (2015년~)</td>
                            <td>2,262(품목기준)</td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>

                  <h3 class="section-title">의약품 적정사용 자료 개발 및 홍보</h3>
                  <div class="info-action-list">
                    <div class="info-action-item">
                      <div class="info-action-item__text-group">
                        <strong class="info-action-item__title">
                          <span class="info-action-item__tag">[전문가 대상]</span> 의약품 적정사용 정보집
                        </strong>
                        <p class="info-action-item__desc">
                          전문가를 위한 의약품 안전사용 정보집을 발간하고 의약품 처방 조제 시 참고자료로 활용하도록 하고 있습니다.
                        </p>
                      </div>
                      <div className="info-action__btn">
	                  	<button type="button" className="btn-link-html">바로가기</button>
	                  </div>
                    </div>

                    <div class="info-action-item">
                      <div class="info-action-item__text-group">
                        <strong class="info-action-item__title">
                          <span class="info-action-item__tag">[대국민 대상]</span> 의약품 안전사용 교육자료
                        </strong>
                        <p class="info-action-item__desc">
                          전문가뿐 아니라 대국민 대상으로 다양한 주제의 의약품 안전사용 교육자료를 개발 배포함으로써 안전한 의약품 사용문화 조성에 이바지하고 있습니다.
                        </p>
                      </div>
                    </div>
                  </div>
                </section> ','Y','system','2026-02-04 09:56:32.280183','system','2026-02-04 09:56:32.280183');
