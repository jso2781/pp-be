INSERT INTO kids_own.tb_ca_l_cntn_info_log (prvc_hstry_sn,task_sys_se_cd,menu_sn,cntn_dt,acsr_info_nm,qna_sql_cn,prcs_nocs,dwnld_yn,dwnld_rsn,flfmt_task_nm,reg_dt,rgtr_id,mdfcn_dt,mdfr_id) VALUES
	 (13,'02',3,NULL,'박성주',NULL,NULL,NULL,NULL,'1','2026-02-04 13:04:13.973034','psj','2026-02-04 13:04:13.973034','psj2'),
	 (14,'02',3,NULL,'박성주',NULL,NULL,NULL,NULL,'1','2026-02-04 13:04:13.987738','psj','2026-02-04 13:04:13.987738','psj2'),
	 (15,'02',3,NULL,'박성주',NULL,NULL,NULL,NULL,'1','2026-02-04 13:04:21.868471','psj','2026-02-04 13:04:21.868471','psj2'),
	 (16,'02',3,NULL,'박성주',NULL,NULL,NULL,NULL,'1','2026-02-04 13:04:21.872822','psj','2026-02-04 13:04:21.872822','psj2'),
	 (18,'02',3,NULL,'박성주',NULL,NULL,NULL,NULL,'1','2026-02-04 13:09:08.959855','psj','2026-02-04 13:09:08.959855','psj2'),
	 (17,'02',3,NULL,'박성주',NULL,NULL,NULL,NULL,'1','2026-02-04 13:09:08.95986','psj','2026-02-04 13:09:08.95986','psj2'),
	 (19,'02',3,NULL,'박성주',NULL,NULL,NULL,NULL,'1','2026-02-04 13:44:31.189256','psj','2026-02-04 13:44:31.189256','psj2'),
	 (20,'02',3,NULL,'박성주',NULL,NULL,NULL,NULL,'1','2026-02-04 13:44:31.203795','psj','2026-02-04 13:44:31.203795','psj2');
