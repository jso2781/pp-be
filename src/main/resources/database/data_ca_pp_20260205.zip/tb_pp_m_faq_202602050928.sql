INSERT INTO kids_own.tb_pp_m_faq (faq_sn,task_se_cd,faq_clsf_nm,faq_ttl,faq_seq,use_yn,lang_se_cd,faq_ans_cn,atch_file_group_id,wrtr_dept_nm,mdfr_dept_nm,rgtr_id,reg_dt,mdfr_id,mdfcn_dt) VALUES
	 (1,'PP','의약품부작용 정의','테스트 FAQ',2,'N','KOR','테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트',NULL,NULL,NULL,'','2026-02-03 18:21:58.685785','','2026-02-03 18:21:58.685785');
