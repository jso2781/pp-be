-- kids_own.tb_pp_d_menu definition

-- Drop table

-- DROP TABLE kids_own.tb_pp_d_menu;

CREATE TABLE kids_own.tb_pp_d_menu (
	menu_sn varchar(20) NOT NULL,
	menu_url_addr varchar(320) NULL,
	menu_npag_nm varchar(20) NULL,
	prvc_incl_yn bpchar(1) NOT NULL,
	dgstfn_exmn_yn bpchar(1) NOT NULL,
	menu_expsr_yn bpchar(1) NOT NULL, -- default: Y
	dept_info_expsr_yn bpchar(1) NOT NULL,
	pic_info_expsr_yn bpchar(1) NOT NULL,
	mobl_aplcn_yn bpchar(1) NOT NULL,
	lgn_yn bpchar(1) NULL,
	encpt_pic_telno varchar(256) NULL,
	menu_kogl_cprgt_type_cd bpchar(1) NULL,
	menu_pic_id varchar(40) NOT NULL,
	menu_tkcg_dept_no varchar(100) NULL,
	rgtr_id varchar(40) NULL,
	reg_dt timestamp NULL,
	mdfr_id varchar(40) NULL,
	mdfcn_dt timestamp NULL,
	CONSTRAINT pk_tb_pp_d_menu PRIMARY KEY (menu_sn)
);

-- Column comments

COMMENT ON COLUMN kids_own.tb_pp_d_menu.menu_expsr_yn IS 'default: Y';

-- Permissions

ALTER TABLE kids_own.tb_pp_d_menu OWNER TO postgres;
GRANT ALL ON TABLE kids_own.tb_pp_d_menu TO postgres;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_d_menu TO bo_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_d_menu TO bo_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_d_menu TO cm_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_d_menu TO cm_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_d_menu TO co_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_d_menu TO co_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_d_menu TO cr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_d_menu TO cr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_d_menu TO dr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_d_menu TO dr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_d_menu TO ex_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_d_menu TO ex_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_d_menu TO pp_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_d_menu TO pp_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_d_menu TO sc_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_d_menu TO sc_dev;


-- kids_own.tb_pp_m_authrt definition

-- Drop table

-- DROP TABLE kids_own.tb_pp_m_authrt;

CREATE TABLE kids_own.tb_pp_m_authrt (
	authrt_cd varchar(10) NOT NULL,
	up_authrt_cd varchar(20) NOT NULL,
	task_se_cd varchar(20) NULL,
	authrt_nm varchar(20) NULL,
	authrt_type_cd varchar(20) NULL,
	authrt_expln varchar(4000) NULL,
	use_yn bpchar(1) NOT NULL,
	wrtr_dept_nm varchar(40) NULL,
	mdfr_dept_nm varchar(40) NULL,
	rgtr_id varchar(40) NULL,
	reg_dt timestamp NULL,
	mdfr_id varchar(40) NULL,
	mdfcn_dt timestamp NULL,
	CONSTRAINT pk_tb_pp_m_authrt PRIMARY KEY (authrt_cd)
);

-- Permissions

ALTER TABLE kids_own.tb_pp_m_authrt OWNER TO postgres;
GRANT ALL ON TABLE kids_own.tb_pp_m_authrt TO postgres;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_authrt TO bo_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_authrt TO bo_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_authrt TO cm_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_authrt TO cm_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_authrt TO co_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_authrt TO co_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_authrt TO cr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_authrt TO cr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_authrt TO dr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_authrt TO dr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_authrt TO ex_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_authrt TO ex_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_authrt TO pp_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_authrt TO pp_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_authrt TO sc_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_authrt TO sc_dev;


-- kids_own.tb_pp_m_authrt_chg_hstry definition

-- Drop table

-- DROP TABLE kids_own.tb_pp_m_authrt_chg_hstry;

CREATE TABLE kids_own.tb_pp_m_authrt_chg_hstry (
	authrt_chg_sn numeric(10) NOT NULL,
	authrt_cd varchar(10) NOT NULL,
	menu_sn varchar(20) NULL,
	aplcn_trgt_type_cd bpchar(5) NOT NULL,
	chg_role_list_cn varchar(4000) NULL,
	aplcn_trgt_nm varchar(20) NULL,
	chg_type_cd varchar(20) NOT NULL,
	authrt_chg_rmrk_cn varchar(1000) NOT NULL,
	rgtr_id varchar(40) NULL,
	reg_dt timestamp NULL,
	mdfr_id varchar(40) NULL,
	mdfcn_dt timestamp NULL,
	CONSTRAINT pk_tb_pp_m_authrt_chg_hstry PRIMARY KEY (authrt_chg_sn)
);

-- Permissions

ALTER TABLE kids_own.tb_pp_m_authrt_chg_hstry OWNER TO postgres;
GRANT ALL ON TABLE kids_own.tb_pp_m_authrt_chg_hstry TO postgres;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_authrt_chg_hstry TO bo_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_authrt_chg_hstry TO bo_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_authrt_chg_hstry TO cm_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_authrt_chg_hstry TO cm_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_authrt_chg_hstry TO co_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_authrt_chg_hstry TO co_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_authrt_chg_hstry TO cr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_authrt_chg_hstry TO cr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_authrt_chg_hstry TO dr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_authrt_chg_hstry TO dr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_authrt_chg_hstry TO ex_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_authrt_chg_hstry TO ex_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_authrt_chg_hstry TO pp_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_authrt_chg_hstry TO pp_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_authrt_chg_hstry TO sc_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_authrt_chg_hstry TO sc_dev;


-- kids_own.tb_pp_m_authrt_menu definition

-- Drop table

-- DROP TABLE kids_own.tb_pp_m_authrt_menu;

CREATE TABLE kids_own.tb_pp_m_authrt_menu (
	authrt_cd varchar(10) NOT NULL,
	menu_sn varchar(20) NOT NULL,
	authrt_menu_role_rmrk_cn varchar(1000) NULL,
	rgtr_id varchar(40) NULL,
	reg_dt timestamp NULL,
	mdfr_id varchar(40) NULL,
	mdfcn_dt timestamp NULL,
	CONSTRAINT pk_tb_pp_m_authrt_menu PRIMARY KEY (authrt_cd, menu_sn)
);

-- Permissions

ALTER TABLE kids_own.tb_pp_m_authrt_menu OWNER TO postgres;
GRANT ALL ON TABLE kids_own.tb_pp_m_authrt_menu TO postgres;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_authrt_menu TO bo_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_authrt_menu TO bo_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_authrt_menu TO cm_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_authrt_menu TO cm_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_authrt_menu TO co_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_authrt_menu TO co_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_authrt_menu TO cr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_authrt_menu TO cr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_authrt_menu TO dr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_authrt_menu TO dr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_authrt_menu TO ex_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_authrt_menu TO ex_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_authrt_menu TO pp_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_authrt_menu TO pp_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_authrt_menu TO sc_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_authrt_menu TO sc_dev;


-- kids_own.tb_pp_m_authrt_menu_role definition

-- Drop table

-- DROP TABLE kids_own.tb_pp_m_authrt_menu_role;

CREATE TABLE kids_own.tb_pp_m_authrt_menu_role (
	authrt_cd varchar(10) NOT NULL,
	role_cd varchar(20) NOT NULL,
	menu_sn varchar(20) NOT NULL,
	rgtr_id varchar(40) NULL,
	reg_dt timestamp NULL,
	mdfr_id varchar(40) NULL,
	mdfcn_dt timestamp NULL,
	CONSTRAINT pk_tb_pp_m_authrt_menu_role PRIMARY KEY (authrt_cd, role_cd, menu_sn)
);

-- Permissions

ALTER TABLE kids_own.tb_pp_m_authrt_menu_role OWNER TO postgres;
GRANT ALL ON TABLE kids_own.tb_pp_m_authrt_menu_role TO postgres;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_authrt_menu_role TO bo_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_authrt_menu_role TO bo_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_authrt_menu_role TO cm_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_authrt_menu_role TO cm_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_authrt_menu_role TO co_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_authrt_menu_role TO co_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_authrt_menu_role TO cr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_authrt_menu_role TO cr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_authrt_menu_role TO dr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_authrt_menu_role TO dr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_authrt_menu_role TO ex_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_authrt_menu_role TO ex_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_authrt_menu_role TO pp_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_authrt_menu_role TO pp_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_authrt_menu_role TO sc_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_authrt_menu_role TO sc_dev;


-- kids_own.tb_pp_m_bbs definition

-- Drop table

-- DROP TABLE kids_own.tb_pp_m_bbs;

CREATE TABLE kids_own.tb_pp_m_bbs (
	bbs_id varchar(20) NOT NULL,
	bbs_nm varchar(300) NULL,
	bbs_atrb_cd bpchar(3) NOT NULL,
	bbs_expln varchar(4000) NULL,
	bbs_smry_cn varchar(4000) NULL,
	cmnt_use_yn bpchar(1) NOT NULL,
	inq_cnt_expsr_yn bpchar(1) NOT NULL,
	dept_expsr_yn bpchar(1) NOT NULL,
	file_atch_yn bpchar(1) NOT NULL,
	atch_psblty_file_cnt numeric(2) NULL,
	lang_se_cd bpchar(3) NOT NULL,
	use_yn bpchar(1) NOT NULL,
	rgtr_id varchar(40) NULL,
	reg_dt timestamp NULL,
	mdfr_id varchar(40) NULL,
	mdfcn_dt timestamp NULL,
	CONSTRAINT pk_tb_pp_m_bbs PRIMARY KEY (bbs_id)
);

-- Permissions

ALTER TABLE kids_own.tb_pp_m_bbs OWNER TO postgres;
GRANT ALL ON TABLE kids_own.tb_pp_m_bbs TO postgres;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_bbs TO bo_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_bbs TO bo_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_bbs TO cm_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_bbs TO cm_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_bbs TO co_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_bbs TO co_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_bbs TO cr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_bbs TO cr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_bbs TO dr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_bbs TO dr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_bbs TO ex_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_bbs TO ex_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_bbs TO pp_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_bbs TO pp_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_bbs TO sc_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_bbs TO sc_dev;


-- kids_own.tb_pp_m_bbs_authrt definition

-- Drop table

-- DROP TABLE kids_own.tb_pp_m_bbs_authrt;

CREATE TABLE kids_own.tb_pp_m_bbs_authrt (
	bbs_id varchar(20) NOT NULL,
	authrt_cd varchar(10) NOT NULL,
	rgtr_id varchar(40) NULL,
	reg_dt timestamp NULL,
	mdfr_id varchar(40) NULL,
	mdfcn_dt timestamp NULL,
	CONSTRAINT pk_tb_pp_m_bbs_authrt PRIMARY KEY (bbs_id, authrt_cd)
);

-- Permissions

ALTER TABLE kids_own.tb_pp_m_bbs_authrt OWNER TO postgres;
GRANT ALL ON TABLE kids_own.tb_pp_m_bbs_authrt TO postgres;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_bbs_authrt TO bo_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_bbs_authrt TO bo_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_bbs_authrt TO cm_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_bbs_authrt TO cm_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_bbs_authrt TO co_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_bbs_authrt TO co_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_bbs_authrt TO cr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_bbs_authrt TO cr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_bbs_authrt TO dr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_bbs_authrt TO dr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_bbs_authrt TO ex_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_bbs_authrt TO ex_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_bbs_authrt TO pp_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_bbs_authrt TO pp_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_bbs_authrt TO sc_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_bbs_authrt TO sc_dev;


-- kids_own.tb_pp_m_c definition

-- Drop table

-- DROP TABLE kids_own.tb_pp_m_c;

CREATE TABLE kids_own.tb_pp_m_c (
	dclr_sn numeric(10) NOT NULL,
	encpt_mbr_flnm varchar(256) NOT NULL,
	encpt_mbr_telno varchar(256) NULL,
	encpt_mbr_eml_nm varchar(256) NULL,
	dclr_ttl_nm varchar(200) NOT NULL,
	dshsty_actr_flnm varchar(300) NOT NULL,
	dshsty_act_pip_cn varchar(1000) NOT NULL,
	dshsty_act_plc_cn varchar(1000) NOT NULL,
	dshsty_act_cn text NOT NULL,
	add_idntf_idfr_nm varchar(300) NULL,
	dclr_cn_idnty_mthd_cn varchar(4000) NULL,
	dshsty_act_idntf_rsn_cn varchar(4000) NULL,
	dshsty_act_prd_cn varchar(1000) NULL,
	rgtr_id varchar(40) NULL,
	reg_dt timestamp NULL,
	mdfr_id varchar(40) NULL,
	mdfcn_dt timestamp NULL,
	CONSTRAINT pk_tb_pp_m_c PRIMARY KEY (dclr_sn)
);

-- Permissions

ALTER TABLE kids_own.tb_pp_m_c OWNER TO postgres;
GRANT ALL ON TABLE kids_own.tb_pp_m_c TO postgres;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_c TO bo_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_c TO bo_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_c TO cm_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_c TO cm_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_c TO co_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_c TO co_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_c TO cr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_c TO cr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_c TO dr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_c TO dr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_c TO ex_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_c TO ex_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_c TO pp_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_c TO pp_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_c TO sc_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_c TO sc_dev;


-- kids_own.tb_pp_m_cmnt definition

-- Drop table

-- DROP TABLE kids_own.tb_pp_m_cmnt;

CREATE TABLE kids_own.tb_pp_m_cmnt (
	cmnt_sn numeric(22) NOT NULL,
	pst_sn numeric(22) NOT NULL,
	cmnt_cn varchar(4000) NULL,
	encpt_cmnt_pswd varchar(256) NULL,
	use_yn bpchar(1) NOT NULL,
	rgtr_id varchar(40) NULL,
	reg_dt timestamp NULL,
	mdfr_id varchar(40) NULL,
	mdfcn_dt timestamp NULL,
	CONSTRAINT pk_tb_pp_m_cmnt PRIMARY KEY (cmnt_sn)
);

-- Permissions

ALTER TABLE kids_own.tb_pp_m_cmnt OWNER TO postgres;
GRANT ALL ON TABLE kids_own.tb_pp_m_cmnt TO postgres;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_cmnt TO bo_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_cmnt TO bo_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_cmnt TO cm_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_cmnt TO cm_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_cmnt TO co_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_cmnt TO co_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_cmnt TO cr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_cmnt TO cr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_cmnt TO dr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_cmnt TO dr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_cmnt TO ex_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_cmnt TO ex_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_cmnt TO pp_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_cmnt TO pp_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_cmnt TO sc_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_cmnt TO sc_dev;


-- kids_own.tb_pp_m_conts definition

-- Drop table

-- DROP TABLE kids_own.tb_pp_m_conts;

CREATE TABLE kids_own.tb_pp_m_conts (
	conts_sn varchar(10) NOT NULL,
	conts_ttl varchar(200) NOT NULL,
	conts_cn text NOT NULL,
	conts_use_yn bpchar(1) NOT NULL,
	rgtr_id varchar(40) NULL,
	reg_dt timestamp NULL,
	mdfr_id varchar(40) NULL,
	mdfcn_dt timestamp NULL,
	CONSTRAINT pk_tb_pp_m_conts PRIMARY KEY (conts_sn)
);

-- Permissions

ALTER TABLE kids_own.tb_pp_m_conts OWNER TO postgres;
GRANT ALL ON TABLE kids_own.tb_pp_m_conts TO postgres;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_conts TO bo_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_conts TO bo_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_conts TO cm_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_conts TO cm_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_conts TO co_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_conts TO co_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_conts TO cr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_conts TO cr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_conts TO dr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_conts TO dr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_conts TO ex_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_conts TO ex_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_conts TO pp_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_conts TO pp_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_conts TO sc_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_conts TO sc_dev;


-- kids_own.tb_pp_m_dept_authrt definition

-- Drop table

-- DROP TABLE kids_own.tb_pp_m_dept_authrt;

CREATE TABLE kids_own.tb_pp_m_dept_authrt (
	dept_no varchar(20) NOT NULL,
	authrt_cd varchar(10) NOT NULL,
	dept_authrt_rmrk_cn varchar(1000) NULL,
	rgtr_id varchar(40) NULL,
	reg_dt timestamp NULL,
	mdfr_id varchar(40) NULL,
	mdfcn_dt timestamp NULL,
	CONSTRAINT pk_tb_pp_m_dept_authrt PRIMARY KEY (dept_no, authrt_cd)
);

-- Permissions

ALTER TABLE kids_own.tb_pp_m_dept_authrt OWNER TO postgres;
GRANT ALL ON TABLE kids_own.tb_pp_m_dept_authrt TO postgres;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dept_authrt TO bo_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dept_authrt TO bo_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dept_authrt TO cm_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dept_authrt TO cm_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dept_authrt TO co_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dept_authrt TO co_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dept_authrt TO cr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dept_authrt TO cr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dept_authrt TO dr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dept_authrt TO dr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dept_authrt TO ex_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dept_authrt TO ex_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dept_authrt TO pp_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dept_authrt TO pp_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dept_authrt TO sc_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dept_authrt TO sc_dev;


-- kids_own.tb_pp_m_dept_info definition

-- Drop table

-- DROP TABLE kids_own.tb_pp_m_dept_info;

CREATE TABLE kids_own.tb_pp_m_dept_info (
	dept_no varchar(20) NOT NULL,
	dept_nm varchar(80) NULL,
	up_dept_no varchar(20) NULL,
	rgtr_id varchar(40) NULL,
	reg_dt timestamp NULL,
	mdfr_id varchar(40) NULL,
	mdfcn_dt timestamp NULL,
	CONSTRAINT pk_tb_pp_m_dept_info PRIMARY KEY (dept_no)
);

-- Permissions

ALTER TABLE kids_own.tb_pp_m_dept_info OWNER TO postgres;
GRANT ALL ON TABLE kids_own.tb_pp_m_dept_info TO postgres;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dept_info TO bo_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dept_info TO bo_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dept_info TO cm_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dept_info TO cm_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dept_info TO co_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dept_info TO co_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dept_info TO cr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dept_info TO cr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dept_info TO dr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dept_info TO dr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dept_info TO ex_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dept_info TO ex_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dept_info TO pp_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dept_info TO pp_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dept_info TO sc_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dept_info TO sc_dev;


-- kids_own.tb_pp_m_dgstfn_exmn definition

-- Drop table

-- DROP TABLE kids_own.tb_pp_m_dgstfn_exmn;

CREATE TABLE kids_own.tb_pp_m_dgstfn_exmn (
	dgstfn_exmn_sn numeric(22) NOT NULL,
	menu_sn varchar(20) NOT NULL,
	dgstfn_scr numeric(2) NOT NULL,
	rgtr_id varchar(40) NULL,
	reg_dt timestamp NULL,
	mdfr_id varchar(40) NULL,
	mdfcn_dt timestamp NULL,
	CONSTRAINT pk_tb_pp_m_dgstfn_exmn PRIMARY KEY (dgstfn_exmn_sn)
);

-- Permissions

ALTER TABLE kids_own.tb_pp_m_dgstfn_exmn OWNER TO postgres;
GRANT ALL ON TABLE kids_own.tb_pp_m_dgstfn_exmn TO postgres;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dgstfn_exmn TO bo_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dgstfn_exmn TO bo_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dgstfn_exmn TO cm_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dgstfn_exmn TO cm_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dgstfn_exmn TO co_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dgstfn_exmn TO co_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dgstfn_exmn TO cr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dgstfn_exmn TO cr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dgstfn_exmn TO dr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dgstfn_exmn TO dr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dgstfn_exmn TO ex_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dgstfn_exmn TO ex_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dgstfn_exmn TO pp_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dgstfn_exmn TO pp_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dgstfn_exmn TO sc_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dgstfn_exmn TO sc_dev;


-- kids_own.tb_pp_m_dmn definition

-- Drop table

-- DROP TABLE kids_own.tb_pp_m_dmn;

CREATE TABLE kids_own.tb_pp_m_dmn (
	com_std_dmn_nm varchar(100) NOT NULL,
	sys_se_nm varchar(40) NULL,
	artcl_sou_nm varchar(40) NULL,
	com_std_dmn_clsf_nm varchar(40) NULL,
	com_std_dmn_group_nm varchar(40) NULL,
	com_std_dmn_expln varchar(4000) NULL,
	dmn_type_nm varchar(40) NULL,
	dmn_len numeric(10) NULL,
	dmn_dcpt_len numeric(10) NULL,
	rgtr_id varchar(40) NULL,
	reg_dt timestamp NULL,
	mdfr_id varchar(40) NULL,
	mdfcn_dt timestamp NULL,
	CONSTRAINT pk_tb_pp_m_dmn PRIMARY KEY (com_std_dmn_nm)
);

-- Permissions

ALTER TABLE kids_own.tb_pp_m_dmn OWNER TO postgres;
GRANT ALL ON TABLE kids_own.tb_pp_m_dmn TO postgres;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dmn TO bo_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dmn TO bo_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dmn TO cm_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dmn TO cm_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dmn TO co_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dmn TO co_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dmn TO cr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dmn TO cr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dmn TO dr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dmn TO dr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dmn TO ex_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dmn TO ex_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dmn TO pp_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dmn TO pp_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dmn TO sc_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dmn TO sc_dev;


-- kids_own.tb_pp_m_dur_age_bann definition

-- Drop table

-- DROP TABLE kids_own.tb_pp_m_dur_age_bann;

CREATE TABLE kids_own.tb_pp_m_dur_age_bann (
	연령금기일련번호 varchar(50) NOT NULL,
	igrd_nm varchar(100) NOT NULL,
	igrd_cd varchar(20) NOT NULL,
	prdct_cd bpchar(9) NOT NULL,
	prdct_nm varchar(256) NOT NULL,
	bzenty_nm varchar(100) NOT NULL,
	rlvt_age numeric(3) NOT NULL,
	rlvt_age_unit_nm varchar(20) NULL,
	age_prcs_cnd_nm varchar(20) NULL,
	ancmnt_no bpchar(8) NULL,
	ancmnt_ymd bpchar(8) NULL,
	dtl_info_cn varchar(4000) NULL,
	slry_se_cd bpchar(1) NULL, -- 1:급여, 2:비급여
	aplcn_ym bpchar(6) NULL,
	oper_stts_cd bpchar(1) NULL, -- O:운영,W:적용대기,E:오류
	rgtr_id varchar(40) NULL,
	reg_dt timestamp NULL,
	mdfr_id varchar(40) NULL,
	mdfcn_dt timestamp NULL,
	CONSTRAINT pk_tb_pp_m_dur_age_bann PRIMARY KEY ("연령금기일련번호")
);

-- Column comments

COMMENT ON COLUMN kids_own.tb_pp_m_dur_age_bann.slry_se_cd IS '1:급여, 2:비급여';
COMMENT ON COLUMN kids_own.tb_pp_m_dur_age_bann.oper_stts_cd IS 'O:운영,W:적용대기,E:오류';

-- Permissions

ALTER TABLE kids_own.tb_pp_m_dur_age_bann OWNER TO postgres;
GRANT ALL ON TABLE kids_own.tb_pp_m_dur_age_bann TO postgres;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_age_bann TO bo_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_age_bann TO bo_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_age_bann TO cm_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_age_bann TO cm_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_age_bann TO co_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_age_bann TO co_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_age_bann TO cr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_age_bann TO cr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_age_bann TO dr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_age_bann TO dr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_age_bann TO ex_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_age_bann TO ex_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_age_bann TO pp_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_age_bann TO pp_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_age_bann TO sc_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_age_bann TO sc_dev;


-- kids_own.tb_pp_m_dur_conc_bann definition

-- Drop table

-- DROP TABLE kids_own.tb_pp_m_dur_conc_bann;

CREATE TABLE kids_own.tb_pp_m_dur_conc_bann (
	병용금기일련번호 varchar(50) NOT NULL,
	igrd_nm_1 varchar(100) NOT NULL,
	igrd_cd_1 varchar(20) NOT NULL,
	prdct_cd_1 bpchar(9) NOT NULL,
	prdct_nm_1 varchar(256) NULL,
	bzenty_nm_1 varchar(100) NULL,
	slry_se_cd_1 bpchar(1) NULL, -- 1:급여, 2:비급여
	igrd_nm_2 varchar(100) NOT NULL,
	igrd_cd_2 varchar(20) NOT NULL,
	prdct_cd_2 bpchar(9) NOT NULL,
	prdct_nm_2 varchar(256) NULL,
	bzenty_nm_2 varchar(100) NULL,
	slry_se_cd_2 bpchar(1) NULL, -- 1:급여, 2:비급여
	ancmnt_no bpchar(8) NULL,
	ancmnt_aplcn_ymd bpchar(8) NULL,
	금기사유 varchar(2000) NULL,
	rmrk_cn varchar(4000) NULL,
	aplcn_ym bpchar(6) NULL,
	oper_stts_cd bpchar(1) NULL, -- O:운영,W:적용대기,E:오류
	rgtr_id varchar(40) NULL,
	reg_dt timestamp NULL,
	mdfr_id varchar(40) NULL,
	mdfcn_dt timestamp NULL,
	CONSTRAINT pk_tb_pp_m_dur_conc_bann PRIMARY KEY ("병용금기일련번호")
);

-- Column comments

COMMENT ON COLUMN kids_own.tb_pp_m_dur_conc_bann.slry_se_cd_1 IS '1:급여, 2:비급여';
COMMENT ON COLUMN kids_own.tb_pp_m_dur_conc_bann.slry_se_cd_2 IS '1:급여, 2:비급여';
COMMENT ON COLUMN kids_own.tb_pp_m_dur_conc_bann.oper_stts_cd IS 'O:운영,W:적용대기,E:오류';

-- Permissions

ALTER TABLE kids_own.tb_pp_m_dur_conc_bann OWNER TO postgres;
GRANT ALL ON TABLE kids_own.tb_pp_m_dur_conc_bann TO postgres;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_conc_bann TO bo_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_conc_bann TO bo_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_conc_bann TO cm_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_conc_bann TO cm_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_conc_bann TO co_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_conc_bann TO co_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_conc_bann TO cr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_conc_bann TO cr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_conc_bann TO dr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_conc_bann TO dr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_conc_bann TO ex_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_conc_bann TO ex_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_conc_bann TO pp_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_conc_bann TO pp_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_conc_bann TO sc_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_conc_bann TO sc_dev;


-- kids_own.tb_pp_m_dur_cpct definition

-- Drop table

-- DROP TABLE kids_own.tb_pp_m_dur_cpct;

CREATE TABLE kids_own.tb_pp_m_dur_cpct (
	cpct_cutn_sn varchar(50) NOT NULL,
	mdcn_cd bpchar(9) NOT NULL,
	mdcn_nm varchar(256) NULL,
	gnrl_nm_cd bpchar(9) NOT NULL,
	gnrl_nm varchar(100) NULL,
	day_max_admin_cpct_cn varchar(4000) NOT NULL,
	day_max_admin_crtr_cpct numeric(10, 3) NULL,
	chck_crtr_igrd_cpct numeric(10, 3) NULL,
	pbanc_ymd bpchar(8) NULL,
	pbanc_no bpchar(8) NULL,
	dtl_cn varchar(4000) NULL,
	slry_se_cd bpchar(1) NULL, -- 1:급여, 2:비급여
	aplcn_ym bpchar(6) NULL,
	oper_stts_cd bpchar(1) NULL, -- O:운영,W:적용대기,E:오류
	rgtr_id varchar(40) NULL,
	reg_dt timestamp NULL,
	mdfr_id varchar(40) NULL,
	mdfcn_dt timestamp NULL,
	CONSTRAINT pk_tb_pp_m_dur_cpct PRIMARY KEY (cpct_cutn_sn)
);

-- Column comments

COMMENT ON COLUMN kids_own.tb_pp_m_dur_cpct.slry_se_cd IS '1:급여, 2:비급여';
COMMENT ON COLUMN kids_own.tb_pp_m_dur_cpct.oper_stts_cd IS 'O:운영,W:적용대기,E:오류';

-- Permissions

ALTER TABLE kids_own.tb_pp_m_dur_cpct OWNER TO postgres;
GRANT ALL ON TABLE kids_own.tb_pp_m_dur_cpct TO postgres;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_cpct TO bo_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_cpct TO bo_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_cpct TO cm_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_cpct TO cm_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_cpct TO co_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_cpct TO co_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_cpct TO cr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_cpct TO cr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_cpct TO dr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_cpct TO dr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_cpct TO ex_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_cpct TO ex_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_cpct TO pp_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_cpct TO pp_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_cpct TO sc_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_cpct TO sc_dev;


-- kids_own.tb_pp_m_dur_dosage definition

-- Drop table

-- DROP TABLE kids_own.tb_pp_m_dur_dosage;

CREATE TABLE kids_own.tb_pp_m_dur_dosage (
	admin_prd_cutn_sn varchar(50) NOT NULL,
	mdcn_cd bpchar(9) NOT NULL,
	mdcn_nm varchar(256) NULL,
	gnrl_nm_cd bpchar(9) NOT NULL,
	gnrl_nm varchar(100) NULL,
	max_admin_prd_day_cnt numeric(4) NOT NULL,
	pbanc_ymd bpchar(8) NULL,
	pbanc_no bpchar(8) NULL,
	rmrk_cn varchar(4000) NULL,
	slry_se_cd bpchar(1) NULL, -- 1:급여, 2:비급여
	aplcn_ym bpchar(6) NULL,
	oper_stts_cd bpchar(1) NULL, -- O:운영,W:적용대기,E:오류
	rgtr_id varchar(40) NULL,
	reg_dt timestamp NULL,
	mdfr_id varchar(40) NULL,
	mdfcn_dt timestamp NULL,
	CONSTRAINT pk_tb_pp_m_dur_dosage PRIMARY KEY (admin_prd_cutn_sn)
);

-- Column comments

COMMENT ON COLUMN kids_own.tb_pp_m_dur_dosage.slry_se_cd IS '1:급여, 2:비급여';
COMMENT ON COLUMN kids_own.tb_pp_m_dur_dosage.oper_stts_cd IS 'O:운영,W:적용대기,E:오류';

-- Permissions

ALTER TABLE kids_own.tb_pp_m_dur_dosage OWNER TO postgres;
GRANT ALL ON TABLE kids_own.tb_pp_m_dur_dosage TO postgres;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_dosage TO bo_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_dosage TO bo_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_dosage TO cm_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_dosage TO cm_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_dosage TO co_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_dosage TO co_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_dosage TO cr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_dosage TO cr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_dosage TO dr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_dosage TO dr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_dosage TO ex_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_dosage TO ex_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_dosage TO pp_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_dosage TO pp_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_dosage TO sc_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_dosage TO sc_dev;


-- kids_own.tb_pp_m_dur_eftgrp definition

-- Drop table

-- DROP TABLE kids_own.tb_pp_m_dur_eftgrp;

CREATE TABLE kids_own.tb_pp_m_dur_eftgrp (
	효능군중복일련번호 varchar(50) NOT NULL,
	효능그룹명 varchar(20) NOT NULL,
	group_nm varchar(20) NOT NULL,
	group_nm_1 varchar(20) NOT NULL,
	gnrl_nm_cd bpchar(9) NULL,
	gnrl_nm varchar(100) NULL,
	효능군중복점검코드 bpchar(8) NOT NULL,
	mdcn_cd bpchar(9) NOT NULL,
	item_nm varchar(300) NULL,
	bzenty_nm varchar(100) NULL,
	pbanc_ymd bpchar(8) NULL,
	pbanc_no bpchar(8) NULL,
	slry_se_cd bpchar(1) NULL, -- 1:급여, 2:비급여
	aplcn_ym bpchar(6) NULL,
	oper_stts_cd bpchar(1) NULL, -- O:운영,W:적용대기,E:오류
	rgtr_id varchar(40) NULL,
	reg_dt timestamp NULL,
	mdfr_id varchar(40) NULL,
	mdfcn_dt timestamp NULL,
	CONSTRAINT pk_tb_pp_m_dur_eftgrp PRIMARY KEY ("효능군중복일련번호")
);

-- Column comments

COMMENT ON COLUMN kids_own.tb_pp_m_dur_eftgrp.slry_se_cd IS '1:급여, 2:비급여';
COMMENT ON COLUMN kids_own.tb_pp_m_dur_eftgrp.oper_stts_cd IS 'O:운영,W:적용대기,E:오류';

-- Permissions

ALTER TABLE kids_own.tb_pp_m_dur_eftgrp OWNER TO postgres;
GRANT ALL ON TABLE kids_own.tb_pp_m_dur_eftgrp TO postgres;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_eftgrp TO bo_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_eftgrp TO bo_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_eftgrp TO cm_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_eftgrp TO cm_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_eftgrp TO co_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_eftgrp TO co_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_eftgrp TO cr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_eftgrp TO cr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_eftgrp TO dr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_eftgrp TO dr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_eftgrp TO ex_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_eftgrp TO ex_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_eftgrp TO pp_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_eftgrp TO pp_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_eftgrp TO sc_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_eftgrp TO sc_dev;


-- kids_own.tb_pp_m_dur_nursw definition

-- Drop table

-- DROP TABLE kids_own.tb_pp_m_dur_nursw;

CREATE TABLE kids_own.tb_pp_m_dur_nursw (
	수유부주의일련번호 varchar(50) NOT NULL,
	prdct_cd bpchar(9) NOT NULL,
	igrd_cd varchar(20) NOT NULL,
	igrd_nm varchar(100) NULL,
	prdct_nm varchar(256) NULL,
	bzenty_nm varchar(100) NULL,
	pbanc_ymd bpchar(8) NULL,
	pbanc_no bpchar(8) NULL,
	aplcn_ym bpchar(6) NULL,
	rmrk_cn varchar(4000) NULL,
	slry_se_cd bpchar(1) NULL, -- 품목(I), 성분(C)
	oper_stts_cd bpchar(1) NULL,
	rgtr_id varchar(40) NULL,
	reg_dt timestamp NULL,
	mdfr_id varchar(40) NULL,
	mdfcn_dt timestamp NULL,
	CONSTRAINT pk_tb_pp_m_dur_nursw PRIMARY KEY ("수유부주의일련번호")
);

-- Column comments

COMMENT ON COLUMN kids_own.tb_pp_m_dur_nursw.slry_se_cd IS '품목(I), 성분(C)';

-- Permissions

ALTER TABLE kids_own.tb_pp_m_dur_nursw OWNER TO postgres;
GRANT ALL ON TABLE kids_own.tb_pp_m_dur_nursw TO postgres;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_nursw TO bo_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_nursw TO bo_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_nursw TO cm_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_nursw TO cm_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_nursw TO co_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_nursw TO co_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_nursw TO cr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_nursw TO cr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_nursw TO dr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_nursw TO dr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_nursw TO ex_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_nursw TO ex_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_nursw TO pp_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_nursw TO pp_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_nursw TO sc_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_nursw TO sc_dev;


-- kids_own.tb_pp_m_dur_prgnt_bann definition

-- Drop table

-- DROP TABLE kids_own.tb_pp_m_dur_prgnt_bann;

CREATE TABLE kids_own.tb_pp_m_dur_prgnt_bann (
	임부금기일련번호 varchar(50) NOT NULL,
	igrd_nm varchar(100) NULL,
	igrd_cd varchar(20) NOT NULL,
	prdct_cd bpchar(9) NOT NULL,
	prdct_nm varchar(256) NULL,
	bzenty_nm varchar(100) NULL,
	ancmnt_ymd bpchar(8) NULL,
	ancmnt_no bpchar(8) NULL,
	금기등급수 numeric(2) NULL,
	dtl_info_cn varchar(4000) NULL,
	slry_se_cd bpchar(1) NULL, -- 1:급여, 2:비급여
	aplcn_ym bpchar(6) NULL,
	oper_stts_cd bpchar(1) NULL, -- O:운영,W:적용대기,E:오류
	rgtr_id varchar(40) NULL,
	reg_dt timestamp NULL,
	mdfr_id varchar(40) NULL,
	mdfcn_dt timestamp NULL,
	CONSTRAINT pk_tb_pp_m_dur_prgnt_bann PRIMARY KEY ("임부금기일련번호")
);

-- Column comments

COMMENT ON COLUMN kids_own.tb_pp_m_dur_prgnt_bann.slry_se_cd IS '1:급여, 2:비급여';
COMMENT ON COLUMN kids_own.tb_pp_m_dur_prgnt_bann.oper_stts_cd IS 'O:운영,W:적용대기,E:오류';

-- Permissions

ALTER TABLE kids_own.tb_pp_m_dur_prgnt_bann OWNER TO postgres;
GRANT ALL ON TABLE kids_own.tb_pp_m_dur_prgnt_bann TO postgres;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_prgnt_bann TO bo_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_prgnt_bann TO bo_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_prgnt_bann TO cm_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_prgnt_bann TO cm_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_prgnt_bann TO co_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_prgnt_bann TO co_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_prgnt_bann TO cr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_prgnt_bann TO cr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_prgnt_bann TO dr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_prgnt_bann TO dr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_prgnt_bann TO ex_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_prgnt_bann TO ex_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_prgnt_bann TO pp_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_prgnt_bann TO pp_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_prgnt_bann TO sc_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_prgnt_bann TO sc_dev;


-- kids_own.tb_pp_m_dur_snctz definition

-- Drop table

-- DROP TABLE kids_own.tb_pp_m_dur_snctz;

CREATE TABLE kids_own.tb_pp_m_dur_snctz (
	snctz_cutn_sn varchar(50) NOT NULL,
	prdct_cd bpchar(9) NOT NULL,
	igrd_nm varchar(100) NULL,
	igrd_cd varchar(20) NOT NULL,
	prdct_nm varchar(256) NULL,
	bzenty_nm varchar(100) NULL,
	pbanc_ymd bpchar(8) NULL,
	pbanc_no bpchar(8) NULL,
	mdcn_dtl_cn varchar(4000) NULL,
	aplcn_ym bpchar(6) NULL,
	rmrk_cn varchar(4000) NULL,
	oper_stts_cd bpchar(1) NULL,
	slry_se_cd bpchar(1) NULL,
	rgtr_id varchar(40) NULL,
	reg_dt timestamp NULL,
	mdfr_id varchar(40) NULL,
	mdfcn_dt timestamp NULL,
	CONSTRAINT pk_tb_pp_m_dur_snctz PRIMARY KEY (snctz_cutn_sn)
);

-- Permissions

ALTER TABLE kids_own.tb_pp_m_dur_snctz OWNER TO postgres;
GRANT ALL ON TABLE kids_own.tb_pp_m_dur_snctz TO postgres;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_snctz TO bo_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_snctz TO bo_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_snctz TO cm_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_snctz TO cm_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_snctz TO co_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_snctz TO co_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_snctz TO cr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_snctz TO cr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_snctz TO dr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_snctz TO dr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_snctz TO ex_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_snctz TO ex_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_snctz TO pp_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_snctz TO pp_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_snctz TO sc_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_dur_snctz TO sc_dev;


-- kids_own.tb_pp_m_emp_info definition

-- Drop table

-- DROP TABLE kids_own.tb_pp_m_emp_info;

CREATE TABLE kids_own.tb_pp_m_emp_info (
	emp_no varchar(20) NOT NULL,
	emp_nm varchar(20) NULL,
	dept_no varchar(20) NULL,
	jbgd_nm varchar(20) NULL,
	encpt_emp_telno varchar(256) NULL,
	encpt_emp_eml_nm varchar(256) NULL,
	rgtr_id varchar(40) NULL,
	reg_dt timestamp NULL,
	mdfr_id varchar(40) NULL,
	mdfcn_dt timestamp NULL,
	CONSTRAINT pk_tb_pp_m_emp_info PRIMARY KEY (emp_no)
);

-- Permissions

ALTER TABLE kids_own.tb_pp_m_emp_info OWNER TO postgres;
GRANT ALL ON TABLE kids_own.tb_pp_m_emp_info TO postgres;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_emp_info TO bo_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_emp_info TO bo_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_emp_info TO cm_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_emp_info TO cm_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_emp_info TO co_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_emp_info TO co_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_emp_info TO cr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_emp_info TO cr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_emp_info TO dr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_emp_info TO dr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_emp_info TO ex_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_emp_info TO ex_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_emp_info TO pp_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_emp_info TO pp_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_emp_info TO sc_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_emp_info TO sc_dev;


-- kids_own.tb_pp_m_exprt_authrt definition

-- Drop table

-- DROP TABLE kids_own.tb_pp_m_exprt_authrt;

CREATE TABLE kids_own.tb_pp_m_exprt_authrt (
	mbr_no varchar(10) NOT NULL,
	exprt_task_sn numeric(10) NULL,
	authrt_cd varchar(10) NOT NULL,
	rgtr_id varchar(40) NULL,
	reg_dt timestamp NULL,
	mdfr_id varchar(40) NULL,
	mdfcn_dt timestamp NULL,
	CONSTRAINT pk_tb_pp_m_exprt_authrt PRIMARY KEY (mbr_no, authrt_cd)
);

-- Permissions

ALTER TABLE kids_own.tb_pp_m_exprt_authrt OWNER TO postgres;
GRANT ALL ON TABLE kids_own.tb_pp_m_exprt_authrt TO postgres;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_exprt_authrt TO bo_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_exprt_authrt TO bo_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_exprt_authrt TO cm_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_exprt_authrt TO cm_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_exprt_authrt TO co_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_exprt_authrt TO co_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_exprt_authrt TO cr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_exprt_authrt TO cr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_exprt_authrt TO dr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_exprt_authrt TO dr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_exprt_authrt TO ex_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_exprt_authrt TO ex_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_exprt_authrt TO pp_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_exprt_authrt TO pp_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_exprt_authrt TO sc_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_exprt_authrt TO sc_dev;


-- kids_own.tb_pp_m_exprt_info definition

-- Drop table

-- DROP TABLE kids_own.tb_pp_m_exprt_info;

CREATE TABLE kids_own.tb_pp_m_exprt_info (
	mbr_no varchar(10) NOT NULL,
	brno bpchar(10) NOT NULL,
	task_se_cd varchar(10) NULL,
	encpt_exprt_inst_eml_nm varchar(256) NULL,
	exprt_hdof_yn bpchar(1) NOT NULL,
	exprt_aprv_stts_yn bpchar(1) NOT NULL,
	aprv_prcs_dt timestamp NULL,
	rjct_rsn varchar(4000) NULL,
	atch_file_group_id varchar(40) NULL,
	rgtr_id varchar(40) NULL,
	reg_dt timestamp NULL,
	mdfr_id varchar(40) NULL,
	mdfcn_dt timestamp NULL,
	CONSTRAINT pk_tb_pp_m_exprt_info PRIMARY KEY (mbr_no)
);

-- Permissions

ALTER TABLE kids_own.tb_pp_m_exprt_info OWNER TO postgres;
GRANT ALL ON TABLE kids_own.tb_pp_m_exprt_info TO postgres;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_exprt_info TO bo_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_exprt_info TO bo_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_exprt_info TO cm_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_exprt_info TO cm_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_exprt_info TO co_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_exprt_info TO co_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_exprt_info TO cr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_exprt_info TO cr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_exprt_info TO dr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_exprt_info TO dr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_exprt_info TO ex_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_exprt_info TO ex_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_exprt_info TO pp_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_exprt_info TO pp_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_exprt_info TO sc_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_exprt_info TO sc_dev;


-- kids_own.tb_pp_m_exprt_task definition

-- Drop table

-- DROP TABLE kids_own.tb_pp_m_exprt_task;

CREATE TABLE kids_own.tb_pp_m_exprt_task (
	exprt_task_sn numeric(10) NOT NULL,
	mbr_no varchar(10) NULL,
	brno bpchar(10) NOT NULL,
	task_se_cd varchar(10) NOT NULL,
	exprt_aprv_stts_yn bpchar(1) NOT NULL,
	aprv_prcs_dt timestamp NULL,
	rjct_rsn varchar(4000) NULL,
	wrtr_dept_nm varchar(40) NULL,
	mdfr_dept_nm varchar(40) NULL,
	rgtr_id varchar(40) NULL,
	reg_dt timestamp NULL,
	mdfr_id varchar(40) NULL,
	mdfcn_dt timestamp NULL,
	CONSTRAINT pk_tb_pp_m_exprt_task PRIMARY KEY (exprt_task_sn)
);

-- Permissions

ALTER TABLE kids_own.tb_pp_m_exprt_task OWNER TO postgres;
GRANT ALL ON TABLE kids_own.tb_pp_m_exprt_task TO postgres;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_exprt_task TO bo_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_exprt_task TO bo_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_exprt_task TO cm_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_exprt_task TO cm_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_exprt_task TO co_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_exprt_task TO co_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_exprt_task TO cr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_exprt_task TO cr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_exprt_task TO dr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_exprt_task TO dr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_exprt_task TO ex_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_exprt_task TO ex_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_exprt_task TO pp_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_exprt_task TO pp_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_exprt_task TO sc_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_exprt_task TO sc_dev;


-- kids_own.tb_pp_m_faq definition

-- Drop table

-- DROP TABLE kids_own.tb_pp_m_faq;

CREATE TABLE kids_own.tb_pp_m_faq (
	faq_sn numeric(10) NOT NULL,
	task_se_cd bpchar(3) NOT NULL,
	faq_clsf_nm varchar(80) NULL,
	faq_ttl varchar(256) NULL,
	faq_seq numeric(10) NOT NULL,
	use_yn bpchar(1) NOT NULL,
	lang_se_cd bpchar(2) NOT NULL,
	faq_ans_cn varchar(4000) NULL,
	atch_file_group_id varchar(40) NULL,
	wrtr_dept_nm varchar(40) NULL,
	mdfr_dept_nm varchar(40) NULL,
	rgtr_id varchar(40) NULL,
	reg_dt timestamp NULL,
	mdfr_id varchar(40) NULL,
	mdfcn_dt timestamp NULL,
	CONSTRAINT pk_tb_pp_m_faq PRIMARY KEY (faq_sn)
);

-- Permissions

ALTER TABLE kids_own.tb_pp_m_faq OWNER TO postgres;
GRANT ALL ON TABLE kids_own.tb_pp_m_faq TO postgres;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_faq TO bo_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_faq TO bo_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_faq TO cm_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_faq TO cm_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_faq TO co_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_faq TO co_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_faq TO cr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_faq TO cr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_faq TO dr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_faq TO dr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_faq TO ex_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_faq TO ex_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_faq TO pp_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_faq TO pp_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_faq TO sc_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_faq TO sc_dev;


-- kids_own.tb_pp_m_file definition

-- Drop table

-- DROP TABLE kids_own.tb_pp_m_file;

CREATE TABLE kids_own.tb_pp_m_file (
	file_sn numeric(10) NOT NULL,
	atch_file_id varchar(40) NULL,
	file_type_cd bpchar(1) NULL,
	file_knd_cd varchar(20) NULL,
	file_ttl_nm varchar(200) NULL,
	rgtr_id varchar(40) NULL,
	reg_dt timestamp NULL,
	mdfr_id varchar(40) NULL,
	mdfcn_dt timestamp NULL,
	CONSTRAINT pk_tb_pp_m_file PRIMARY KEY (file_sn)
);

-- Permissions

ALTER TABLE kids_own.tb_pp_m_file OWNER TO postgres;
GRANT ALL ON TABLE kids_own.tb_pp_m_file TO postgres;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_file TO bo_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_file TO bo_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_file TO cm_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_file TO cm_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_file TO co_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_file TO co_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_file TO cr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_file TO cr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_file TO dr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_file TO dr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_file TO ex_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_file TO ex_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_file TO pp_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_file TO pp_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_file TO sc_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_file TO sc_dev;


-- kids_own.tb_pp_m_form definition

-- Drop table

-- DROP TABLE kids_own.tb_pp_m_form;

CREATE TABLE kids_own.tb_pp_m_form (
	form_sn numeric(22) NOT NULL,
	task_cd varchar(20) NULL,
	form_nm varchar(40) NULL,
	form_path_nm varchar(256) NULL,
	use_yn bpchar(1) NOT NULL,
	rgtr_id varchar(40) NULL,
	reg_dt timestamp NULL,
	mdfr_id varchar(40) NULL,
	mdfcn_dt timestamp NULL,
	CONSTRAINT pk_tb_pp_m_form PRIMARY KEY (form_sn)
);

-- Permissions

ALTER TABLE kids_own.tb_pp_m_form OWNER TO postgres;
GRANT ALL ON TABLE kids_own.tb_pp_m_form TO postgres;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_form TO bo_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_form TO bo_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_form TO cm_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_form TO cm_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_form TO co_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_form TO co_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_form TO cr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_form TO cr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_form TO dr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_form TO dr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_form TO ex_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_form TO ex_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_form TO pp_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_form TO pp_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_form TO sc_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_form TO sc_dev;


-- kids_own.tb_pp_m_inst definition

-- Drop table

-- DROP TABLE kids_own.tb_pp_m_inst;

CREATE TABLE kids_own.tb_pp_m_inst (
	brno bpchar(10) NOT NULL,
	inst_nm varchar(200) NOT NULL,
	del_yn bpchar(1) NOT NULL,
	rgtr_id varchar(40) NULL,
	reg_dt timestamp NULL,
	mdfr_id varchar(40) NULL,
	mdfcn_dt timestamp NULL,
	CONSTRAINT pk_tb_pp_m_inst PRIMARY KEY (brno)
);

-- Permissions

ALTER TABLE kids_own.tb_pp_m_inst OWNER TO postgres;
GRANT ALL ON TABLE kids_own.tb_pp_m_inst TO postgres;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_inst TO bo_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_inst TO bo_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_inst TO cm_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_inst TO cm_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_inst TO co_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_inst TO co_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_inst TO cr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_inst TO cr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_inst TO dr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_inst TO dr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_inst TO ex_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_inst TO ex_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_inst TO pp_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_inst TO pp_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_inst TO sc_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_inst TO sc_dev;


-- kids_own.tb_pp_m_inst_task definition

-- Drop table

-- DROP TABLE kids_own.tb_pp_m_inst_task;

CREATE TABLE kids_own.tb_pp_m_inst_task (
	brno bpchar(10) NOT NULL,
	task_se_cd varchar(10) NOT NULL,
	mbr_no varchar(10) NULL,
	use_yn bpchar(1) NOT NULL,
	rgtr_id varchar(40) NULL,
	reg_dt timestamp NULL,
	mdfr_id varchar(40) NULL,
	mdfcn_dt timestamp NULL,
	CONSTRAINT pk_tb_pp_m_inst_task PRIMARY KEY (brno, task_se_cd)
);

-- Permissions

ALTER TABLE kids_own.tb_pp_m_inst_task OWNER TO postgres;
GRANT ALL ON TABLE kids_own.tb_pp_m_inst_task TO postgres;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_inst_task TO bo_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_inst_task TO bo_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_inst_task TO cm_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_inst_task TO cm_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_inst_task TO co_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_inst_task TO co_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_inst_task TO cr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_inst_task TO cr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_inst_task TO dr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_inst_task TO dr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_inst_task TO ex_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_inst_task TO ex_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_inst_task TO pp_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_inst_task TO pp_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_inst_task TO sc_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_inst_task TO sc_dev;


-- kids_own.tb_pp_m_mbr_info definition

-- Drop table

-- DROP TABLE kids_own.tb_pp_m_mbr_info;

CREATE TABLE kids_own.tb_pp_m_mbr_info (
	mbr_no varchar(10) NOT NULL,
	mbr_id varchar(40) NOT NULL,
	encpt_mbr_flnm varchar(256) NOT NULL,
	encpt_mbr_eml_nm varchar(256) NULL,
	encpt_mbr_pswd varchar(256) NOT NULL,
	encpt_mbr_telno varchar(256) NULL,
	mbr_type_cd bpchar(1) NOT NULL,
	mbr_join_stts_cd bpchar(1) NOT NULL,
	mbr_join_dt timestamp NOT NULL,
	mbr_whdwl_rsn varchar(4000) NULL,
	mbr_whdwl_dt timestamp NULL,
	cnstn_mbcmt_yn bpchar(1) NULL,
	bfr_enpswd varchar(256) NULL,
	pswd_chg_dt timestamp NULL,
	pswd_err_nmtm numeric(2) NULL,
	link_info_idntf_id varchar(100) NULL,
	cert_token_vl varchar(40) NULL,
	rgtr_id varchar(40) NULL,
	reg_dt timestamp NULL,
	mdfr_id varchar(40) NULL,
	mdfcn_dt timestamp NULL,
	CONSTRAINT pk_tb_pp_m_mbr_info PRIMARY KEY (mbr_no)
);

-- Permissions

ALTER TABLE kids_own.tb_pp_m_mbr_info OWNER TO postgres;
GRANT ALL ON TABLE kids_own.tb_pp_m_mbr_info TO postgres;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_mbr_info TO bo_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_mbr_info TO bo_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_mbr_info TO cm_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_mbr_info TO cm_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_mbr_info TO co_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_mbr_info TO co_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_mbr_info TO cr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_mbr_info TO cr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_mbr_info TO dr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_mbr_info TO dr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_mbr_info TO ex_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_mbr_info TO ex_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_mbr_info TO pp_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_mbr_info TO pp_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_mbr_info TO sc_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_mbr_info TO sc_dev;


-- kids_own.tb_pp_m_menu definition

-- Drop table

-- DROP TABLE kids_own.tb_pp_m_menu;

CREATE TABLE kids_own.tb_pp_m_menu (
	menu_sn varchar(20) NOT NULL,
	menu_nm varchar(100) NULL,
	up_menu_sn varchar(20) NULL,
	task_se_cd varchar(10) NOT NULL,
	menu_type_cd varchar(20) NOT NULL,
	lang_se_cd bpchar(3) NOT NULL,
	menu_seq numeric(10) NOT NULL,
	menu_expln varchar(4000) NULL,
	pic_dept_nm varchar(40) NULL,
	pic_flnm varchar(20) NULL,
	use_yn bpchar(1) NOT NULL,
	rgtr_id varchar(40) NULL,
	reg_dt timestamp NULL,
	mdfr_id varchar(40) NULL,
	mdfcn_dt timestamp NULL,
	CONSTRAINT pk_tb_pp_m_menu PRIMARY KEY (menu_sn)
);

-- Permissions

ALTER TABLE kids_own.tb_pp_m_menu OWNER TO postgres;
GRANT ALL ON TABLE kids_own.tb_pp_m_menu TO postgres;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_menu TO bo_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_menu TO bo_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_menu TO cm_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_menu TO cm_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_menu TO co_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_menu TO co_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_menu TO cr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_menu TO cr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_menu TO dr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_menu TO dr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_menu TO ex_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_menu TO ex_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_menu TO pp_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_menu TO pp_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_menu TO sc_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_menu TO sc_dev;


-- kids_own.tb_pp_m_mngr_info definition

-- Drop table

-- DROP TABLE kids_own.tb_pp_m_mngr_info;

CREATE TABLE kids_own.tb_pp_m_mngr_info (
	emp_no varchar(20) NOT NULL,
	encpt_mngr_pswd varchar(256) NULL,
	tmpr_pswd_yn bpchar(1) NOT NULL,
	pswd_err_nmtm numeric(2) NOT NULL,
	encpt_bfr_pswd varchar(256) NULL,
	rgtr_id varchar(40) NULL,
	reg_dt timestamp NULL,
	mdfr_id varchar(40) NULL,
	mdfcn_dt timestamp NULL,
	CONSTRAINT pk_tb_pp_m_mngr_info PRIMARY KEY (emp_no)
);

-- Permissions

ALTER TABLE kids_own.tb_pp_m_mngr_info OWNER TO postgres;
GRANT ALL ON TABLE kids_own.tb_pp_m_mngr_info TO postgres;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_mngr_info TO bo_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_mngr_info TO bo_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_mngr_info TO cm_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_mngr_info TO cm_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_mngr_info TO co_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_mngr_info TO co_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_mngr_info TO cr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_mngr_info TO cr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_mngr_info TO dr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_mngr_info TO dr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_mngr_info TO ex_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_mngr_info TO ex_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_mngr_info TO pp_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_mngr_info TO pp_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_mngr_info TO sc_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_mngr_info TO sc_dev;


-- kids_own.tb_pp_m_opnn definition

-- Drop table

-- DROP TABLE kids_own.tb_pp_m_opnn;

CREATE TABLE kids_own.tb_pp_m_opnn (
	opnn_sn numeric(22) NOT NULL,
	encpt_wrtr_flnm varchar(256) NULL,
	encpt_wrtr_telno varchar(256) NULL,
	encpt_mbr_eml_nm varchar(256) NULL,
	wrt_se_cd bpchar(3) NOT NULL, -- 의사,약사,간호사,소비자,기타
	pbpt_cn varchar(4000) NULL,
	dmnd_mttr_cn varchar(4000) NULL,
	dmnd_mttr_dtl_cn text NULL,
	ref_mttr_cn varchar(4000) NULL,
	insd_ref_mttr_cn text NULL,
	atch_file_group_id varchar(40) NULL,
	rgtr_id varchar(40) NULL,
	reg_dt timestamp NULL,
	mdfr_id varchar(40) NULL,
	mdfcn_dt timestamp NULL,
	CONSTRAINT pk_tb_pp_m_opnn PRIMARY KEY (opnn_sn)
);

-- Column comments

COMMENT ON COLUMN kids_own.tb_pp_m_opnn.wrt_se_cd IS '의사,약사,간호사,소비자,기타';

-- Permissions

ALTER TABLE kids_own.tb_pp_m_opnn OWNER TO postgres;
GRANT ALL ON TABLE kids_own.tb_pp_m_opnn TO postgres;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_opnn TO bo_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_opnn TO bo_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_opnn TO cm_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_opnn TO cm_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_opnn TO co_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_opnn TO co_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_opnn TO cr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_opnn TO cr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_opnn TO dr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_opnn TO dr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_opnn TO ex_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_opnn TO ex_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_opnn TO pp_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_opnn TO pp_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_opnn TO sc_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_opnn TO sc_dev;


-- kids_own.tb_pp_m_pic_authrt definition

-- Drop table

-- DROP TABLE kids_own.tb_pp_m_pic_authrt;

CREATE TABLE kids_own.tb_pp_m_pic_authrt (
	emp_no varchar(20) NOT NULL,
	authrt_cd varchar(10) NOT NULL,
	pic_authrt_rmrk_cn varchar(1000) NULL,
	rgtr_id varchar(40) NULL,
	reg_dt timestamp NULL,
	mdfr_id varchar(40) NULL,
	mdfcn_dt timestamp NULL,
	CONSTRAINT pk_tb_pp_m_pic_authrt PRIMARY KEY (emp_no, authrt_cd)
);

-- Permissions

ALTER TABLE kids_own.tb_pp_m_pic_authrt OWNER TO postgres;
GRANT ALL ON TABLE kids_own.tb_pp_m_pic_authrt TO postgres;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_pic_authrt TO bo_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_pic_authrt TO bo_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_pic_authrt TO cm_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_pic_authrt TO cm_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_pic_authrt TO co_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_pic_authrt TO co_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_pic_authrt TO cr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_pic_authrt TO cr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_pic_authrt TO dr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_pic_authrt TO dr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_pic_authrt TO ex_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_pic_authrt TO ex_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_pic_authrt TO pp_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_pic_authrt TO pp_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_pic_authrt TO sc_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_pic_authrt TO sc_dev;


-- kids_own.tb_pp_m_popup definition

-- Drop table

-- DROP TABLE kids_own.tb_pp_m_popup;

CREATE TABLE kids_own.tb_pp_m_popup (
	popup_sn numeric(10) NOT NULL,
	popup_ttl varchar(100) NULL,
	popup_pstg_bgng_dt timestamp NOT NULL,
	popup_pstg_end_dt timestamp NOT NULL,
	popup_lnkg_addr varchar(320) NULL,
	popup_seq numeric(10) NOT NULL,
	popup_pstg_yn bpchar(1) NOT NULL,
	popup_npag_yn bpchar(1) NOT NULL,
	popup_expln varchar(4000) NULL,
	atch_file_group_id varchar(40) NULL,
	wrtr_dept_nm varchar(40) NULL,
	mdfr_dept_nm varchar(40) NULL,
	rgtr_id varchar(40) NULL,
	reg_dt timestamp NULL,
	mdfr_id varchar(40) NULL,
	mdfcn_dt timestamp NULL,
	CONSTRAINT pk_tb_pp_m_popup PRIMARY KEY (popup_sn)
);

-- Permissions

ALTER TABLE kids_own.tb_pp_m_popup OWNER TO postgres;
GRANT ALL ON TABLE kids_own.tb_pp_m_popup TO postgres;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_popup TO bo_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_popup TO bo_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_popup TO cm_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_popup TO cm_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_popup TO co_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_popup TO co_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_popup TO cr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_popup TO cr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_popup TO dr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_popup TO dr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_popup TO ex_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_popup TO ex_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_popup TO pp_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_popup TO pp_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_popup TO sc_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_popup TO sc_dev;


-- kids_own.tb_pp_m_prvc_acs_hstry definition

-- Drop table

-- DROP TABLE kids_own.tb_pp_m_prvc_acs_hstry;

CREATE TABLE kids_own.tb_pp_m_prvc_acs_hstry (
	prvc_acs_sn numeric(10) NOT NULL,
	inq_crtr_dt timestamp NOT NULL,
	srvc_cd bpchar(2) NOT NULL,
	menu_sn varchar(20) NULL,
	메소드명 varchar(100) NOT NULL,
	inq_info_cn varchar(1000) NOT NULL,
	rqstr_id varchar(40) NOT NULL,
	rqstr_ip_addr varchar(255) NULL,
	inq_cnd_cn varchar(4000) NOT NULL,
	inq_telgm_cn text NOT NULL,
	rgtr_id varchar(40) NULL,
	reg_dt timestamp NULL,
	mdfr_id varchar(40) NULL,
	mdfcn_dt timestamp NULL,
	CONSTRAINT pk_tb_pp_m_prvc_acs_hstry PRIMARY KEY (prvc_acs_sn)
);

-- Permissions

ALTER TABLE kids_own.tb_pp_m_prvc_acs_hstry OWNER TO postgres;
GRANT ALL ON TABLE kids_own.tb_pp_m_prvc_acs_hstry TO postgres;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_prvc_acs_hstry TO bo_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_prvc_acs_hstry TO bo_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_prvc_acs_hstry TO cm_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_prvc_acs_hstry TO cm_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_prvc_acs_hstry TO co_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_prvc_acs_hstry TO co_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_prvc_acs_hstry TO cr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_prvc_acs_hstry TO cr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_prvc_acs_hstry TO dr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_prvc_acs_hstry TO dr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_prvc_acs_hstry TO ex_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_prvc_acs_hstry TO ex_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_prvc_acs_hstry TO pp_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_prvc_acs_hstry TO pp_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_prvc_acs_hstry TO sc_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_prvc_acs_hstry TO sc_dev;


-- kids_own.tb_pp_m_pst definition

-- Drop table

-- DROP TABLE kids_own.tb_pp_m_pst;

CREATE TABLE kids_own.tb_pp_m_pst (
	pst_sn numeric(22) NOT NULL,
	bbs_id varchar(20) NOT NULL,
	pst_ttl varchar(100) NULL,
	pst_cn text NULL,
	pst_inq_cnt numeric(10) NOT NULL,
	pst_kogl_cprgt_type_cd bpchar(1) NULL,
	atch_file_group_id varchar(40) NULL,
	thmb_id varchar(40) NULL,
	fix_yn bpchar(1) NOT NULL,
	fix_bgng_ymd bpchar(8) NULL,
	fix_end_ymd bpchar(8) NULL,
	vdo_url_addr varchar(200) NULL,
	expsr_yn bpchar(1) NOT NULL,
	wrtr_dept_nm varchar(80) NULL,
	mdfr_dept_nm varchar(80) NULL,
	rgtr_id varchar(40) NULL,
	reg_dt timestamp NULL,
	mdfr_id varchar(40) NULL,
	mdfcn_dt timestamp NULL,
	CONSTRAINT pk_tb_pp_m_pst PRIMARY KEY (pst_sn)
);

-- Permissions

ALTER TABLE kids_own.tb_pp_m_pst OWNER TO postgres;
GRANT ALL ON TABLE kids_own.tb_pp_m_pst TO postgres;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_pst TO bo_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_pst TO bo_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_pst TO cm_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_pst TO cm_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_pst TO co_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_pst TO co_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_pst TO cr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_pst TO cr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_pst TO dr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_pst TO dr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_pst TO ex_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_pst TO ex_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_pst TO pp_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_pst TO pp_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_pst TO sc_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_pst TO sc_dev;


-- kids_own.tb_pp_m_role definition

-- Drop table

-- DROP TABLE kids_own.tb_pp_m_role;

CREATE TABLE kids_own.tb_pp_m_role (
	role_cd varchar(20) NOT NULL,
	role_nm varchar(40) NULL,
	role_type_cd varchar(20) NULL,
	role_expln_cn varchar(4000) NULL,
	use_yn bpchar(1) NOT NULL,
	wrtr_dept_nm varchar(40) NULL,
	mdfr_dept_nm varchar(40) NULL,
	rgtr_id varchar(40) NULL,
	reg_dt timestamp NULL,
	mdfr_id varchar(40) NULL,
	mdfcn_dt timestamp NULL,
	CONSTRAINT pk_tb_pp_m_role PRIMARY KEY (role_cd)
);

-- Permissions

ALTER TABLE kids_own.tb_pp_m_role OWNER TO postgres;
GRANT ALL ON TABLE kids_own.tb_pp_m_role TO postgres;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_role TO bo_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_role TO bo_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_role TO cm_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_role TO cm_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_role TO co_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_role TO co_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_role TO cr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_role TO cr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_role TO dr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_role TO dr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_role TO ex_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_role TO ex_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_role TO pp_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_role TO pp_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_role TO sc_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_role TO sc_dev;


-- kids_own.tb_pp_m_stty_agt_info definition

-- Drop table

-- DROP TABLE kids_own.tb_pp_m_stty_agt_info;

CREATE TABLE kids_own.tb_pp_m_stty_agt_info (
	mbr_no varchar(10) NOT NULL,
	stty_agt_nm varchar(20) NULL,
	encpt_stty_agt_telno varchar(256) NULL,
	stty_agt_rel_nm varchar(20) NULL,
	link_info_idntf_id varchar(100) NULL,
	cert_token_vl varchar(40) NULL,
	rgtr_id varchar(40) NULL,
	reg_dt timestamp NULL,
	mdfr_id varchar(40) NULL,
	mdfcn_dt timestamp NULL,
	CONSTRAINT pk_tb_pp_m_stty_agt_info PRIMARY KEY (mbr_no)
);

-- Permissions

ALTER TABLE kids_own.tb_pp_m_stty_agt_info OWNER TO postgres;
GRANT ALL ON TABLE kids_own.tb_pp_m_stty_agt_info TO postgres;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_stty_agt_info TO bo_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_stty_agt_info TO bo_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_stty_agt_info TO cm_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_stty_agt_info TO cm_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_stty_agt_info TO co_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_stty_agt_info TO co_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_stty_agt_info TO cr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_stty_agt_info TO cr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_stty_agt_info TO dr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_stty_agt_info TO dr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_stty_agt_info TO ex_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_stty_agt_info TO ex_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_stty_agt_info TO pp_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_stty_agt_info TO pp_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_stty_agt_info TO sc_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_stty_agt_info TO sc_dev;


-- kids_own.tb_pp_m_task_cd definition

-- Drop table

-- DROP TABLE kids_own.tb_pp_m_task_cd;

CREATE TABLE kids_own.tb_pp_m_task_cd (
	task_cd varchar(20) NOT NULL,
	task_cd_nm varchar(200) NULL,
	up_task_cd varchar(20) NULL,
	task_cd_vl varchar(100) NULL,
	task_cd_expln varchar(4000) NULL,
	use_yn bpchar(1) NOT NULL,
	rgtr_id varchar(40) NULL,
	reg_dt timestamp NULL,
	mdfr_id varchar(40) NULL,
	mdfcn_dt timestamp NULL,
	CONSTRAINT pk_tb_pp_m_task_cd PRIMARY KEY (task_cd)
);

-- Permissions

ALTER TABLE kids_own.tb_pp_m_task_cd OWNER TO postgres;
GRANT ALL ON TABLE kids_own.tb_pp_m_task_cd TO postgres;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_task_cd TO bo_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_task_cd TO bo_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_task_cd TO cm_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_task_cd TO cm_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_task_cd TO co_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_task_cd TO co_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_task_cd TO cr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_task_cd TO cr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_task_cd TO dr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_task_cd TO dr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_task_cd TO ex_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_task_cd TO ex_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_task_cd TO pp_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_task_cd TO pp_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_task_cd TO sc_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_task_cd TO sc_dev;


-- kids_own.tb_pp_m_trm definition

-- Drop table

-- DROP TABLE kids_own.tb_pp_m_trm;

CREATE TABLE kids_own.tb_pp_m_trm (
	std_trm_nm varchar(100) NOT NULL,
	sys_se_nm varchar(40) NULL,
	artcl_sou_nm varchar(40) NULL,
	std_trm_eng_abbr_nm varchar(40) NULL,
	atrb_type_nm varchar(40) NULL,
	com_std_dmn_nm varchar(100) NULL,
	rgtr_id varchar(40) NULL,
	reg_dt timestamp NULL,
	mdfr_id varchar(40) NULL,
	mdfcn_dt timestamp NULL,
	CONSTRAINT pk_tb_pp_m_trm PRIMARY KEY (std_trm_nm)
);

-- Permissions

ALTER TABLE kids_own.tb_pp_m_trm OWNER TO postgres;
GRANT ALL ON TABLE kids_own.tb_pp_m_trm TO postgres;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_trm TO bo_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_trm TO bo_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_trm TO cm_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_trm TO cm_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_trm TO co_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_trm TO co_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_trm TO cr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_trm TO cr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_trm TO dr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_trm TO dr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_trm TO ex_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_trm TO ex_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_trm TO pp_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_trm TO pp_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_trm TO sc_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_trm TO sc_dev;


-- kids_own.tb_pp_m_trms_stt definition

-- Drop table

-- DROP TABLE kids_own.tb_pp_m_trms_stt;

CREATE TABLE kids_own.tb_pp_m_trms_stt (
	trms_stt_sn numeric(10) NOT NULL,
	trms_stt_cd varchar(20) NOT NULL,
	trms_stt_aplcn_ymd bpchar(8) NOT NULL,
	trms_stt_end_ymd bpchar(8) NULL,
	trms_stt_cn varchar(4000) NULL,
	atch_file_group_id varchar(40) NULL,
	wrtr_dept_nm varchar(40) NULL,
	mdfr_dept_nm varchar(40) NULL,
	rgtr_id varchar(40) NULL,
	reg_dt timestamp NULL,
	mdfr_id varchar(40) NULL,
	mdfcn_dt timestamp NULL,
	CONSTRAINT pk_tb_pp_m_trms_stt PRIMARY KEY (trms_stt_sn)
);

-- Permissions

ALTER TABLE kids_own.tb_pp_m_trms_stt OWNER TO postgres;
GRANT ALL ON TABLE kids_own.tb_pp_m_trms_stt TO postgres;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_trms_stt TO bo_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_trms_stt TO bo_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_trms_stt TO cm_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_trms_stt TO cm_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_trms_stt TO co_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_trms_stt TO co_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_trms_stt TO cr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_trms_stt TO cr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_trms_stt TO dr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_trms_stt TO dr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_trms_stt TO ex_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_trms_stt TO ex_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_trms_stt TO pp_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_trms_stt TO pp_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_trms_stt TO sc_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_trms_stt TO sc_dev;


-- kids_own.tb_pp_m_word definition

-- Drop table

-- DROP TABLE kids_own.tb_pp_m_word;

CREATE TABLE kids_own.tb_pp_m_word (
	com_std_word_nm varchar(100) NOT NULL,
	sys_se_nm varchar(40) NULL,
	artcl_sou_nm varchar(40) NULL,
	com_std_word_eng_abbr_nm varchar(40) NULL,
	com_std_word_eng_nm varchar(256) NULL,
	com_std_word_expln varchar(4000) NULL,
	frm_word_yn bpchar(1) NULL,
	rgtr_id varchar(40) NULL,
	reg_dt timestamp NULL,
	mdfr_id varchar(40) NULL,
	mdfcn_dt timestamp NULL,
	CONSTRAINT pk_tb_pp_m_word PRIMARY KEY (com_std_word_nm)
);

-- Permissions

ALTER TABLE kids_own.tb_pp_m_word OWNER TO postgres;
GRANT ALL ON TABLE kids_own.tb_pp_m_word TO postgres;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_word TO bo_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_word TO bo_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_word TO cm_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_word TO cm_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_word TO co_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_word TO co_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_word TO cr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_word TO cr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_word TO dr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_word TO dr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_word TO ex_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_word TO ex_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_word TO pp_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_word TO pp_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_word TO sc_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_pp_m_word TO sc_dev;