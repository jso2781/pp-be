INSERT INTO kids_own.tb_pp_m_pst (pst_sn,bbs_id,pst_ttl,pst_cn,pst_inq_cnt,pst_kogl_cprgt_type_cd,atch_file_group_id,thmb_id,fix_yn,fix_bgng_ymd,fix_end_ymd,vdo_url_addr,expsr_yn,wrtr_dept_nm,mdfr_dept_nm,rgtr_id,reg_dt,mdfr_id,mdfcn_dt) VALUES
	 (999,'999','테스트 게시물 1','<!DOCTYPE HTML>
<html lang="ko">
<head>
    <title>KIDS 관리자</title>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=2.0, minimum-scale=1.0, user-scalable=no">
    <meta name="keywords" content="">
    <meta name="decription" content="">
    <meta name="author" content="">
    <link rel="icon" type="image/x-icon" href="../img/kids.ico">
    
    <!-- js -->
    <script type="text/javascript" src="../js/jquery-3.7.1.min.js"></script>
    <script type="text/javascript" src="../js/jquery-ui.min.js"></script>
    <script type="text/javascript" src="../js/bootstrap.min.js"></script>
    
    <!-- datepicker,datetimepicker -->
    <script type="text/javascript" src="../js/datepicker.js"></script>
    <script type="text/javascript" src="../js/jquery.datetimepicker.full.min.js"></script>
    <link rel="stylesheet" href="../css/jquery.datetimepicker.min.css" />
    
    <!-- select2 -->
    <script type="text/javascript" src="../js/select2.min.js"></script>
    <link rel="stylesheet" type="text/css" href="../css/select2.min.css">
    
    <!-- ui js -->
    <script type="text/javascript" src="../js/commonUI.js"></script>
    
    <!-- css -->
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" media="all">
    <link rel="stylesheet" type="text/css" href="../css/style.css">

</head>
<body>

    <div id="wrap">
        <!-- S T A R T :: header -->
        <div id="header">
            <div class="inner">
                <h1 class="logo">
                    <a href="javascript:void(0);">
                        <img src="../img/logo.png" alt="한국의약품안전관리원">
                        <span class="logo_text">통합관리시스템</span>
                    </a>
                </h1>
                <div class="sidebar_controller">
                    <button type="button" class="btn_sidebar"><span class="blind">메뉴바</span></button>
                </div>
                <div class="util_group">
                    <div class="user_info">
                        <p class="user_name"><span>admin</span>님</p>
                        <p class="access">2025-10-21 09:03 접속</p>
                        <div class="notification">
                            <button class="btn_notify">
                                <span class="ico_bell"><span class="blind">알림</span></span>
                                <span class="notify_count">3</span>
                            </button>
                            <div class="notify_box">
                                <p>새 알림 1</p>
                                <p>새 알림 2</p>
                                <p>새 알림 3</p>
                            </div>
                        </div>
                        <button type="button" class="btn_logout">로그아웃</button>
                    </div>
                </div>
            </div>
            <!-- //inner -->
        </div>
        <!-- E N D :: header -->

        <!-- S T A R T :: container -->
        <div id="container" class="sub_container">
            <!-- aside :: s -->
            <div class="aside">
                <div class="aside_inner">
                    <div id="lnb">
                        <ul class="lnb_list">
                            <li><a href="javascript:void(0);">대국민 서비스 포털 관리</a>
                                <ul>
                                    <li><a href="javascript:void(0);">전체메뉴 </a>
                                        <ul>
                                            <li><a href="javascript:void(0);">메뉴1_1_1</a></li>
                                            <li><a href="javascript:void(0);">메뉴1_1_2</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="javascript:void(0);">회원 관리</a></li>
                                    <li><a href="javascript:void(0);">게시판 관리</a></li>
                                    <li><a href="javascript:void(0);">게시물 관리</a></li>
                                    <li><a href="javascript:void(0);">뉴스레터/설문 관리</a></li>
                                    <li><a href="javascript:void(0);">교육 관리</a></li>
                                    <li><a href="javascript:void(0);">사이트 관리</a></li>
                                    <li><a href="javascript:void(0);">원시자료관리</a></li>
                                    <li><a href="javascript:void(0);">충실도 정보관리</a></li>
                                    <li><a href="javascript:void(0);">접속기록 관리</a></li>
                                    <li><a href="javascript:void(0);">DUR 정보관리</a></li>
                                </ul>
                            </li>
                            <li><a href="javascript:void(0);">의약품 안전 통합 교육 플랫폼</a></li>
                            <li><a href="javascript:void(0);">의약품 안전 통합 상담시스템</a>
                                <ul>
                                    <li><a href="javascript:void(0);">LNB 메뉴3_1</a></li>
                                    <li><a href="javascript:void(0);">LNB 메뉴3_2</a></li>
                                    <li><a href="javascript:void(0);">LNB 메뉴4_3</a></li>
                                </ul>
                            </li>
                            <li><a href="javascript:void(0);">안전 정보 관리 업무 지원 시스템</a>
                                <ul>
                                    <li><a href="javascript:void(0);">LNB 메뉴4_1</a></li>
                                    <li><a href="javascript:void(0);">LNB 메뉴4_2</a></li>
                                    <li><a href="javascript:void(0);">LNB 메뉴4_3</a></li>
                                </ul>
                            </li>
                            <li><a href="javascript:void(0);">약물 부작용 포털 및 업무 지원 </a></li>
                            <li><a href="javascript:void(0);">지능형 의약품 안전정보 통합분석</a></li>
                            <li><a href="javascript:void(0);">전문가 관리 시스템</a></li>
                            <li><a href="javascript:void(0);">설문 시스템</a></li>
                            <li><a href="javascript:void(0);">전자문서고</a></li>
                        </ul>
                    </div>
                    <!-- //lnb -->
                </div>
                <!-- //aside_inner -->
            </div>
            <!-- aside :: e -->

            <!-- content_wrap :: s -->
            <div class="content_wrap">
                <div class="location">
                    <div class="page_path">
                        <h2 class="tit">타이틀</h2>
                    </div>
                    <div class="local">
                        <span class="home"><span class="blind">홈</span></span>
                        <span class="route">뎁스1</span>
                        <span class="current">뎁스2</span>
                    </div>
                </div>
                <div class="content">
                <!-- 내용시작 -->
                 
                    컨텐츠
                  
                <!-- //내용시작 -->    
                </div>
                <!-- //content -->
            </div>
            <!-- content_wrap :: e -->
        </div>
        <!-- E N D :: container -->
    </div>
    <!--//wrap -->

</body>
</html>',0,'1',NULL,NULL,'Y','20260128','20260211',NULL,'Y',NULL,'',NULL,'2026-01-28 04:33:30.851883',NULL,'2026-01-28 04:33:30.851883');
