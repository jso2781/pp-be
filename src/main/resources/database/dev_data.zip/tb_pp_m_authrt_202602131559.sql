INSERT INTO kids_own.tb_pp_m_authrt (authrt_cd,up_authrt_cd,task_se_cd,authrt_nm,authrt_type_cd,authrt_expln,use_yn,wrtr_dept_nm,mdfr_dept_nm,rgtr_id,reg_dt,mdfr_id,mdfcn_dt) VALUES
	 ('YG_MNG','HOME_MNG','PP','약관법령 관리',NULL,NULL,'Y',NULL,NULL,NULL,NULL,NULL,NULL),
	 ('MAIN_MNG','HOME_MNG','PP','메인 관리',NULL,NULL,'Y',NULL,NULL,NULL,NULL,NULL,NULL),
	 ('BBS_MNG','HOME_MNG','PP','게시판 관리',NULL,NULL,'Y',NULL,NULL,NULL,NULL,NULL,NULL),
	 ('GG_AUTHOR','EXPRT_AUTH','PP','기관 관리자',NULL,NULL,'Y',NULL,NULL,NULL,NULL,NULL,NULL),
	 ('JJ_USE','DUR_INFO','PP','적정사용정보',NULL,NULL,'Y',NULL,NULL,NULL,NULL,NULL,NULL),
	 ('DU_BBS_MNG','DUR_INFO','PP','DUR 게시판 관리',NULL,NULL,'Y',NULL,NULL,NULL,NULL,NULL,NULL),
	 ('AUTH_EXPRT','AUTH_ADMIN','PP','전문가 관리',NULL,NULL,'Y',NULL,NULL,NULL,NULL,NULL,NULL),
	 ('AUTH_MENU','AUTH_ADMIN','PP','메뉴 관리',NULL,NULL,'Y',NULL,NULL,NULL,NULL,NULL,NULL),
	 ('AUTH_ADMIN','','PP','권한 관리자',NULL,NULL,'Y',NULL,NULL,NULL,NULL,NULL,NULL),
	 ('DUR_INFO','','PP','DUR 정보 관리',NULL,NULL,'Y',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO kids_own.tb_pp_m_authrt (authrt_cd,up_authrt_cd,task_se_cd,authrt_nm,authrt_type_cd,authrt_expln,use_yn,wrtr_dept_nm,mdfr_dept_nm,rgtr_id,reg_dt,mdfr_id,mdfcn_dt) VALUES
	 ('HOME_MNG','','PP','홈페이지 관리',NULL,NULL,'Y',NULL,NULL,NULL,NULL,NULL,NULL),
	 ('EXPRT_CR','','CR','부작용포털(eCRF)  권한',NULL,NULL,'Y',NULL,NULL,NULL,NULL,NULL,NULL),
	 ('EXPRT_CM','','CM','통합분석시스템(CDM)  권한',NULL,NULL,'Y',NULL,NULL,NULL,NULL,NULL,NULL),
	 ('EXPRT_DR','','DR','전자문서고  권한',NULL,NULL,'Y',NULL,NULL,NULL,NULL,NULL,NULL),
	 ('EXPRT_SV','','SV','설문 권한',NULL,NULL,'Y',NULL,NULL,NULL,NULL,NULL,NULL),
	 ('EXPRT_ED','','ED','교육플랫폼 권한',NULL,NULL,'Y',NULL,NULL,NULL,NULL,NULL,NULL),
	 ('EXPRT_CC','','CC','통합상담 권한',NULL,NULL,'Y',NULL,NULL,NULL,NULL,NULL,NULL),
	 ('EXPRT_BO','','BO','안전정보업무 권한',NULL,NULL,'Y',NULL,NULL,NULL,NULL,NULL,NULL),
	 ('EXPRT_AUTH','','PP','전문가 승인 권한',NULL,NULL,'Y',NULL,NULL,NULL,NULL,NULL,NULL),
	 ('EXPRT_CR2','','CR','부작용포털(eCRF)  권한2',NULL,NULL,'Y',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO kids_own.tb_pp_m_authrt (authrt_cd,up_authrt_cd,task_se_cd,authrt_nm,authrt_type_cd,authrt_expln,use_yn,wrtr_dept_nm,mdfr_dept_nm,rgtr_id,reg_dt,mdfr_id,mdfcn_dt) VALUES
	 ('AUTH_CR','','','부작용포털(eCRF)  승인 권한',NULL,NULL,'Y',NULL,NULL,NULL,NULL,NULL,NULL),
	 ('AUTH_CM','','','통합분석시스템(CDM) 승인 권한',NULL,NULL,'Y',NULL,NULL,NULL,NULL,NULL,NULL),
	 ('AUTH_DR','','','전자문서고 승인 권한',NULL,NULL,'Y',NULL,NULL,NULL,NULL,NULL,NULL),
	 ('AUTH_SV','','','설문 승인 권한',NULL,NULL,'Y',NULL,NULL,NULL,NULL,NULL,NULL),
	 ('AUTH_ED','','','교육플랫폼 승인 권한',NULL,NULL,'Y',NULL,NULL,NULL,NULL,NULL,NULL),
	 ('AUTH_CC','','','통합상담 승인 권한',NULL,NULL,'Y',NULL,NULL,NULL,NULL,NULL,NULL),
	 ('AUTH_BO','','','안전정보업무 승인 권한',NULL,NULL,'Y',NULL,NULL,NULL,NULL,NULL,NULL);
