-- kids_own.tb_ca_addr definition

-- Drop table

-- DROP TABLE kids_own.tb_ca_addr;

CREATE TABLE kids_own.tb_ca_addr (
	zip bpchar(5) NOT NULL,
	ctpv_nm varchar(300) NULL,
	sgg_nm varchar(200) NULL,
	emd_nm varchar(300) NULL,
	road_nm_cd varchar(20) NULL,
	road_nm varchar(300) NULL,
	bno_mno numeric(4) NULL,
	bno_sno numeric(4) NULL,
	bldg_nm varchar(300) NULL,
	dtl_bldg_nm varchar(300) NULL,
	lotno_no_vl varchar(40) NULL,
	lotno_mno numeric(4) NULL,
	lotno_sno numeric(4) NULL,
	reg_dt timestamp NULL,
	rgtr_id varchar(40) NULL,
	mdfcn_dt timestamp NULL,
	mdfr_id varchar(40) NULL,
	CONSTRAINT pk_tb_ca_addr PRIMARY KEY (zip)
);

-- Permissions

ALTER TABLE kids_own.tb_ca_addr OWNER TO postgres;
GRANT ALL ON TABLE kids_own.tb_ca_addr TO postgres;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_addr TO bo_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_addr TO bo_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_addr TO cm_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_addr TO cm_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_addr TO co_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_addr TO co_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_addr TO cr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_addr TO cr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_addr TO dr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_addr TO dr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_addr TO ex_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_addr TO ex_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_addr TO pp_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_addr TO pp_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_addr TO sc_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_addr TO sc_dev;


-- kids_own.tb_ca_c_dtl_code definition

-- Drop table

-- DROP TABLE kids_own.tb_ca_c_dtl_code;

CREATE TABLE kids_own.tb_ca_c_dtl_code (
	com_dtl_cd varchar(20) NOT NULL,
	com_group_cd varchar(20) NOT NULL,
	com_dtl_cd_nm varchar(80) NULL,
	dgt numeric(10) NULL,
	sort_seq numeric(10) NULL,
	rsvt_cn_1 text NULL,
	rsvt_cn_2 text NULL,
	rsvt_cn_3 text NULL,
	rsvt_cn_4 text NULL,
	rsvt_cn_5 text NULL,
	rsvt_cn_6 text NULL,
	rsvt_cn_7 text NULL,
	rsvt_cn_8 text NULL,
	rsvt_cn_9 text NULL,
	rsvt_cn_10 text NULL,
	use_yn bpchar(1) NULL,
	reg_dt timestamp NULL,
	rgtr_id varchar(40) NULL,
	mdfcn_dt timestamp NULL,
	mdfr_id varchar(40) NULL,
	CONSTRAINT pk_tb_ca_c_dtl_code PRIMARY KEY (com_dtl_cd, com_group_cd)
);

-- Permissions

ALTER TABLE kids_own.tb_ca_c_dtl_code OWNER TO postgres;
GRANT ALL ON TABLE kids_own.tb_ca_c_dtl_code TO postgres;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_c_dtl_code TO bo_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_c_dtl_code TO bo_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_c_dtl_code TO cm_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_c_dtl_code TO cm_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_c_dtl_code TO co_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_c_dtl_code TO co_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_c_dtl_code TO cr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_c_dtl_code TO cr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_c_dtl_code TO dr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_c_dtl_code TO dr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_c_dtl_code TO ex_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_c_dtl_code TO ex_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_c_dtl_code TO pp_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_c_dtl_code TO pp_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_c_dtl_code TO sc_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_c_dtl_code TO sc_dev;


-- kids_own.tb_ca_c_group_code definition

-- Drop table

-- DROP TABLE kids_own.tb_ca_c_group_code;

CREATE TABLE kids_own.tb_ca_c_group_code (
	com_group_cd varchar(20) NOT NULL,
	group_cd_nm varchar(80) NOT NULL,
	group_cd_expln varchar(300) NOT NULL,
	group_cd_abbr_nm varchar(40) NULL,
	group_cd_rsvt_cn_1 text NULL,
	group_cd_rsvt_cn_2 text NULL,
	group_cd_rsvt_cn_3 text NULL,
	group_cd_rsvt_cn_4 text NULL,
	group_cd_rsvt_cn_5 text NULL,
	reg_dt timestamp NULL,
	rgtr_id varchar(40) NULL,
	mdfcn_dt timestamp NULL,
	mdfr_id varchar(40) NULL,
	CONSTRAINT pk_tb_ca_c_group_code PRIMARY KEY (com_group_cd)
);

-- Permissions

ALTER TABLE kids_own.tb_ca_c_group_code OWNER TO postgres;
GRANT ALL ON TABLE kids_own.tb_ca_c_group_code TO postgres;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_c_group_code TO bo_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_c_group_code TO bo_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_c_group_code TO cm_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_c_group_code TO cm_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_c_group_code TO co_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_c_group_code TO co_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_c_group_code TO cr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_c_group_code TO cr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_c_group_code TO dr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_c_group_code TO dr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_c_group_code TO ex_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_c_group_code TO ex_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_c_group_code TO pp_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_c_group_code TO pp_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_c_group_code TO sc_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_c_group_code TO sc_dev;


-- kids_own.tb_ca_e_cert definition

-- Drop table

-- DROP TABLE kids_own.tb_ca_e_cert;

CREATE TABLE kids_own.tb_ca_e_cert (
	cert_dmnd_no varchar(64) NOT NULL,
	link_info_idntf_id varchar(100) NOT NULL,
	intg_cert_sn numeric(22) NOT NULL,
	anyid_unq_vl varchar(100) NULL,
	user_crtf_vl varchar(100) NULL,
	user_cnpl_no varchar(20) NULL,
	user_dompl_se_cd bpchar(1) NULL,
	user_rrno varchar(20) NULL,
	user_gndr_cd bpchar(1) NULL,
	user_flnm varchar(20) NULL,
	user_brdt bpchar(8) NULL,
	cert_token_vl varchar(40) NOT NULL,
	cert_scs_yn bpchar(1) NULL,
	cert_dmnd_dt timestamp NOT NULL,
	cert_rslt_se_cd varchar(10) NULL,
	cert_rspns_cd varchar(10) NOT NULL,
	cert_rspns_msg_cn varchar(1000) NULL,
	rqstr_ip_addr varchar(255) NOT NULL,
	prcs_stts_cd varchar(10) NULL,
	prcs_stts_nm varchar(20) NULL,
	rslt_vl varchar(4000) NULL,
	reg_dt timestamp NULL,
	rgtr_id varchar(40) NULL,
	mdfcn_dt timestamp NULL,
	mdfr_id varchar(40) NULL,
	CONSTRAINT pk_tb_ca_e_cert PRIMARY KEY (cert_dmnd_no, link_info_idntf_id, intg_cert_sn)
);

-- Permissions

ALTER TABLE kids_own.tb_ca_e_cert OWNER TO postgres;
GRANT ALL ON TABLE kids_own.tb_ca_e_cert TO postgres;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_e_cert TO bo_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_e_cert TO bo_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_e_cert TO cm_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_e_cert TO cm_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_e_cert TO co_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_e_cert TO co_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_e_cert TO cr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_e_cert TO cr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_e_cert TO dr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_e_cert TO dr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_e_cert TO ex_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_e_cert TO ex_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_e_cert TO pp_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_e_cert TO pp_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_e_cert TO sc_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_e_cert TO sc_dev;


-- kids_own.tb_ca_e_doc_otpt definition

-- Drop table

-- DROP TABLE kids_own.tb_ca_e_doc_otpt;

CREATE TABLE kids_own.tb_ca_e_doc_otpt (
	otpt_sn numeric(22) NOT NULL,
	prnot_id varchar(20) NOT NULL,
	rqstr_id varchar(40) NOT NULL,
	ognz_cd varchar(20) NULL,
	elsgn varchar(20) NULL,
	img_nm varchar(100) NULL,
	img_extn_nm varchar(100) NULL,
	otpt_dt bpchar(14) NULL,
	reg_dt timestamp NULL,
	rgtr_id varchar(40) NULL,
	mdfcn_dt timestamp NULL,
	mdfr_id varchar(40) NULL,
	CONSTRAINT pk_tb_ca_e_doc_otpt PRIMARY KEY (otpt_sn)
);

-- Permissions

ALTER TABLE kids_own.tb_ca_e_doc_otpt OWNER TO postgres;
GRANT ALL ON TABLE kids_own.tb_ca_e_doc_otpt TO postgres;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_e_doc_otpt TO bo_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_e_doc_otpt TO bo_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_e_doc_otpt TO cm_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_e_doc_otpt TO cm_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_e_doc_otpt TO co_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_e_doc_otpt TO co_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_e_doc_otpt TO cr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_e_doc_otpt TO cr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_e_doc_otpt TO dr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_e_doc_otpt TO dr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_e_doc_otpt TO ex_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_e_doc_otpt TO ex_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_e_doc_otpt TO pp_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_e_doc_otpt TO pp_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_e_doc_otpt TO sc_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_e_doc_otpt TO sc_dev;


-- kids_own.tb_ca_e_file_group_trsm definition

-- Drop table

-- DROP TABLE kids_own.tb_ca_e_file_group_trsm;

CREATE TABLE kids_own.tb_ca_e_file_group_trsm (
	atch_file_group_id varchar(40) NOT NULL,
	task_se_cd varchar(10) NULL,
	task_se_trgt_id varchar(40) NULL,
	use_yn bpchar(1) NULL,
	reg_dt timestamp NULL,
	rgtr_id varchar(40) NULL,
	mdfcn_dt timestamp NULL,
	mdfr_id varchar(40) NULL,
	CONSTRAINT pk_tb_ca_e_file_group_trsm PRIMARY KEY (atch_file_group_id)
);

-- Permissions

ALTER TABLE kids_own.tb_ca_e_file_group_trsm OWNER TO postgres;
GRANT ALL ON TABLE kids_own.tb_ca_e_file_group_trsm TO postgres;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_e_file_group_trsm TO bo_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_e_file_group_trsm TO bo_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_e_file_group_trsm TO cm_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_e_file_group_trsm TO cm_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_e_file_group_trsm TO co_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_e_file_group_trsm TO co_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_e_file_group_trsm TO cr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_e_file_group_trsm TO cr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_e_file_group_trsm TO dr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_e_file_group_trsm TO dr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_e_file_group_trsm TO ex_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_e_file_group_trsm TO ex_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_e_file_group_trsm TO pp_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_e_file_group_trsm TO pp_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_e_file_group_trsm TO sc_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_e_file_group_trsm TO sc_dev;


-- kids_own.tb_ca_e_file_trsm definition

-- Drop table

-- DROP TABLE kids_own.tb_ca_e_file_trsm;

CREATE TABLE kids_own.tb_ca_e_file_trsm (
	atch_file_id varchar(40) NOT NULL,
	atch_file_group_id varchar(40) NULL,
	file_seq numeric(10) NOT NULL,
	file_strg_path_dsctn varchar(1000) NULL,
	인코딩파일명 varchar(300) NULL,
	prvc_incl_yn bpchar(1) NULL,
	file_nm varchar(300) NULL,
	file_extn_nm varchar(20) NULL,
	file_cn text NULL,
	file_sz numeric(10) NULL,
	crt_dt bpchar(14) NULL,
	use_yn bpchar(1) NULL,
	reg_dt timestamp NULL,
	rgtr_id varchar(40) NULL,
	mdfcn_dt timestamp NULL,
	mdfr_id varchar(40) NULL,
	CONSTRAINT pk_tb_ca_e_file_trsm PRIMARY KEY (atch_file_id)
);

-- Permissions

ALTER TABLE kids_own.tb_ca_e_file_trsm OWNER TO postgres;
GRANT ALL ON TABLE kids_own.tb_ca_e_file_trsm TO postgres;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_e_file_trsm TO bo_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_e_file_trsm TO bo_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_e_file_trsm TO cm_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_e_file_trsm TO cm_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_e_file_trsm TO co_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_e_file_trsm TO co_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_e_file_trsm TO cr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_e_file_trsm TO cr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_e_file_trsm TO dr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_e_file_trsm TO dr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_e_file_trsm TO ex_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_e_file_trsm TO ex_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_e_file_trsm TO pp_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_e_file_trsm TO pp_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_e_file_trsm TO sc_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_e_file_trsm TO sc_dev;


-- kids_own.tb_ca_i_msg_img definition

-- Drop table

-- DROP TABLE kids_own.tb_ca_i_msg_img;

CREATE TABLE kids_own.tb_ca_i_msg_img (
	msg_img_sn numeric(22) NOT NULL,
	seq_no numeric(22) NOT NULL,
	file_cnt numeric(10) NOT NULL,
	file_path_nm_1 varchar(256) NULL,
	file_path_nm_2 varchar(256) NULL,
	file_path_nm_3 varchar(256) NULL,
	img_idntf_id_vl varchar(100) NULL,
	img_uld_type varchar(20) NULL,
	otsd_img_url varchar(200) NULL,
	img_prcs_yn bpchar(1) NULL,
	img_prcs_msg varchar(300) NULL,
	img_uld_acnt varchar(40) NULL,
	img_uld_hr varchar(20) NULL,
	img_expry_hr varchar(20) NULL,
	reg_dt timestamp NULL,
	rgtr_id varchar(20) NULL,
	mdfcn_dt timestamp NULL,
	mdfr_id varchar(20) NULL,
	CONSTRAINT pk_tb_ca_i_msg_img PRIMARY KEY (msg_img_sn)
);

-- Permissions

ALTER TABLE kids_own.tb_ca_i_msg_img OWNER TO postgres;
GRANT ALL ON TABLE kids_own.tb_ca_i_msg_img TO postgres;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_i_msg_img TO bo_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_i_msg_img TO bo_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_i_msg_img TO cm_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_i_msg_img TO cm_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_i_msg_img TO co_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_i_msg_img TO co_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_i_msg_img TO cr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_i_msg_img TO cr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_i_msg_img TO dr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_i_msg_img TO dr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_i_msg_img TO ex_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_i_msg_img TO ex_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_i_msg_img TO pp_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_i_msg_img TO pp_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_i_msg_img TO sc_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_i_msg_img TO sc_dev;


-- kids_own.tb_ca_i_msg_rslt definition

-- Drop table

-- DROP TABLE kids_own.tb_ca_i_msg_rslt;

CREATE TABLE kids_own.tb_ca_i_msg_rslt (
	seq_no numeric(22) NOT NULL,
	rslt_cd varchar(10) NOT NULL,
	rslt_msg varchar(1000) NULL,
	reg_dt timestamp NULL,
	rgtr_id varchar(20) NULL,
	mdfcn_dt timestamp NULL,
	mdfr_id varchar(20) NULL,
	CONSTRAINT pk_tb_ca_i_msg_rslt PRIMARY KEY (seq_no)
);

-- Permissions

ALTER TABLE kids_own.tb_ca_i_msg_rslt OWNER TO postgres;
GRANT ALL ON TABLE kids_own.tb_ca_i_msg_rslt TO postgres;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_i_msg_rslt TO bo_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_i_msg_rslt TO bo_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_i_msg_rslt TO cm_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_i_msg_rslt TO cm_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_i_msg_rslt TO co_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_i_msg_rslt TO co_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_i_msg_rslt TO cr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_i_msg_rslt TO cr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_i_msg_rslt TO dr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_i_msg_rslt TO dr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_i_msg_rslt TO ex_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_i_msg_rslt TO ex_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_i_msg_rslt TO pp_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_i_msg_rslt TO pp_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_i_msg_rslt TO sc_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_i_msg_rslt TO sc_dev;


-- kids_own.tb_ca_i_msg_sndng definition

-- Drop table

-- DROP TABLE kids_own.tb_ca_i_msg_sndng;

CREATE TABLE kids_own.tb_ca_i_msg_sndng (
	seq_no numeric(22) NOT NULL,
	메시지유입시간 bpchar(14) NOT NULL,
	슈어엠발급아이디 varchar(32) NOT NULL,
	biz_type varchar(10) NULL,
	브랜드키 varchar(40) NULL,
	rply_sndr varchar(40) NULL,
	dsptch_no varchar(20) NOT NULL,
	rcvr varchar(40) NULL,
	ntn_cd varchar(10) NULL,
	rcptn_no varchar(20) NOT NULL,
	ttl varchar(200) NULL,
	msg_cn varchar(4000) NOT NULL,
	rsvt_dt bpchar(14) NOT NULL,
	sndng_dt bpchar(14) NOT NULL,
	trmnl_rcptn_tm bpchar(14) NOT NULL,
	msg_stts_vl bpchar(1) NULL,
	err_cd numeric(10) NULL,
	msg_type bpchar(1) NOT NULL,
	img_no numeric(10) NULL,
	ltr_rtry_nmtm numeric(10) NOT NULL,
	ltr_rtrsm_yn bpchar(1) NULL,
	kakao_form_cd varchar(40) NULL,
	kakao_fail_sbst_msg varchar(2000) NULL,
	재처리문자타입 varchar(5) NULL,
	tlcmco_cd bpchar(1) NULL,
	msg_atch_cn varchar(4000) NULL,
	바로연결정보 varchar(1000) NULL,
	친구톡메시지 varchar(4000) NULL,
	헤더 varchar(50) NULL,
	카카오에러코드 varchar(20) NULL,
	kakao_ttl varchar(100) NULL,
	타게팅 bpchar(1) NULL,
	카카오캠페인이름 varchar(80) NULL,
	dsptch_bzmn_idntf_cd bpchar(10) NULL,
	insd_use_field_id varchar(50) NULL,
	etc_artcl_1 varchar(20) NULL,
	etc_artcl_2 varchar(20) NULL,
	etc_artcl_3 varchar(20) NULL,
	etc_artcl_4 varchar(20) NULL,
	etc_artcl_5 varchar(20) NULL,
	reg_dt timestamp NULL,
	rgtr_id varchar(20) NULL,
	mdfcn_dt timestamp NULL,
	mdfr_id varchar(20) NULL,
	CONSTRAINT pk_tb_ca_i_msg_sndng PRIMARY KEY (seq_no)
);

-- Permissions

ALTER TABLE kids_own.tb_ca_i_msg_sndng OWNER TO postgres;
GRANT ALL ON TABLE kids_own.tb_ca_i_msg_sndng TO postgres;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_i_msg_sndng TO bo_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_i_msg_sndng TO bo_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_i_msg_sndng TO cm_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_i_msg_sndng TO cm_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_i_msg_sndng TO co_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_i_msg_sndng TO co_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_i_msg_sndng TO cr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_i_msg_sndng TO cr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_i_msg_sndng TO dr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_i_msg_sndng TO dr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_i_msg_sndng TO ex_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_i_msg_sndng TO ex_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_i_msg_sndng TO pp_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_i_msg_sndng TO pp_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_i_msg_sndng TO sc_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_i_msg_sndng TO sc_dev;


-- kids_own.tb_ca_l_cntn_info_log definition

-- Drop table

-- DROP TABLE kids_own.tb_ca_l_cntn_info_log;

CREATE TABLE kids_own.tb_ca_l_cntn_info_log (
	prvc_hstry_mdfcn_sn numeric(22) NOT NULL,
	cntn_log_sn numeric(10) NULL,
	cert_dmnd_no varchar(64) NULL,
	inpt_dt timestamp NULL,
	inst_cd varchar(20) NULL,
	trgt_menu_nm varchar(40) NULL,
	질의응답쿼리내용 text NULL,
	url_addr varchar(2000) NOT NULL,
	task_se_cd_no varchar(10) NULL,
	cntn_dt timestamp NULL,
	acsr_nm varchar(20) NULL,
	rqstr_id varchar(40) NULL,
	flfmt_task_cd varchar(10) NULL,
	etc_memo_cn varchar(4000) NULL,
	prvc_incl_yn bpchar(1) NULL,
	reg_dt timestamp NULL,
	rgtr_id varchar(40) NULL,
	link_info_idntf_id varchar(100) NULL,
	intg_cert_sn numeric(22) NULL,
	CONSTRAINT pk_tb_ca_l_cntn_info_log PRIMARY KEY (prvc_hstry_mdfcn_sn)
);

-- Permissions

ALTER TABLE kids_own.tb_ca_l_cntn_info_log OWNER TO postgres;
GRANT ALL ON TABLE kids_own.tb_ca_l_cntn_info_log TO postgres;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_l_cntn_info_log TO bo_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_l_cntn_info_log TO bo_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_l_cntn_info_log TO cm_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_l_cntn_info_log TO cm_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_l_cntn_info_log TO co_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_l_cntn_info_log TO co_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_l_cntn_info_log TO cr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_l_cntn_info_log TO cr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_l_cntn_info_log TO dr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_l_cntn_info_log TO dr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_l_cntn_info_log TO ex_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_l_cntn_info_log TO ex_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_l_cntn_info_log TO pp_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_l_cntn_info_log TO pp_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_l_cntn_info_log TO sc_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_l_cntn_info_log TO sc_dev;


-- kids_own.tb_ca_l_sesn_log_info_mng definition

-- Drop table

-- DROP TABLE kids_own.tb_ca_l_sesn_log_info_mng;

CREATE TABLE kids_own.tb_ca_l_sesn_log_info_mng (
	cntn_log_sn numeric(10) NOT NULL,
	cert_dmnd_no varchar(64) NOT NULL,
	link_info_idntf_id varchar(100) NOT NULL,
	intg_cert_sn numeric(22) NOT NULL,
	lgn_se_cd bpchar(1) NULL,
	srvc_user_id varchar(40) NULL,
	rqstr_ip_addr varchar(255) NOT NULL,
	cntn_se_no varchar(10) NULL,
	cntn_ocrn_dt bpchar(14) NULL,
	cntn_dtl_expln varchar(40) NULL,
	cert_token_vl varchar(40) NOT NULL,
	token_crt_hr bpchar(6) NULL,
	task_se_cd varchar(10) NOT NULL,
	srvc_nm varchar(100) NULL,
	flfmt_hr bpchar(6) NULL,
	sess_expry_prnmnt_hr bpchar(6) NULL,
	lgt_dt timestamp NULL,
	reg_dt timestamp NULL,
	rgtr_id varchar(40) NULL,
	CONSTRAINT pk_tb_ca_l_sesn_log_info_mng PRIMARY KEY (cntn_log_sn, cert_dmnd_no, link_info_idntf_id, intg_cert_sn)
);

-- Permissions

ALTER TABLE kids_own.tb_ca_l_sesn_log_info_mng OWNER TO postgres;
GRANT ALL ON TABLE kids_own.tb_ca_l_sesn_log_info_mng TO postgres;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_l_sesn_log_info_mng TO bo_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_l_sesn_log_info_mng TO bo_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_l_sesn_log_info_mng TO cm_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_l_sesn_log_info_mng TO cm_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_l_sesn_log_info_mng TO co_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_l_sesn_log_info_mng TO co_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_l_sesn_log_info_mng TO cr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_l_sesn_log_info_mng TO cr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_l_sesn_log_info_mng TO dr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_l_sesn_log_info_mng TO dr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_l_sesn_log_info_mng TO ex_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_l_sesn_log_info_mng TO ex_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_l_sesn_log_info_mng TO pp_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_l_sesn_log_info_mng TO pp_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_l_sesn_log_info_mng TO sc_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_l_sesn_log_info_mng TO sc_dev;


-- kids_own.tb_ca_m_anyid_intg_cert definition

-- Drop table

-- DROP TABLE kids_own.tb_ca_m_anyid_intg_cert;

CREATE TABLE kids_own.tb_ca_m_anyid_intg_cert (
	intg_cert_sn numeric(22) NOT NULL,
	intg_cert_dmnd_sn numeric(22) NULL,
	rqstr_ip_addr varchar(255) NOT NULL,
	prcs_stts_cd varchar(10) NULL,
	intg_cert_rspns_cd varchar(10) NULL,
	intg_cert_rspns_msg_vl varchar(40) NULL,
	reg_dt timestamp NULL,
	rgtr_id varchar(40) NULL,
	mdfcn_dt timestamp NULL,
	mdfr_id varchar(40) NULL,
	CONSTRAINT pk_tb_ca_m_anyid_intg_cert PRIMARY KEY (intg_cert_sn)
);

-- Permissions

ALTER TABLE kids_own.tb_ca_m_anyid_intg_cert OWNER TO postgres;
GRANT ALL ON TABLE kids_own.tb_ca_m_anyid_intg_cert TO postgres;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_m_anyid_intg_cert TO bo_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_m_anyid_intg_cert TO bo_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_m_anyid_intg_cert TO cm_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_m_anyid_intg_cert TO cm_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_m_anyid_intg_cert TO co_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_m_anyid_intg_cert TO co_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_m_anyid_intg_cert TO cr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_m_anyid_intg_cert TO cr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_m_anyid_intg_cert TO dr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_m_anyid_intg_cert TO dr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_m_anyid_intg_cert TO ex_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_m_anyid_intg_cert TO ex_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_m_anyid_intg_cert TO pp_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_m_anyid_intg_cert TO pp_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_m_anyid_intg_cert TO sc_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_m_anyid_intg_cert TO sc_dev;


-- kids_own.tb_ca_m_atch definition

-- Drop table

-- DROP TABLE kids_own.tb_ca_m_atch;

CREATE TABLE kids_own.tb_ca_m_atch (
	atch_file_sn numeric(10) NOT NULL,
	menu_sn numeric(22) NOT NULL,
	menu_type varchar(20) NULL,
	atch_file_uld_hr timestamp NOT NULL,
	atch_file_use_yn bpchar(1) NOT NULL,
	atch_file_path varchar(1000) NULL,
	atch_file_nm varchar(100) NULL,
	atch_file_extn_nm varchar(5) NULL,
	atch_file_cn varchar(1000) NULL,
	atch_file_sz numeric(14) NULL,
	rgtr_id varchar(40) NULL,
	reg_dt timestamp NULL,
	mdfr_id varchar(40) NULL,
	mdfcn_dt timestamp NULL,
	CONSTRAINT pk_tb_ca_m_atch PRIMARY KEY (atch_file_sn)
);

-- Permissions

ALTER TABLE kids_own.tb_ca_m_atch OWNER TO postgres;
GRANT ALL ON TABLE kids_own.tb_ca_m_atch TO postgres;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_m_atch TO bo_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_m_atch TO bo_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_m_atch TO cm_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_m_atch TO cm_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_m_atch TO co_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_m_atch TO co_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_m_atch TO cr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_m_atch TO cr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_m_atch TO dr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_m_atch TO dr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_m_atch TO ex_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_m_atch TO ex_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_m_atch TO pp_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_m_atch TO pp_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_m_atch TO sc_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_m_atch TO sc_dev;


-- kids_own.tb_ca_m_com_cd definition

-- Drop table

-- DROP TABLE kids_own.tb_ca_m_com_cd;

CREATE TABLE kids_own.tb_ca_m_com_cd (
	com_cd bpchar(12) NOT NULL,
	CONSTRAINT pk_tb_ca_m_com_cd PRIMARY KEY (com_cd)
);

-- Permissions

ALTER TABLE kids_own.tb_ca_m_com_cd OWNER TO postgres;
GRANT ALL ON TABLE kids_own.tb_ca_m_com_cd TO postgres;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_m_com_cd TO bo_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_m_com_cd TO bo_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_m_com_cd TO cm_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_m_com_cd TO cm_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_m_com_cd TO co_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_m_com_cd TO co_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_m_com_cd TO cr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_m_com_cd TO cr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_m_com_cd TO dr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_m_com_cd TO dr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_m_com_cd TO ex_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_m_com_cd TO ex_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_m_com_cd TO pp_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_m_com_cd TO pp_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_m_com_cd TO sc_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_m_com_cd TO sc_dev;


-- kids_own.tb_ca_m_eml_sndng definition

-- Drop table

-- DROP TABLE kids_own.tb_ca_m_eml_sndng;

CREATE TABLE kids_own.tb_ca_m_eml_sndng (
	eml_sndng_sn numeric(22) NOT NULL,
	eml_ttl varchar(256) NULL,
	eml_cn varchar(4000) NULL,
	sndpty_flnm varchar(100) NULL,
	sndpty_eml_addr varchar(320) NOT NULL,
	rcvr_flnm varchar(100) NULL,
	rcvr_eml_addr varchar(320) NOT NULL,
	rcvr_jbps_nm varchar(100) NULL,
	sndng_rslt_cd varchar(10) NULL,
	atch_file_id varchar(40) NULL,
	dsptch_dt bpchar(14) NULL,
	reg_dt timestamp NULL,
	rgtr_id varchar(40) NULL,
	mdfcn_dt timestamp NULL,
	mdfr_id varchar(40) NULL,
	CONSTRAINT pk_tb_ca_m_eml_sndng PRIMARY KEY (eml_sndng_sn)
);

-- Permissions

ALTER TABLE kids_own.tb_ca_m_eml_sndng OWNER TO postgres;
GRANT ALL ON TABLE kids_own.tb_ca_m_eml_sndng TO postgres;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_m_eml_sndng TO bo_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_m_eml_sndng TO bo_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_m_eml_sndng TO cm_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_m_eml_sndng TO cm_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_m_eml_sndng TO co_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_m_eml_sndng TO co_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_m_eml_sndng TO cr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_m_eml_sndng TO cr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_m_eml_sndng TO dr_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_m_eml_sndng TO dr_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_m_eml_sndng TO ex_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_m_eml_sndng TO ex_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_m_eml_sndng TO pp_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_m_eml_sndng TO pp_dev;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_m_eml_sndng TO sc_app;
GRANT DELETE, SELECT, INSERT, UPDATE ON TABLE kids_own.tb_ca_m_eml_sndng TO sc_dev;