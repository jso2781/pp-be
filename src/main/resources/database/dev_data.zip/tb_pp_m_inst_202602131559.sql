INSERT INTO kids_own.tb_pp_m_inst (brno,inst_nm,del_yn,rgtr_id,reg_dt,mdfr_id,mdfcn_dt) VALUES
	 ('9999999999','국립안양병원','N',NULL,NULL,NULL,NULL);
