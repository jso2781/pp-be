INSERT INTO kids_own.tb_pp_m_menu (menu_sn,menu_nm,up_menu_sn,task_se_cd,menu_type_cd,lang_se_cd,menu_seq,menu_expln,pic_dept_nm,pic_flnm,use_yn,rgtr_id,reg_dt,mdfr_id,mdfcn_dt) VALUES
	 ('999','테스트 메뉴분류 1',NULL,'PP','M','KOR',1,'',NULL,NULL,'Y',NULL,'2026-01-28 08:02:27.390812',NULL,'2026-01-28 08:02:27.390812');
