INSERT INTO kids_own.tb_pp_m_pst (pst_sn,bbs_id,pst_ttl,pst_cn,pst_inq_cnt,pst_kogl_cprgt_type_cd,atch_file_group_id,thmb_id,fix_yn,fix_bgng_ymd,fix_end_ymd,vdo_url_addr,expsr_yn,wrtr_dept_nm,mdfr_dept_nm,rgtr_id,reg_dt,mdfr_id,mdfcn_dt) VALUES
	 (4,'BBS_COM_001','공지_게시글4','공지_게시글4_내용',49,'1',NULL,NULL,'N',NULL,NULL,NULL,'Y','개발팀',NULL,'test001','2026-01-04 14:22:51.03',NULL,NULL),
	 (6,'BBS_COM_001','공지_게시글6','공지_게시글6_내용',50,'1',NULL,NULL,'N',NULL,NULL,NULL,'Y','개발팀',NULL,'test001','2026-01-06 14:22:51.03',NULL,NULL),
	 (8,'BBS_COM_001','공지_게시글8','공지_게시글8_내용',50,'1',NULL,NULL,'N',NULL,NULL,NULL,'Y','개발팀',NULL,'test001','2026-01-08 14:22:51.03',NULL,NULL),
	 (13,'BBS_COM_002','채용_게시글1','채용_게시글1_내용',50,'1',NULL,NULL,'N',NULL,NULL,NULL,'Y','개발팀',NULL,'test001','2026-01-01 14:22:51.03',NULL,NULL),
	 (16,'BBS_COM_003','뉴스레터_게시글1','뉴스레터_게시글1_내용',50,'1',NULL,NULL,'N',NULL,NULL,NULL,'Y','개발팀',NULL,'test001','2026-01-04 14:22:51.03',NULL,NULL),
	 (17,'BBS_COM_003','뉴스레터_게시글2','뉴스레터_게시글2_내용',50,'1',NULL,NULL,'N',NULL,NULL,NULL,'Y','개발팀',NULL,'test001','2026-01-05 14:22:51.03',NULL,NULL),
	 (18,'BBS_COM_003','뉴스레터_게시글3','뉴스레터_게시글3_내용',50,'1',NULL,NULL,'N',NULL,NULL,NULL,'Y','개발팀',NULL,'test001','2026-01-06 14:22:51.03',NULL,NULL),
	 (19,'BBS_COM_003','뉴스레터_게시글4','뉴스레터_게시글4_내용',50,'1',NULL,NULL,'N',NULL,NULL,NULL,'Y','개발팀',NULL,'test001','2026-01-07 14:22:51.03',NULL,NULL),
	 (20,'BBS_COM_003','뉴스레터_게시글5','뉴스레터_게시글5_내용',50,'1',NULL,NULL,'N',NULL,NULL,NULL,'Y','개발팀',NULL,'test001','2026-01-08 14:22:51.03',NULL,NULL),
	 (21,'BBS_COM_004','보도자료_게시글1','보도_게시글1_내용',50,'1',NULL,NULL,'N',NULL,NULL,NULL,'Y','개발팀',NULL,'test001','2026-01-09 14:22:51.03',NULL,NULL);
INSERT INTO kids_own.tb_pp_m_pst (pst_sn,bbs_id,pst_ttl,pst_cn,pst_inq_cnt,pst_kogl_cprgt_type_cd,atch_file_group_id,thmb_id,fix_yn,fix_bgng_ymd,fix_end_ymd,vdo_url_addr,expsr_yn,wrtr_dept_nm,mdfr_dept_nm,rgtr_id,reg_dt,mdfr_id,mdfcn_dt) VALUES
	 (22,'BBS_COM_004','보도자료_게시글2','보도_게시글2_내용',50,'1',NULL,NULL,'N',NULL,NULL,NULL,'Y','개발팀',NULL,'test001','2026-01-10 14:22:51.03',NULL,NULL),
	 (23,'BBS_COM_004','보도자료_게시글3','보도_게시글3_내용',50,'1',NULL,NULL,'N',NULL,NULL,NULL,'Y','개발팀',NULL,'test001','2026-01-11 14:22:51.03',NULL,NULL),
	 (24,'BBS_GAL_001','카드뉴스_게시글1','카드_게시글1_내용',50,'1','5','3','N',NULL,NULL,NULL,'Y','개발팀',NULL,'test001','2026-01-11 14:22:51.03',NULL,NULL),
	 (25,'BBS_GAL_001','카드뉴스_게시글2','카드_게시글2_내용',50,'1','5','4','N',NULL,NULL,NULL,'Y','개발팀',NULL,'test001','2026-01-12 14:22:51.03',NULL,NULL),
	 (26,'BBS_GAL_001','카드뉴스_게시글3','카드_게시글3_내용',50,'1','5','3','N',NULL,NULL,NULL,'Y','개발팀',NULL,'test001','2026-01-13 14:22:51.03',NULL,NULL),
	 (27,'BBS_GAL_001','카드뉴스_게시글4','카드_게시글4_내용',52,'1','5','4','N',NULL,NULL,NULL,'Y','개발팀',NULL,'test001','2026-01-14 14:22:51.03',NULL,NULL),
	 (29,'BBS_GAL_002','홍보존_게시글1','홍보_게시글1_내용',50,'1',NULL,'7','N',NULL,NULL,NULL,'Y','개발팀',NULL,'test001','2026-01-09 14:22:51.03',NULL,NULL),
	 (30,'BBS_GAL_002','홍보존_게시글2','홍보_게시글2_내용',50,'1',NULL,'8','N',NULL,NULL,NULL,'Y','개발팀',NULL,'test001','2026-01-10 14:22:51.03',NULL,NULL),
	 (31,'BBS_GAL_002','홍보존_게시글3','홍보_게시글3_내용',50,'1',NULL,'9','N',NULL,NULL,NULL,'Y','개발팀',NULL,'test001','2026-01-11 14:22:51.03',NULL,NULL),
	 (34,'BBS_GAL_003','인스타_게시글1','인스타_게시글1_내용',50,'1',NULL,'10','N',NULL,NULL,'https://www.instagram.com/p/DNfLv4av7rc/?utm_source=ig_web_copy_link&igsh=MXJjNHBzZHhzYWc3eg%3D%3D','Y','개발팀',NULL,'test001','2026-01-11 14:22:51.03',NULL,NULL);
INSERT INTO kids_own.tb_pp_m_pst (pst_sn,bbs_id,pst_ttl,pst_cn,pst_inq_cnt,pst_kogl_cprgt_type_cd,atch_file_group_id,thmb_id,fix_yn,fix_bgng_ymd,fix_end_ymd,vdo_url_addr,expsr_yn,wrtr_dept_nm,mdfr_dept_nm,rgtr_id,reg_dt,mdfr_id,mdfcn_dt) VALUES
	 (35,'BBS_GAL_003','인스타_게시글2','인스타_게시글2_내용',50,'1',NULL,'10','N',NULL,NULL,'https://www.instagram.com/p/DNfLv4av7rc/?utm_source=ig_web_copy_link&igsh=MXJjNHBzZHhzYWc3eg%3D%3D','Y','개발팀',NULL,'test001','2026-01-12 14:22:51.03',NULL,NULL),
	 (36,'BBS_GAL_003','인스타_게시글3','인스타_게시글3_내용',50,'1',NULL,'10','N',NULL,NULL,'https://www.instagram.com/p/DNfLv4av7rc/?utm_source=ig_web_copy_link&igsh=MXJjNHBzZHhzYWc3eg%3D%3D','Y','개발팀',NULL,'test001','2026-01-13 14:22:51.03',NULL,NULL),
	 (37,'BBS_GAL_003','인스타_게시글4','인스타_게시글4_내용',50,'1',NULL,'10','N',NULL,NULL,'https://www.instagram.com/p/DNfLv4av7rc/?utm_source=ig_web_copy_link&igsh=MXJjNHBzZHhzYWc3eg%3D%3D','Y','개발팀',NULL,'test001','2026-01-14 14:22:51.03',NULL,NULL),
	 (38,'BBS_GAL_003','인스타_게시글5','인스타_게시글5_내용',50,'1',NULL,'10','N',NULL,NULL,'https://www.instagram.com/p/DNfLv4av7rc/?utm_source=ig_web_copy_link&igsh=MXJjNHBzZHhzYWc3eg%3D%3D','Y','개발팀',NULL,'test001','2026-01-15 14:22:51.03',NULL,NULL),
	 (39,'BBS_GAL_004','블로그_게시글1','블로그_게시글1_내용',50,'1','','11','N',NULL,NULL,'https://blog.naver.com/drugsafe_official/223970486234','Y','개발팀',NULL,'test001','2026-01-11 14:22:51.03',NULL,NULL),
	 (40,'BBS_GAL_004','블로그_게시글2','블로그_게시글2_내용',50,'1','','11','N',NULL,NULL,'https://blog.naver.com/drugsafe_official/223970486234','Y','개발팀',NULL,'test001','2026-01-12 14:22:51.03',NULL,NULL),
	 (41,'BBS_GAL_004','블로그_게시글3','블로그_게시글3_내용',50,'1','','11','N',NULL,NULL,'https://blog.naver.com/drugsafe_official/223970486234','Y','개발팀',NULL,'test001','2026-01-13 14:22:51.03',NULL,NULL),
	 (42,'BBS_GAL_004','블로그_게시글4','블로그_게시글4_내용',50,'1','','11','N',NULL,NULL,'https://blog.naver.com/drugsafe_official/223970486234','Y','개발팀',NULL,'test001','2026-01-14 14:22:51.03',NULL,NULL),
	 (43,'BBS_GAL_004','블로그_게시글5','블로그_게시글5_내용',50,'1','','11','N',NULL,NULL,'https://blog.naver.com/drugsafe_official/223970486234','Y','개발팀',NULL,'test001','2026-01-15 14:22:51.03',NULL,NULL),
	 (46,'BBS_VDO_001','동영상_게시글3','동영상_게시글3_내용',58,'1','','6','N',NULL,NULL,'https://www.youtube.com/watch?v=DK0jpcbOj7k&t=1s','Y','개발팀',NULL,'test001','2026-01-11 14:22:51.03',NULL,NULL);
INSERT INTO kids_own.tb_pp_m_pst (pst_sn,bbs_id,pst_ttl,pst_cn,pst_inq_cnt,pst_kogl_cprgt_type_cd,atch_file_group_id,thmb_id,fix_yn,fix_bgng_ymd,fix_end_ymd,vdo_url_addr,expsr_yn,wrtr_dept_nm,mdfr_dept_nm,rgtr_id,reg_dt,mdfr_id,mdfcn_dt) VALUES
	 (47,'BBS_VDO_001','동영상_게시글4','동영상_게시글4_내용',52,'1','','6','N',NULL,NULL,'https://www.youtube.com/watch?v=5GYlL0fipio','Y','개발팀',NULL,'test001','2026-01-11 14:22:51.03',NULL,NULL),
	 (49,'BBS_VDO_002','유튜브_게시글1','유튜브_게시글1_내용',50,'1',NULL,NULL,'N',NULL,NULL,'https://www.youtube.com/watch?v=n_yGIPkqkyE','Y','개발팀',NULL,'test001','2026-01-11 14:22:51.03',NULL,NULL),
	 (50,'BBS_VDO_002','유튜브_게시글2','유튜브_게시글2_내용',50,'1',NULL,NULL,'N',NULL,NULL,'https://www.youtube.com/watch?v=DK0jpcbOj7k&t=1s','Y','개발팀',NULL,'test001','2026-01-12 14:22:51.03',NULL,NULL),
	 (45,'BBS_VDO_001','동영상_게시글2','동영상_게시글2_내용',54,'1','','6','N',NULL,NULL,'https://www.youtube.com/watch?v=n_yGIPkqkyE','Y','개발팀',NULL,'test001','2026-01-11 14:22:51.03',NULL,NULL),
	 (7,'BBS_COM_001','공지_게시글7','공지_게시글7_내용',52,'1',NULL,NULL,'N',NULL,NULL,NULL,'Y','개발팀',NULL,'test001','2026-01-07 14:22:51.03',NULL,NULL),
	 (28,'BBS_GAL_001','카드뉴스_게시글5','카드_게시글5_내용',70,'1','5','3','N',NULL,NULL,NULL,'Y','개발팀',NULL,'test001','2026-01-15 14:22:51.03',NULL,NULL),
	 (12,'BBS_COM_001','공지_게시글12_첨부파일','공지_게시글12_내용',90,'1','1',NULL,'N',NULL,NULL,NULL,'Y','개발팀',NULL,'test001','2026-01-12 14:22:51.03',NULL,NULL),
	 (11,'BBS_COM_001','공지_게시글11','공지_게시글11_내용',60,'1',NULL,NULL,'N',NULL,NULL,NULL,'Y','개발팀',NULL,'test001','2026-01-11 14:22:51.03',NULL,NULL),
	 (10,'BBS_COM_001','공지_게시글10_고정','공지_게시글10_고정',66,'1',NULL,NULL,'Y',NULL,NULL,NULL,'Y','개발팀',NULL,'test001','2026-01-10 14:22:51.03',NULL,NULL),
	 (3,'BBS_COM_001','공지_게시글3','공지_게시글3_내용',41,'1',NULL,NULL,'N',NULL,NULL,NULL,'Y','개발팀',NULL,'test001','2026-01-03 14:22:51.03',NULL,NULL);
INSERT INTO kids_own.tb_pp_m_pst (pst_sn,bbs_id,pst_ttl,pst_cn,pst_inq_cnt,pst_kogl_cprgt_type_cd,atch_file_group_id,thmb_id,fix_yn,fix_bgng_ymd,fix_end_ymd,vdo_url_addr,expsr_yn,wrtr_dept_nm,mdfr_dept_nm,rgtr_id,reg_dt,mdfr_id,mdfcn_dt) VALUES
	 (9,'BBS_COM_001','공지_게시글9','공지_게시글9_내용',54,'1',NULL,NULL,'N',NULL,NULL,NULL,'Y','개발팀',NULL,'test001','2026-01-09 14:22:51.03',NULL,NULL),
	 (1,'BBS_COM_001','공지_게시글1_고정','공지_게시글1_고정',23,'1',NULL,NULL,'Y',NULL,NULL,NULL,'Y','개발팀',NULL,'test001','2026-01-01 14:22:51.03',NULL,NULL),
	 (14,'BBS_COM_002','채용_게시글2','채용_게시글2_내용',54,'1',NULL,NULL,'N',NULL,NULL,NULL,'Y','개발팀',NULL,'test001','2026-01-02 14:22:51.03',NULL,NULL),
	 (5,'BBS_COM_001','공지_게시글5','공지_게시글5_내용',52,'1',NULL,NULL,'N',NULL,NULL,NULL,'Y','개발팀',NULL,'test001','2026-01-05 14:22:51.03',NULL,NULL),
	 (15,'BBS_COM_002','채용_게시글3','채용_게시글3_내용',56,'1',NULL,NULL,'N',NULL,NULL,NULL,'Y','개발팀',NULL,'test001','2026-01-03 14:22:51.03',NULL,NULL),
	 (51,'BBS_VDO_002','유튜브_게시글3','유튜브_게시글3_내용',50,'1',NULL,NULL,'N',NULL,NULL,'https://www.youtube.com/watch?v=5GYlL0fipio','Y','개발팀',NULL,'test001','2026-01-13 14:22:51.03',NULL,NULL),
	 (52,'BBS_VDO_002','유튜브_게시글4','유튜브_게시글4_내용',50,'1',NULL,NULL,'N',NULL,NULL,'https://www.youtube.com/watch?v=y7ohT0LgAvA&t=2s','Y','개발팀',NULL,'test001','2026-01-14 14:22:51.03',NULL,NULL),
	 (53,'BBS_VDO_002','유튜브_게시글5','유튜브_게시글5_내용',50,'1',NULL,NULL,'N',NULL,NULL,'https://www.youtube.com/watch?v=n_yGIPkqkyE','Y','개발팀',NULL,'test001','2026-01-15 14:22:51.03',NULL,NULL),
	 (54,'BBS_COM_005','자료실_게시글1','자료실_게시글1_내용',52,'1',NULL,NULL,'N',NULL,NULL,'','Y','개발팀',NULL,'test001','2026-01-11 14:22:51.03',NULL,NULL),
	 (55,'BBS_COM_005','자료실_게시글2','자료실_게시글2_내용',54,'1',NULL,NULL,'N',NULL,NULL,'','Y','개발팀',NULL,'test001','2026-01-11 14:22:51.03',NULL,NULL);
INSERT INTO kids_own.tb_pp_m_pst (pst_sn,bbs_id,pst_ttl,pst_cn,pst_inq_cnt,pst_kogl_cprgt_type_cd,atch_file_group_id,thmb_id,fix_yn,fix_bgng_ymd,fix_end_ymd,vdo_url_addr,expsr_yn,wrtr_dept_nm,mdfr_dept_nm,rgtr_id,reg_dt,mdfr_id,mdfcn_dt) VALUES
	 (999,'999','테스트 게시물 1','<!DOCTYPE HTML>
<html lang="ko">
<head>
    <title>KIDS 관리자</title>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=2.0, minimum-scale=1.0, user-scalable=no">
    <meta name="keywords" content="">
    <meta name="decription" content="">
    <meta name="author" content="">
    <link rel="icon" type="image/x-icon" href="../img/kids.ico">
    
    <!-- js -->
    <script type="text/javascript" src="../js/jquery-3.7.1.min.js"></script>
    <script type="text/javascript" src="../js/jquery-ui.min.js"></script>
    <script type="text/javascript" src="../js/bootstrap.min.js"></script>
    
    <!-- datepicker,datetimepicker -->
    <script type="text/javascript" src="../js/datepicker.js"></script>
    <script type="text/javascript" src="../js/jquery.datetimepicker.full.min.js"></script>
    <link rel="stylesheet" href="../css/jquery.datetimepicker.min.css" />
    
    <!-- select2 -->
    <script type="text/javascript" src="../js/select2.min.js"></script>
    <link rel="stylesheet" type="text/css" href="../css/select2.min.css">
    
    <!-- ui js -->
    <script type="text/javascript" src="../js/commonUI.js"></script>
    
    <!-- css -->
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" media="all">
    <link rel="stylesheet" type="text/css" href="../css/style.css">

</head>
<body>

    <div id="wrap">
        <!-- S T A R T :: header -->
        <div id="header">
            <div class="inner">
                <h1 class="logo">
                    <a href="javascript:void(0);">
                        <img src="../img/logo.png" alt="한국의약품안전관리원">
                        <span class="logo_text">통합관리시스템</span>
                    </a>
                </h1>
                <div class="sidebar_controller">
                    <button type="button" class="btn_sidebar"><span class="blind">메뉴바</span></button>
                </div>
                <div class="util_group">
                    <div class="user_info">
                        <p class="user_name"><span>admin</span>님</p>
                        <p class="access">2025-10-21 09:03 접속</p>
                        <div class="notification">
                            <button class="btn_notify">
                                <span class="ico_bell"><span class="blind">알림</span></span>
                                <span class="notify_count">3</span>
                            </button>
                            <div class="notify_box">
                                <p>새 알림 1</p>
                                <p>새 알림 2</p>
                                <p>새 알림 3</p>
                            </div>
                        </div>
                        <button type="button" class="btn_logout">로그아웃</button>
                    </div>
                </div>
            </div>
            <!-- //inner -->
        </div>
        <!-- E N D :: header -->

        <!-- S T A R T :: container -->
        <div id="container" class="sub_container">
            <!-- aside :: s -->
            <div class="aside">
                <div class="aside_inner">
                    <div id="lnb">
                        <ul class="lnb_list">
                            <li><a href="javascript:void(0);">대국민 서비스 포털 관리</a>
                                <ul>
                                    <li><a href="javascript:void(0);">전체메뉴 </a>
                                        <ul>
                                            <li><a href="javascript:void(0);">메뉴1_1_1</a></li>
                                            <li><a href="javascript:void(0);">메뉴1_1_2</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="javascript:void(0);">회원 관리</a></li>
                                    <li><a href="javascript:void(0);">게시판 관리</a></li>
                                    <li><a href="javascript:void(0);">게시물 관리</a></li>
                                    <li><a href="javascript:void(0);">뉴스레터/설문 관리</a></li>
                                    <li><a href="javascript:void(0);">교육 관리</a></li>
                                    <li><a href="javascript:void(0);">사이트 관리</a></li>
                                    <li><a href="javascript:void(0);">원시자료관리</a></li>
                                    <li><a href="javascript:void(0);">충실도 정보관리</a></li>
                                    <li><a href="javascript:void(0);">접속기록 관리</a></li>
                                    <li><a href="javascript:void(0);">DUR 정보관리</a></li>
                                </ul>
                            </li>
                            <li><a href="javascript:void(0);">의약품 안전 통합 교육 플랫폼</a></li>
                            <li><a href="javascript:void(0);">의약품 안전 통합 상담시스템</a>
                                <ul>
                                    <li><a href="javascript:void(0);">LNB 메뉴3_1</a></li>
                                    <li><a href="javascript:void(0);">LNB 메뉴3_2</a></li>
                                    <li><a href="javascript:void(0);">LNB 메뉴4_3</a></li>
                                </ul>
                            </li>
                            <li><a href="javascript:void(0);">안전 정보 관리 업무 지원 시스템</a>
                                <ul>
                                    <li><a href="javascript:void(0);">LNB 메뉴4_1</a></li>
                                    <li><a href="javascript:void(0);">LNB 메뉴4_2</a></li>
                                    <li><a href="javascript:void(0);">LNB 메뉴4_3</a></li>
                                </ul>
                            </li>
                            <li><a href="javascript:void(0);">약물 부작용 포털 및 업무 지원 </a></li>
                            <li><a href="javascript:void(0);">지능형 의약품 안전정보 통합분석</a></li>
                            <li><a href="javascript:void(0);">전문가 관리 시스템</a></li>
                            <li><a href="javascript:void(0);">설문 시스템</a></li>
                            <li><a href="javascript:void(0);">전자문서고</a></li>
                        </ul>
                    </div>
                    <!-- //lnb -->
                </div>
                <!-- //aside_inner -->
            </div>
            <!-- aside :: e -->

            <!-- content_wrap :: s -->
            <div class="content_wrap">
                <div class="location">
                    <div class="page_path">
                        <h2 class="tit">타이틀</h2>
                    </div>
                    <div class="local">
                        <span class="home"><span class="blind">홈</span></span>
                        <span class="route">뎁스1</span>
                        <span class="current">뎁스2</span>
                    </div>
                </div>
                <div class="content">
                <!-- 내용시작 -->
                 
                    컨텐츠
                  
                <!-- //내용시작 -->    
                </div>
                <!-- //content -->
            </div>
            <!-- content_wrap :: e -->
        </div>
        <!-- E N D :: container -->
    </div>
    <!--//wrap -->

</body>
</html>',0,'1',NULL,NULL,'Y','20260128','20260211',NULL,'Y',NULL,'',NULL,'2026-01-28 04:33:30.851883',NULL,'2026-01-28 04:33:30.851883'),
	 (58,'BBS_DUR_001','DUR_게시글2','DUR_게시글2_내용',66,'2',NULL,NULL,'N',NULL,NULL,'','Y','개발팀',NULL,'test001','2026-01-11 14:22:51.03',NULL,NULL),
	 (57,'BBS_DUR_001','DUR_게시글1','DUR_게시글1_내용',128,'3',NULL,NULL,'N',NULL,NULL,'','Y','개발팀',NULL,'test001','2026-01-11 14:22:51.03',NULL,NULL),
	 (44,'BBS_VDO_001','동영상_게시글1','동영상_게시글1_내용',60,'1','5','6','N',NULL,NULL,'https://www.youtube.com/watch?v=y7ohT0LgAvA&t=2s','Y','개발팀',NULL,'test001','2026-01-11 14:22:51.03',NULL,NULL),
	 (56,'BBS_COM_005','자료실_게시글3','자료실_게시글3_내용',52,'1',NULL,NULL,'N',NULL,NULL,'','Y','개발팀',NULL,'test001','2026-01-11 14:22:51.03',NULL,NULL),
	 (48,'BBS_VDO_001','동영상_게시글5','동영상_게시글5_내용',60,'1','','6','N',NULL,NULL,'https://www.youtube.com/watch?v=y7ohT0LgAvA&t=2s','Y','개발팀',NULL,'test001','2026-01-11 14:22:51.03',NULL,NULL),
	 (2,'BBS_COM_001','공지_게시글2','공지_게시글2_내용',41,'1',NULL,NULL,'N',NULL,NULL,NULL,'Y','개발팀',NULL,'test001','2026-01-02 14:22:51.03',NULL,NULL);
