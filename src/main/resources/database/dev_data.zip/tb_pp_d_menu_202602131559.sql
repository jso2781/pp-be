INSERT INTO kids_own.tb_pp_d_menu (menu_sn,menu_url_addr,menu_npag_nm,prvc_incl_yn,dgstfn_exmn_yn,menu_expsr_yn,dept_info_expsr_yn,pic_info_expsr_yn,mobl_aplcn_yn,lgn_yn,encpt_pic_telno,menu_kogl_cprgt_type_cd,menu_pic_id,menu_tkcg_dept_no,rgtr_id,reg_dt,mdfr_id,mdfcn_dt) VALUES
	 ('48','/news/FaqNotice',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157'),
	 ('4','/cms/CmsPage/cms0002',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157'),
	 ('5','/maintask/adverse/report/AdverseKaers',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157'),
	 ('7','https://nedrug.mfds.go.kr/CCCBA03F010/getReport',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157'),
	 ('8','https://nedrug.mfds.go.kr/CCCBA03F010/getReportQuasiDrug',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157'),
	 ('9','/maintask/adverse/AdverseOffline',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157'),
	 ('10','/maintask/adverse/AdverseDataRoom',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157'),
	 ('11','/maintask/adverse/AdverseReportGuide',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157'),
	 ('13','/maintask/sideeffects/Report1',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157'),
	 ('14','https://nedrug.mfds.go.kr/bbs/148',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157');
INSERT INTO kids_own.tb_pp_d_menu (menu_sn,menu_url_addr,menu_npag_nm,prvc_incl_yn,dgstfn_exmn_yn,menu_expsr_yn,dept_info_expsr_yn,pic_info_expsr_yn,mobl_aplcn_yn,lgn_yn,encpt_pic_telno,menu_kogl_cprgt_type_cd,menu_pic_id,menu_tkcg_dept_no,rgtr_id,reg_dt,mdfr_id,mdfcn_dt) VALUES
	 ('16','/maintask/safety/SafetyTerms',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157'),
	 ('17','/maintask/safety/SafetyCausality',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157'),
	 ('18','/maintask/safety/SafetyRelated',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157'),
	 ('20','/maintask/linkage/analysis1',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157'),
	 ('21','https://open.drugsafe.or.kr/analyze/opendatab/List.jsp',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157'),
	 ('23','/cms/CmsPage/cms0001',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157'),
	 ('24','/maintask/dur/DurSearchRoom',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157'),
	 ('25','/maintask/dur/MyDrugInfo',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157'),
	 ('26','/maintask/dur/ApprUseBook',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157'),
	 ('27','/board/general/BBS_DUR_001',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157');
INSERT INTO kids_own.tb_pp_d_menu (menu_sn,menu_url_addr,menu_npag_nm,prvc_incl_yn,dgstfn_exmn_yn,menu_expsr_yn,dept_info_expsr_yn,pic_info_expsr_yn,mobl_aplcn_yn,lgn_yn,encpt_pic_telno,menu_kogl_cprgt_type_cd,menu_pic_id,menu_tkcg_dept_no,rgtr_id,reg_dt,mdfr_id,mdfcn_dt) VALUES
	 ('28','/maintask/dur/DurProposal',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157'),
	 ('30','/maintask/relief/ReliefIntro',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157'),
	 ('31','/maintask/relief/ReliefApply',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157'),
	 ('32','/maintask/relief/ReliefNews',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157'),
	 ('33','https://nedrug.mfds.go.kr',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157'),
	 ('39','https://open.go.kr',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157'),
	 ('40','/open/open/OverseaBizTrips',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157'),
	 ('41','/open/open/BizExpsDetails',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157'),
	 ('42','/open/PublicData',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157'),
	 ('43','/open/disclosure',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157');
INSERT INTO kids_own.tb_pp_d_menu (menu_sn,menu_url_addr,menu_npag_nm,prvc_incl_yn,dgstfn_exmn_yn,menu_expsr_yn,dept_info_expsr_yn,pic_info_expsr_yn,mobl_aplcn_yn,lgn_yn,encpt_pic_telno,menu_kogl_cprgt_type_cd,menu_pic_id,menu_tkcg_dept_no,rgtr_id,reg_dt,mdfr_id,mdfcn_dt) VALUES
	 ('44','/open/BizRealName',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157'),
	 ('46','/board/general/BBS_COM_001',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157'),
	 ('47','/board/general/BBS_COM_002',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157'),
	 ('49','/news/NewsPetition',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157'),
	 ('50','/news/NewsPress',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157'),
	 ('51','/news/NewsLetter',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157'),
	 ('52','/news/NewsLeaflet',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157'),
	 ('53','/board/gallery/BBS_GAL_001',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157'),
	 ('54','/board/video/BBS_VDO_001',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157'),
	 ('55','/board/general/BBS_COM_005',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157');
INSERT INTO kids_own.tb_pp_d_menu (menu_sn,menu_url_addr,menu_npag_nm,prvc_incl_yn,dgstfn_exmn_yn,menu_expsr_yn,dept_info_expsr_yn,pic_info_expsr_yn,mobl_aplcn_yn,lgn_yn,encpt_pic_telno,menu_kogl_cprgt_type_cd,menu_pic_id,menu_tkcg_dept_no,rgtr_id,reg_dt,mdfr_id,mdfcn_dt) VALUES
	 ('57','/about/AboutGreeting',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157'),
	 ('58','/about/AboutFormer',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157'),
	 ('59','/about/AboutHistory',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157'),
	 ('60','/about/AboutVision',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157'),
	 ('61','/about/AboutOrg',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157'),
	 ('62','/about/AboutLaw',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157'),
	 ('63','/about/AboutCharter',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157'),
	 ('64','/about/AboutNews',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157'),
	 ('66','/about/AboutCi/Ci',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157'),
	 ('67','/about/AboutCi/AboutCharacter',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157');
INSERT INTO kids_own.tb_pp_d_menu (menu_sn,menu_url_addr,menu_npag_nm,prvc_incl_yn,dgstfn_exmn_yn,menu_expsr_yn,dept_info_expsr_yn,pic_info_expsr_yn,mobl_aplcn_yn,lgn_yn,encpt_pic_telno,menu_kogl_cprgt_type_cd,menu_pic_id,menu_tkcg_dept_no,rgtr_id,reg_dt,mdfr_id,mdfcn_dt) VALUES
	 ('69','/about/ethics/EthicsAnn',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157'),
	 ('70','/about/ethics/AboutCleanCenter',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157'),
	 ('71','/about/ethics/AboutCleanForm',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157'),
	 ('72','/about/AboutMap',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157'),
	 ('300','https://open.drugsafe.or.kr/analyze/opendatab/List.jsp',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157'),
	 ('302','https://open.drugsafe.or.kr/analyze/opendatab/List.jsp',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157'),
	 ('303','https://open.drugsafe.or.kr/analyze/opendatab/List.jsp',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157'),
	 ('305','https://open.drugsafe.or.kr/analyze/opendatab/List.jsp',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157'),
	 ('306','https://open.drugsafe.or.kr/analyze/opendatab/List.jsp',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157'),
	 ('307','https://open.drugsafe.or.kr/analyze/opendatab/List.jsp',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157');
INSERT INTO kids_own.tb_pp_d_menu (menu_sn,menu_url_addr,menu_npag_nm,prvc_incl_yn,dgstfn_exmn_yn,menu_expsr_yn,dept_info_expsr_yn,pic_info_expsr_yn,mobl_aplcn_yn,lgn_yn,encpt_pic_telno,menu_kogl_cprgt_type_cd,menu_pic_id,menu_tkcg_dept_no,rgtr_id,reg_dt,mdfr_id,mdfcn_dt) VALUES
	 ('308','https://open.drugsafe.or.kr/analyze/opendatab/List.jsp',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157'),
	 ('309','https://open.drugsafe.or.kr/analyze/opendatab/List.jsp',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157'),
	 ('310','https://open.drugsafe.or.kr/analyze/opendatab/List.jsp',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157'),
	 ('311','https://open.drugsafe.or.kr/analyze/opendatab/List.jsp',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157'),
	 ('313','https://open.drugsafe.or.kr/analyze/opendatab/List.jsp',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157'),
	 ('314','https://open.drugsafe.or.kr/analyze/opendatab/List.jsp',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157'),
	 ('38','/cms/CmsPage/cms0013',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157'),
	 ('304','https://www.naver.com/',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157'),
	 ('312','/ko/board/general/BBS_COM_001',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157'),
	 ('315','/ko/board/general/BBS_COM_001',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157');
INSERT INTO kids_own.tb_pp_d_menu (menu_sn,menu_url_addr,menu_npag_nm,prvc_incl_yn,dgstfn_exmn_yn,menu_expsr_yn,dept_info_expsr_yn,pic_info_expsr_yn,mobl_aplcn_yn,lgn_yn,encpt_pic_telno,menu_kogl_cprgt_type_cd,menu_pic_id,menu_tkcg_dept_no,rgtr_id,reg_dt,mdfr_id,mdfcn_dt) VALUES
	 ('299','/ko/expert/ExpertApproval',NULL,'Y','Y','Y','Y','Y','Y','N','02-2172-3868','4','B0542','0000004','SYSTEM','2026-01-28 23:10:45.549157','SYSTEM','2026-01-28 23:10:45.549157');
