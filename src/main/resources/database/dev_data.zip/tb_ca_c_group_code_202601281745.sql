INSERT INTO kids_own.tb_ca_c_group_code (com_group_cd,group_cd_nm,group_cd_expln,group_cd_abbr_nm,group_cd_rsvt_cn_1,group_cd_rsvt_cn_2,group_cd_rsvt_cn_3,group_cd_rsvt_cn_4,group_cd_rsvt_cn_5,reg_dt,rgtr_id,mdfcn_dt,mdfr_id) VALUES
	 ('EX0006','자문이메일구분코드','자문위원(위촉장,섭외요청 등) 이메일 데이터를 분류하기 위한 코드 값','CNSTN_EML_SE_CD',NULL,NULL,NULL,NULL,NULL,'2026-01-27 08:36:49.798','exdev01','2026-01-27 08:36:49.798','exdev01'),
	 ('EX0007','자문제출구분코드','작성서류(온라인,오프라인) 제출구분을 위한 코드 값','CNSTN_SBMSN_SE_CD',NULL,NULL,NULL,NULL,NULL,'2026-01-27 08:36:49.798','exdev01','2026-01-27 08:36:49.798','exdev01'),
	 ('EX0008','자문항목유형코드','자문항목의(일반,부연설명 등) 유형을 구분하는 코드','CNSTN_ARTCL_TYPE_CD',NULL,NULL,NULL,NULL,NULL,'2026-01-27 08:36:49.798','exdev01','2026-01-27 08:36:49.798','exdev01'),
	 ('EX0009','자문선택유형코드','선택 조건(단일,다건) 유형을 구분하는 코드','CNSTN_CHC_TYPE_CD',NULL,NULL,NULL,NULL,NULL,'2026-01-27 08:36:49.798','exdev01','2026-01-27 08:36:49.798','exdev01'),
	 ('EX0010','자문발송상태구분코드','자문발송상태(발송,성공,실패 등) 데이터를 분류하기 위한 코드 값','CNSTN_SNDNG_STTS_SE_CD',NULL,NULL,NULL,NULL,NULL,'2026-01-27 08:36:49.798','exdev01','2026-01-27 08:36:49.798','exdev01'),
	 ('EX0011','자문진행단계코드','자문 작업 또는 절차의 현재 상태를 나타내틑 코드','CNSTN_PRGRS_STP_CD',NULL,NULL,NULL,NULL,NULL,'2026-01-27 08:36:49.798','exdev01','2026-01-27 08:36:49.798','exdev01'),
	 ('EX0001','전문가성별코드','전문가성별코드','EXPRT_GNDR_CD',NULL,NULL,NULL,NULL,NULL,'2026-01-27 08:36:49.798','exdev01','2026-01-27 08:36:49.798','exdev01'),
	 ('EX0002','위원상태구분코드','위원상태구분코드','MBCMT_STTS_SE_CD',NULL,NULL,NULL,NULL,NULL,'2026-01-27 08:36:49.798','exdev01','2026-01-27 08:36:49.798','exdev01'),
	 ('EX0003','위원지역구분코드','자문위원들의 지역을 고유하게 식별하기 위한 코드','MBCMT_RGN_CD',NULL,NULL,NULL,NULL,NULL,'2026-01-27 08:36:49.798','exdev01','2026-01-27 08:36:49.798','exdev01'),
	 ('EX0004','위원활동유형코드','활동유형(전문,상임) 데이터를 분류하기 위한 코드 값','MBCMT_ACTV_TYPE_CD',NULL,NULL,NULL,NULL,NULL,'2026-01-27 08:36:49.798','exdev01','2026-01-27 08:36:49.798','exdev01');
INSERT INTO kids_own.tb_ca_c_group_code (com_group_cd,group_cd_nm,group_cd_expln,group_cd_abbr_nm,group_cd_rsvt_cn_1,group_cd_rsvt_cn_2,group_cd_rsvt_cn_3,group_cd_rsvt_cn_4,group_cd_rsvt_cn_5,reg_dt,rgtr_id,mdfcn_dt,mdfr_id) VALUES
	 ('EX0005','회의문서구분코드','회의문서(회의록,기타) 구분을 위한 코드 값','MTG_DOC_SE_CD',NULL,NULL,NULL,NULL,NULL,'2026-01-27 08:36:49.798','exdev01','2026-01-27 08:36:49.798','exdev01');
