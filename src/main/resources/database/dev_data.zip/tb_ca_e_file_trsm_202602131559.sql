INSERT INTO kids_own.tb_ca_e_file_trsm (atch_file_id,atch_file_group_id,file_seq,file_strg_path_dsctn,encpt_file_nm,prvc_incl_yn,file_nm,file_extn_nm,file_cn,file_sz,crt_dt,use_yn,reg_dt,rgtr_id,mdfcn_dt,mdfr_id) VALUES
	 ('1','1',1,'fileTest\20260112\','test.txt','N','test.txt','txt','파일내용',135975,NULL,'Y',NULL,NULL,NULL,NULL),
	 ('2','2',1,'fileTest\20260112\','imageTest_tsla_logo.png','N','imageTest_tsla_logo.png','png','파일내용',135975,NULL,'Y',NULL,NULL,NULL,NULL),
	 ('3','3',1,'fileTest\20260112\','imageTest_car_logo2.png','N','imageTest_car_logo2.png','png','파일내용',135975,NULL,'Y',NULL,NULL,NULL,NULL),
	 ('4','4',1,'fileTest\20260112\','imageTest_tsla.png','N','imageTest_tsla.png','png','파일내용',135975,NULL,'Y',NULL,NULL,NULL,NULL),
	 ('5','5',1,'fileTest\20260112\','imageTest_tsla2.png','N','imageTest_tsla2.png','png','파일내용',135975,NULL,'Y',NULL,NULL,NULL,NULL),
	 ('6','6',1,'fileTest\20260112\','imageTest_youtube_logo.png','N','imageTest_youtube_logo.png','png','파일내용',135975,NULL,'Y',NULL,NULL,NULL,NULL),
	 ('7','7',1,'fileTest\20260112\','pop1.png','N','pop1.png','png','파일내용',135975,NULL,'Y',NULL,NULL,NULL,NULL),
	 ('8','8',1,'fileTest\20260112\','pop2.png','N','pop2.png','png','파일내용',135975,NULL,'Y',NULL,NULL,NULL,NULL),
	 ('9','9',1,'fileTest\20260112\','pop3.png','N','pop3.png','png','파일내용',135975,NULL,'Y',NULL,NULL,NULL,NULL),
	 ('10','10',1,'fileTest\20260112\','imageTest_insta.png','N','imageTest_insta.png','png','파일내용',135975,NULL,'Y',NULL,NULL,NULL,NULL);
INSERT INTO kids_own.tb_ca_e_file_trsm (atch_file_id,atch_file_group_id,file_seq,file_strg_path_dsctn,encpt_file_nm,prvc_incl_yn,file_nm,file_extn_nm,file_cn,file_sz,crt_dt,use_yn,reg_dt,rgtr_id,mdfcn_dt,mdfr_id) VALUES
	 ('11','11',1,'fileTest\20260112\','imageTest_blog.png','N','imageTest_blog.png','png','파일내용',135975,NULL,'Y',NULL,NULL,NULL,NULL);
