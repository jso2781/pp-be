INSERT INTO kids_own.tb_pp_m_bbs (bbs_id,bbs_nm,bbs_atrb_cd,bbs_expln,bbs_smry_cn,cmnt_use_yn,inq_cnt_expsr_yn,dept_expsr_yn,file_atch_yn,atch_psblty_file_cnt,lang_se_cd,use_yn,rgtr_id,reg_dt,mdfr_id,mdfcn_dt) VALUES
	 ('999','테스트 게시판 1','GNR','이것은 테스트요','테스트 머릿말','Y','Y','Y','Y',5,'KOR','Y',NULL,'2026-01-28 01:23:39.573363',NULL,'2026-01-28 01:44:42.653355');
