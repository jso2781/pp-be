INSERT INTO kids_own.tb_pp_m_popup (popup_sn,popup_ttl,popup_pstg_bgng_dt,popup_pstg_end_dt,popup_lnkg_addr,popup_seq,popup_pstg_yn,popup_npag_yn,popup_expln,atch_file_group_id,wrtr_dept_nm,mdfr_dept_nm,rgtr_id,reg_dt,mdfr_id,mdfcn_dt) VALUES
	 (1,'사용자팝업1','2026-01-20 13:03:54.254','2026-04-25 13:03:54.254','https://www.drugsafe.or.kr/ko/index.do',1,'Y','N',NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL),
	 (2,'사용자팝업2','2026-01-20 13:03:54.254','2026-04-25 13:03:54.254','https://www.drugsafe.or.kr/ko/index.do',2,'Y','N',NULL,'8',NULL,NULL,NULL,NULL,NULL,NULL),
	 (3,'사용자팝업3','2026-01-20 13:03:54.254','2026-04-25 13:03:54.254','https://www.drugsafe.or.kr/ko/index.do',3,'Y','N',NULL,'9',NULL,NULL,NULL,NULL,NULL,NULL),
	 (4,'사용자팝업4','2026-01-20 13:03:54.254','2026-04-25 13:03:54.254','https://www.drugsafe.or.kr/ko/index.do',4,'Y','N',NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL);
