INSERT INTO kids_own.tb_pp_m_authrt (authrt_cd,up_authrt_cd,task_se_cd,authrt_nm,authrt_type_cd,authrt_expln,use_yn,wrtr_dept_nm,mdfr_dept_nm,rgtr_id,reg_dt,mdfr_id,mdfcn_dt) VALUES
	 ('YG_MNG','HOME_MNG','PP','약관법령 관리',NULL,NULL,'Y',NULL,NULL,NULL,NULL,NULL,NULL),
	 ('MAIN_MNG','HOME_MNG','PP','메인 관리',NULL,NULL,'Y',NULL,NULL,NULL,NULL,NULL,NULL),
	 ('BBS_MNG','HOME_MNG','PP','게시판 관리',NULL,NULL,'Y',NULL,NULL,NULL,NULL,NULL,NULL),
	 ('GG_AUTHOR','EXPRT_AUTH','PP','기관 관리자',NULL,NULL,'Y',NULL,NULL,NULL,NULL,NULL,NULL),
	 ('JJ_USE','DUR_INFO','PP','적정사용정보',NULL,NULL,'Y',NULL,NULL,NULL,NULL,NULL,NULL),
	 ('DU_BBS_MNG','DUR_INFO','PP','DUR 게시판 관리',NULL,NULL,'Y',NULL,NULL,NULL,NULL,NULL,NULL),
	 ('AUTH_EXPRT','AUTH_ADMIN','PP','전문가 관리',NULL,NULL,'Y',NULL,NULL,NULL,NULL,NULL,NULL),
	 ('AUTH_MENU','AUTH_ADMIN','PP','메뉴 관리',NULL,NULL,'Y',NULL,NULL,NULL,NULL,NULL,NULL),
	 ('AUTH_ADMIN','','PP','권한 관리자',NULL,NULL,'Y',NULL,NULL,NULL,NULL,NULL,NULL),
	 ('DUR_INFO','','PP','DUR 정보 관리',NULL,NULL,'Y',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO kids_own.tb_pp_m_authrt (authrt_cd,up_authrt_cd,task_se_cd,authrt_nm,authrt_type_cd,authrt_expln,use_yn,wrtr_dept_nm,mdfr_dept_nm,rgtr_id,reg_dt,mdfr_id,mdfcn_dt) VALUES
	 ('HOME_MNG','','PP','홈페이지 관리',NULL,NULL,'Y',NULL,NULL,NULL,NULL,NULL,NULL),
	 ('EXPRT_AUTH','','PP','전문가 권한',NULL,NULL,'Y',NULL,NULL,NULL,NULL,NULL,NULL);
