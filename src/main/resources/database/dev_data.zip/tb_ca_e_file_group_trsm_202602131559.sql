INSERT INTO kids_own.tb_ca_e_file_group_trsm (atch_file_group_id,task_se_cd,task_se_trgt_id,use_yn,reg_dt,rgtr_id,mdfcn_dt,mdfr_id) VALUES
	 ('1','',NULL,' ',NULL,NULL,NULL,NULL),
	 ('2','',NULL,' ',NULL,NULL,NULL,NULL),
	 ('3','',NULL,' ',NULL,NULL,NULL,NULL),
	 ('4','',NULL,' ',NULL,NULL,NULL,NULL),
	 ('5','',NULL,' ',NULL,NULL,NULL,NULL),
	 ('6','',NULL,' ',NULL,NULL,NULL,NULL),
	 ('7','',NULL,' ',NULL,NULL,NULL,NULL),
	 ('8','',NULL,' ',NULL,NULL,NULL,NULL),
	 ('9','',NULL,' ',NULL,NULL,NULL,NULL),
	 ('10','',NULL,' ',NULL,NULL,NULL,NULL);
INSERT INTO kids_own.tb_ca_e_file_group_trsm (atch_file_group_id,task_se_cd,task_se_trgt_id,use_yn,reg_dt,rgtr_id,mdfcn_dt,mdfr_id) VALUES
	 ('11','',NULL,' ',NULL,NULL,NULL,NULL);
