INSERT INTO kids_own.tb_pp_m_dept_authrt (dept_no,authrt_cd,dept_authrt_rmrk_cn,rgtr_id,reg_dt,mdfr_id,mdfcn_dt) VALUES
	 ('0000999','DEPT_AUTH',NULL,'choi','2026-02-13 13:06:40.22723','choi','2026-02-13 13:06:40.22723'),
	 ('0000999','DR_A04',NULL,'admin','2026-02-19 13:46:51.029828','admin','2026-02-19 13:46:51.029828');
