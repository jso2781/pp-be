INSERT INTO kids_own.tb_pp_m_trms_stt (trms_stt_sn,trms_stt_cd,trms_stt_aplcn_ymd,trms_stt_end_ymd,trms_stt_cn,atch_file_group_id,wrtr_dept_nm,mdfr_dept_nm,rgtr_id,reg_dt,mdfr_id,mdfcn_dt) VALUES
	 (1,'CLCT','20260211','20991230','test',NULL,NULL,NULL,'test','2026-02-11 18:18:11.019','test','2026-02-11 18:18:11.019'),
	 (3,'CLCT_ES_CH','20260211','20991230','test',NULL,NULL,NULL,'test','2026-02-11 18:18:11.019','test','2026-02-11 18:18:11.019'),
	 (9,'UTZTN','20260211','20991230','test',NULL,NULL,NULL,'test','2026-02-11 18:18:11.019','test','2026-02-11 18:18:11.019'),
	 (7,'STT_PRVC_ED','20260211','20991230','test',NULL,NULL,NULL,'test','2026-02-11 18:18:11.019','test','2026-02-11 18:18:11.019'),
	 (6,'STT_PRVC_CM','20260211','20991230','test',NULL,NULL,NULL,'test','2026-02-11 18:18:11.019','test','2026-02-11 18:18:11.019'),
	 (8,'STT_PRVC_PP','20260215','20991230','test',NULL,NULL,NULL,'test','2026-02-11 18:18:11.019','test','2026-02-11 18:18:11.019'),
	 (5,'STT_CCTV','20260214','20991230','test',NULL,NULL,NULL,'test','2026-02-11 18:18:11.019','test','2026-02-11 18:18:11.019'),
	 (2,'STTY_AGT','20260213','20991230','test',NULL,NULL,NULL,'test','2026-02-11 18:18:11.019','test','2026-02-11 18:18:11.019'),
	 (4,'STT_EML','20260212','20991230','test',NULL,NULL,NULL,'test','2026-02-11 18:18:11.019','test','2026-02-11 18:18:11.019');
