INSERT INTO kids_own.tb_ex_e_wrt (cmt_sn,cnstn_sn,cnstn_wrt_sn,wrt_group_sn,up_wrt_sn,levl_no,levl_seq,cnstn_artcl_nm,cnstn_artcl_type_cd,cnstn_chc_type_cd,cnstn_wrt_cn,ref_expln_atch_file_id,dgt_lmt_yn,rgtr_id,reg_dt,mdfr_id,mdfcn_dt) VALUES
	 (1,2,2,NULL,NULL,'1',0,'A','01',NULL,'의심부작용 인정',NULL,'Y','SYSTEM','2026-02-19 07:45:25.425941','SYSTEM','2026-02-19 07:45:25.425941'),
	 (1,2,3,NULL,2,'2',0,'A.1','01',NULL,'<p><span style="color:hsl(0, 0%, 30%);font-family:굴림, Gulim, sans-serif;font-size:24px;"><strong>의심부작용명 확인</strong></span></p>',NULL,'Y','SYSTEM','2026-02-19 07:45:25.425941','SYSTEM','2026-02-19 07:45:25.425941'),
	 (1,2,4,NULL,3,'2',0,'temp-sub-1771487126930','02',NULL,'선정약제 각각에 대한 인과성 분류정도 ',NULL,'Y','SYSTEM','2026-02-19 07:45:25.425941','SYSTEM','2026-02-19 07:45:25.425941'),
	 (1,2,5,NULL,2,'2',0,'A.2','01',NULL,'<p><span style="color:hsl(150, 75%, 60%);font-size:24px;"><strong>의심부작용 발생 추정일</strong></span></p>',NULL,'Y','SYSTEM','2026-02-19 07:45:25.425941','SYSTEM','2026-02-19 07:45:25.425941'),
	 (1,2,6,NULL,NULL,'1',0,'B','01',NULL,'의심부작용 불인정',NULL,'Y','SYSTEM','2026-02-19 07:45:25.425941','SYSTEM','2026-02-19 07:45:25.425941'),
	 (1,2,7,NULL,6,'2',0,'B.1','01',NULL,'<p><span style="color:hsl(30, 75%, 60%);font-size:24px;"><strong>의약품 사용의 적성성</strong></span></p>',NULL,'Y','SYSTEM','2026-02-19 07:45:25.425941','SYSTEM','2026-02-19 07:45:25.425941'),
	 (1,3,28,NULL,NULL,'1',0,'A','01',NULL,'의약품부작용 인정',NULL,'Y','SYSTEM','2026-02-19 07:55:12.50119','SYSTEM','2026-02-19 07:55:12.50119'),
	 (1,3,29,NULL,28,'2',0,'A.1','01',NULL,'의심부작용명 확인',NULL,'Y','SYSTEM','2026-02-19 07:55:12.50119','SYSTEM','2026-02-19 07:55:12.50119'),
	 (1,3,30,NULL,28,'2',0,'A.2','01',NULL,'<p><span style="color:hsl(210,75%,60%);font-size:21px;"><strong>의심부작용 발생 추장일</strong></span></p>',NULL,'Y','SYSTEM','2026-02-19 07:55:12.50119','SYSTEM','2026-02-19 07:55:12.50119'),
	 (1,3,31,NULL,28,'2',0,'A.3','01',NULL,'장애 고정추정일(완치일)의 확인',NULL,'Y','SYSTEM','2026-02-19 07:55:12.50119','SYSTEM','2026-02-19 07:55:12.50119');
INSERT INTO kids_own.tb_ex_e_wrt (cmt_sn,cnstn_sn,cnstn_wrt_sn,wrt_group_sn,up_wrt_sn,levl_no,levl_seq,cnstn_artcl_nm,cnstn_artcl_type_cd,cnstn_chc_type_cd,cnstn_wrt_cn,ref_expln_atch_file_id,dgt_lmt_yn,rgtr_id,reg_dt,mdfr_id,mdfcn_dt) VALUES
	 (1,3,32,NULL,31,'2',0,'temp-sub-1771487321850','02',NULL,'3번 문항은 해당 관련 분야의 전문위원 분만 의견주십시오. ',NULL,'Y','SYSTEM','2026-02-19 07:55:12.50119','SYSTEM','2026-02-19 07:55:12.50119'),
	 (1,3,33,NULL,28,'1',0,'temp-sub-1771487381099','02',NULL,'※ 장애일시 보상금',NULL,'Y','SYSTEM','2026-02-19 07:55:12.50119','SYSTEM','2026-02-19 07:55:12.50119'),
	 (1,3,34,NULL,28,'2',0,'A.4','01',NULL,'<p><span style="background-color:hsl(30, 75%, 60%);color:hsl(0, 0%, 0%);"><strong>의약품부작용과 장애 사이의 인과관계 평가</strong></span></p>',NULL,'Y','SYSTEM','2026-02-19 07:55:12.50119','SYSTEM','2026-02-19 07:55:12.50119'),
	 (1,3,35,NULL,34,'3',0,'A.4-1','01',NULL,'<p><span style="color:hsl(0, 75%, 60%);"><strong>보상금 지급 여부에 대한 의견</strong></span></p>',NULL,'Y','SYSTEM','2026-02-19 07:55:12.50119','SYSTEM','2026-02-19 07:55:12.50119'),
	 (1,3,36,NULL,NULL,'1',0,'B','01',NULL,'의약품부작용 불인정',NULL,'Y','SYSTEM','2026-02-19 07:55:12.50119','SYSTEM','2026-02-19 07:55:12.50119'),
	 (1,3,37,NULL,36,'2',0,'B.1','01',NULL,'의심부작용 발생 추장일',NULL,'Y','SYSTEM','2026-02-19 07:55:12.50119','SYSTEM','2026-02-19 07:55:12.50119');
