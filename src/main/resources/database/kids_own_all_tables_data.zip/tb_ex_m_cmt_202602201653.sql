INSERT INTO kids_own.tb_ex_m_cmt (cmt_sn,cmt_se_cd,cmt_nm,actv_prd_bgng_ymd,actv_prd_end_ymd,dept_cd,sthdr_sngl_wrt_yn,entrst_doc_no,entrst_cn,rgtr_id,reg_dt,mdfr_id,mdfcn_dt) VALUES
	 (1,'전문','[단위] 19기 의약품 안전원 위원회','20260209','20270218','0000081','N','제 KARP-25','귀하를 한국의약품 안전관리원 제 6기 의약품 부작용 전문위원회 전문가단으로 위촉합니다','SYSTEM','2026-02-10 01:04:32.677538','system','2026-02-19 07:35:30.72728');
