INSERT INTO kids_own.tb_ex_e_slctn (agnd_cnstn_mbcmt_sn,cmt_sn,cnstn_sn,cnstn_mbcmt_sn,cnstn_prgrs_stp_cd,indiv_prd_bgng_ymd,indiv_prd_end_ymd,acpt_yn,cntct_dmnd_hstry_sn,cnstn_dmnd_hstry_sn,resub_yn,cfmtn_yn,rel_cn,cmpln_cn,stats_incl_yn,reg_dt,mdfr_id,mdfcn_dt,rgtr_id) VALUES
	 (4,1,3,8,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Y','2026-02-19 08:44:15.23974','SYSTEM','2026-02-19 08:44:15.23974','SYSTEM'),
	 (5,1,3,9,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Y','2026-02-19 08:44:15.23974','SYSTEM','2026-02-19 08:44:15.23974','SYSTEM'),
	 (3,1,3,7,'01','        ','        ','Y',3,6,NULL,NULL,NULL,NULL,'Y','2026-02-19 08:43:09.708952','admin','2026-02-19 08:45:49.457896','SYSTEM'),
	 (2,1,3,6,'01','        ','        ','Y',4,7,NULL,NULL,NULL,NULL,'Y','2026-02-19 08:43:09.708952','admin','2026-02-19 08:45:49.462119','SYSTEM'),
	 (1,1,3,5,'02','        ','        ','Y',5,8,NULL,NULL,NULL,NULL,'Y','2026-02-19 08:43:09.708952','SYSTEM','2026-02-20 06:49:31.777833','SYSTEM');
