INSERT INTO kids_own.tb_ex_m_subsc (cmt_sn,subcm_sn,subcm_cmt_nm,rmrk_cn,rgtr_id,reg_dt,mdfr_id,mdfcn_dt) VALUES
	 (1,1,'19기 소분과위원회 ','19기 소분과1','admin','2026-02-11 02:13:12.958445','admin','2026-02-11 02:13:16.945618');
