INSERT INTO kids_own.tb_ex_m_scmt (cmt_sn,scmt_group_sn,scmt_group_nm,scmt_group_expln,rgtr_id,reg_dt,mdfr_id,mdfcn_dt) VALUES
	 (1,1,'19기 분과위원회','19기 분과위원회 1','admin','2026-02-11 02:12:30.534705','admin','2026-02-11 02:12:40.299253');
