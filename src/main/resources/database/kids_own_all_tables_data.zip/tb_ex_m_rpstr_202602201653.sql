INSERT INTO kids_own.tb_ex_m_rpstr (rpstr_sn,atch_file_id,dept_cd,rpstr_ttl,rpstr_cn,rmrk_cn,rgtr_id,reg_dt,mdfr_id,mdfcn_dt) VALUES
	 (1,'test1','0000081','26년 사용자 메뉴얼 등록','사용자 메뉴얼 등록합니다 . 1','비고에 대한 메뉴얼 1','admin','2026-02-10 08:37:05.537985','admin','2026-02-10 08:37:15.738515'),
	 (2,'test1','0000081','운영자 메뉴얼 등록 ','운영자 메뉴얼 등록합니다 .','ㅇ운영자 메뉴얼입니다 ,','admin','2026-02-10 08:37:50.992799','admin','2026-02-10 08:37:50.99282');
