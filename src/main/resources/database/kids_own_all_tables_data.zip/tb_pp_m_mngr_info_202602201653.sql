INSERT INTO kids_own.tb_pp_m_mngr_info (emp_no,encpt_mngr_pswd,tmpr_pswd_yn,pswd_err_nmtm,encpt_bfr_pswd,rgtr_id,reg_dt,mdfr_id,mdfcn_dt) VALUES
	 ('A9999','Rmawk!2505','N',0,'Kids2172!@#','choi','2026-02-13 12:59:48.24679','choi','2026-02-20 16:48:33.489575');
