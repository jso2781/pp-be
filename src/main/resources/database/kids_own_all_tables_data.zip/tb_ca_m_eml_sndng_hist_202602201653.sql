INSERT INTO kids_own.tb_ca_m_eml_sndng_hist (eml_sndng_hstry_sn,eml_sndng_sn,rcvr_eml_addr,rcvr_flnm,sndng_rslt_cd,fail_rsn,rsnd_nmtm,dsptch_dt,otsd_eml_orgnl_rslt_cd,otsd_eml_err_msg,otsd_eml_msg_id,reg_dt,rgtr_id,mdfcn_dt,mdfr_id) VALUES
	 (6,11,'hong22@bbb.bbb','길','0',NULL,NULL,NULL,'0','URI is not absolute',NULL,'2026-02-10 13:28:38.400886','SYSTEM','2026-02-10 13:28:38.400886','SYSTEM'),
	 (7,12,'hong22@bbb.bbb','길','0',NULL,NULL,NULL,'0','URI is not absolute',NULL,'2026-02-12 11:33:26.333634','SYSTEM','2026-02-12 11:33:26.333634','SYSTEM'),
	 (8,13,'hong22@bbb.bbb','길','0',NULL,NULL,NULL,'0','URI is not absolute',NULL,'2026-02-12 11:33:55.987265','SYSTEM','2026-02-12 11:33:55.987265','SYSTEM'),
	 (9,14,'receiver2@test.com','수신자','1',NULL,NULL,NULL,'1',NULL,'TEST-MODE','2026-02-12 12:32:59.596808','SYSTEM','2026-02-12 12:32:59.596808','SYSTEM'),
	 (10,15,'receiver2@test.com','수신자','1',NULL,NULL,NULL,'1',NULL,'TEST-MODE','2026-02-12 12:43:23.961389','SYSTEM','2026-02-12 12:43:23.961389','SYSTEM'),
	 (11,16,'receiver2@test.com','수신자','1',NULL,NULL,NULL,'1',NULL,'TEST-MODE','2026-02-12 12:45:45.322717','SYSTEM','2026-02-12 12:45:45.322717','SYSTEM'),
	 (12,17,'hong22@bbb.bbb','길','1',NULL,NULL,NULL,'1',NULL,'TEST-MODE','2026-02-12 12:54:31.268781','SYSTEM','2026-02-12 12:54:31.268781','SYSTEM'),
	 (13,18,'hong22@bbb.bbb','길','1',NULL,NULL,NULL,'1',NULL,'TEST-MODE','2026-02-12 12:54:50.500477','SYSTEM','2026-02-12 12:54:50.500477','SYSTEM'),
	 (14,19,'hong22@bbb.bbb','길','1',NULL,NULL,NULL,'1',NULL,'TEST-MODE','2026-02-12 12:54:56.814497','SYSTEM','2026-02-12 12:54:56.814497','SYSTEM'),
	 (15,20,'receiver2@test.com','수신자','1',NULL,NULL,NULL,'1',NULL,'TEST-MODE','2026-02-12 14:52:28.90218','SYSTEM','2026-02-12 14:52:28.90218','SYSTEM');
INSERT INTO kids_own.tb_ca_m_eml_sndng_hist (eml_sndng_hstry_sn,eml_sndng_sn,rcvr_eml_addr,rcvr_flnm,sndng_rslt_cd,fail_rsn,rsnd_nmtm,dsptch_dt,otsd_eml_orgnl_rslt_cd,otsd_eml_err_msg,otsd_eml_msg_id,reg_dt,rgtr_id,mdfcn_dt,mdfr_id) VALUES
	 (16,21,'receiver2@test.com','수신자','1',NULL,NULL,NULL,'1',NULL,'TEST-MODE','2026-02-19 16:02:10.456022','SYSTEM','2026-02-19 16:02:10.456022','SYSTEM'),
	 (17,22,'receiver2@test.com','수신자','1',NULL,NULL,NULL,'1',NULL,'TEST-MODE','2026-02-19 16:48:21.160515','SYSTEM','2026-02-19 16:48:21.160515','SYSTEM'),
	 (18,23,'receiver2@test.com','수신자','1',NULL,NULL,NULL,'1',NULL,'TEST-MODE','2026-02-20 15:39:45.828143','SYSTEM','2026-02-20 15:39:45.828143','SYSTEM');
