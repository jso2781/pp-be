INSERT INTO kids_own.tb_ex_m_opnn (agnd_cnstn_mbcmt_sn,opnn_sn,cnstn_opnn_ttl,cnstn_opnn_cn,atch_file_id,rgtr_id,reg_dt,mdfr_id,mdfcn_dt) VALUES
	 (1,1,'장애 안건에 대해 질의드립니다.','KARP-24-D 장애 사항이 맞는지 의견 등록합니다. ',NULL,'SYSTEM','2026-02-20 06:04:24.365249','SYSTEM','2026-02-20 06:04:24.365249');
