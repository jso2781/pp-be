INSERT INTO kids_own.tb_ca_m_eml_sndng (eml_sndng_sn,eml_ttl,eml_cn,sndpty_flnm,sndpty_eml_addr,otsd_eml_dmnd_id,rcvr_flnm,rcvr_eml_addr,rcvr_jbps_nm,sndng_rslt_cd,atch_file_id,dsptch_dt,reg_dt,rgtr_id,mdfcn_dt,mdfr_id) VALUES
	 (11,'테스트','테스트','홍','hong@bbb.bbb',NULL,'길','hong22@bbb.bbb',NULL,'0',NULL,NULL,'2026-02-10 13:28:38.400886','SYSTEM','2026-02-10 13:28:38.400886','SYSTEM'),
	 (12,'h','h','홍','hong@bbb.bbb',NULL,'길','hong22@bbb.bbb',NULL,'0',NULL,NULL,'2026-02-12 11:33:26.333634','SYSTEM','2026-02-12 11:33:26.333634','SYSTEM'),
	 (13,'g','g','홍','hong@bbb.bbb',NULL,'길','hong22@bbb.bbb',NULL,'0',NULL,NULL,'2026-02-12 11:33:55.987265','SYSTEM','2026-02-12 11:33:55.987265','SYSTEM'),
	 (14,'테스트 제목','테스트 내용','발신자','sender@test.com',NULL,'수신자','receiver2@test.com',NULL,'1',NULL,NULL,'2026-02-12 12:32:59.596808','SYSTEM','2026-02-12 12:32:59.596808','SYSTEM'),
	 (15,'테스트 제목','테스트 내용','발신자','sender@test.com',NULL,'수신자','receiver2@test.com',NULL,'1',NULL,NULL,'2026-02-12 12:43:23.961389','SYSTEM','2026-02-12 12:43:23.961389','SYSTEM'),
	 (16,'테스트 제목','테스트 내용','발신자','sender@test.com',NULL,'수신자','receiver2@test.com',NULL,'1',NULL,NULL,'2026-02-12 12:45:45.322717','SYSTEM','2026-02-12 12:45:45.322717','SYSTEM'),
	 (17,'g','g','홍','hong@bbb.bbb',NULL,'길','hong22@bbb.bbb',NULL,'1',NULL,NULL,'2026-02-12 12:54:31.268781','SYSTEM','2026-02-12 12:54:31.268781','SYSTEM'),
	 (18,'g','g','홍','hong@bbb.bbb',NULL,'길','hong22@bbb.bbb',NULL,'1',NULL,NULL,'2026-02-12 12:54:50.500477','SYSTEM','2026-02-12 12:54:50.500477','SYSTEM'),
	 (19,'g','g','홍','hong@bbb.bbb',NULL,'길','hong22@bbb.bbb',NULL,'1',NULL,NULL,'2026-02-12 12:54:56.814497','SYSTEM','2026-02-12 12:54:56.814497','SYSTEM'),
	 (20,'테스트 제목','테스트 내용','발신자','sender@test.com',NULL,'수신자','receiver2@test.com',NULL,'1',NULL,NULL,'2026-02-12 14:52:28.90218','SYSTEM','2026-02-12 14:52:28.90218','SYSTEM');
INSERT INTO kids_own.tb_ca_m_eml_sndng (eml_sndng_sn,eml_ttl,eml_cn,sndpty_flnm,sndpty_eml_addr,otsd_eml_dmnd_id,rcvr_flnm,rcvr_eml_addr,rcvr_jbps_nm,sndng_rslt_cd,atch_file_id,dsptch_dt,reg_dt,rgtr_id,mdfcn_dt,mdfr_id) VALUES
	 (21,'테스트 제목','테스트 내용','발신자','sender@test.com',NULL,'수신자','receiver2@test.com',NULL,'1',NULL,NULL,'2026-02-19 16:02:10.456022','SYSTEM','2026-02-19 16:02:10.456022','SYSTEM'),
	 (22,'테스트 제목','테스트 내용','발신자','sender@test.com',NULL,'수신자','receiver2@test.com',NULL,'1',NULL,NULL,'2026-02-19 16:48:21.160515','SYSTEM','2026-02-19 16:48:21.160515','SYSTEM'),
	 (23,'테스트 제목','테스트 내용','발신자','sender@test.com',NULL,'수신자','receiver2@test.com',NULL,'1',NULL,NULL,'2026-02-20 15:39:45.828143','SYSTEM','2026-02-20 15:39:45.828143','SYSTEM');
