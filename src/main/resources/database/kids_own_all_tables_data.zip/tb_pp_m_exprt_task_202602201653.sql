INSERT INTO kids_own.tb_pp_m_exprt_task (exprt_task_sn,exprt_no,bzmn_task_mng_no,aprv_stts_cd,aprv_prcs_dt,rjct_rsn,wrtr_dept_nm,mdfr_dept_nm,rgtr_id,reg_dt,mdfr_id,mdfcn_dt) VALUES
	 (1,'police_drug_001','BZ26000001','A',NULL,NULL,'system','system','system','2026-02-04 14:05:37.340568','system','2026-02-04 14:05:37.340568'),
	 (2,'police_drug_002','BZ26000005','A',NULL,NULL,'system','system','system','2026-02-04 14:05:37.340568','system','2026-02-04 14:05:37.340568'),
	 (3,'police_drug_003','BZ26000007','A',NULL,NULL,'system','system','system','2026-02-04 14:05:37.340568','system','2026-02-04 14:05:37.340568');
