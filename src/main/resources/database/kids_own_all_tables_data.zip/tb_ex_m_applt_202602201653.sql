INSERT INTO kids_own.tb_ex_m_applt (entrst_sn,cnstn_mbcmt_sn,entrst_doc_no,entrst_cn,eml_hstry_sn,rgtr_id,reg_dt,mdfr_id,mdfcn_dt) VALUES
	 (1,9,'제 KARP-25-01','귀하를 한국의약품 안전관리원 제 6기 의약품 부작용 전문위원회 전문가단으로 위촉합니다',2,'admin','2026-02-11 08:03:00.985912','admin','2026-02-11 08:03:00.985912');
