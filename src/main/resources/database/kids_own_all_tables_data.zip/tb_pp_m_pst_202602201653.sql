INSERT INTO kids_own.tb_pp_m_pst (pst_sn,bbs_id,pst_ttl,pst_cn,pst_inq_cnt,pst_kogl_cprgt_type_cd,atch_file_group_id,thmb_id,fix_yn,fix_bgng_ymd,fix_end_ymd,vdo_url_addr,expsr_yn,wrtr_dept_nm,mdfr_dept_nm,rgtr_id,reg_dt,mdfr_id,mdfcn_dt) VALUES
	 (1,'1','테스트 게시물 1','<!DOCTYPE HTML>
<html lang="ko">
<head>
    <title>KIDS 관리자</title>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=2.0, minimum-scale=1.0, user-scalable=no">
    <meta name="keywords" content="">
    <meta name="decription" content="">
    <meta name="author" content="">
    <link rel="icon" type="image/x-icon" href="../img/kids.ico">
    
    <!-- js -->
    <script type="text/javascript" src="../js/jquery-3.7.1.min.js"></script>
    <script type="text/javascript" src="../js/jquery-ui.min.js"></script>
    <script type="text/javascript" src="../js/bootstrap.min.js"></script>
    <script type="text/javascript" src="../js/datepicker.js"></script>

    <!-- ui js -->
    <script type="text/javascript" src="../js/commonUI.js"></script>

    <!-- css -->
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" media="all">
    <link rel="stylesheet" type="text/css" href="../css/style.css">

</head>
<body>

    <div id="wrap">
        <!-- S T A R T :: header -->
        <div id="header">
            <div class="inner">
                <h1 class="logo">
                    <a href="javascript:void(0);">
                        <img src="../img/logo.png" alt="한국의약품안전관리원">
                        <span class="logo_text">통합관리시스템</span>
                    </a>
                </h1>
            </div>
            <!-- //inner -->
        </div>
        <!-- E N D :: header -->

        <!-- S T A R T :: container -->
        <div id="container" class="sub_container">
            <!-- aside :: s -->
            <div class="aside">
                <div class="aside_inner">
                    <div id="lnb">
                        <ul class="lnb_list">
                            <li><a href="javascript:void(0);">대국민 서비스 포털 관리</a>
                                <ul>
                                    <li><a href="javascript:void(0);">전체메뉴 </a>
                                        <ul>
                                            <li><a href="javascript:void(0);">메뉴1_1_1</a></li>
                                            <li><a href="javascript:void(0);">메뉴1_1_2</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="javascript:void(0);">회원 관리</a></li>
                                    <li><a href="javascript:void(0);">게시판 관리</a></li>
                                    <li><a href="javascript:void(0);">게시물 관리</a></li>
                                    <li><a href="javascript:void(0);">뉴스레터/설문 관리</a></li>
                                    <li><a href="javascript:void(0);">교육 관리</a></li>
                                    <li><a href="javascript:void(0);">사이트 관리</a></li>
                                    <li><a href="javascript:void(0);">원시자료관리</a></li>
                                    <li><a href="javascript:void(0);">충실도 정보관리</a></li>
                                    <li><a href="javascript:void(0);">접속기록 관리</a></li>
                                    <li><a href="javascript:void(0);">DUR 정보관리</a></li>
                                </ul>
                            </li>
                            <li><a href="javascript:void(0);">의약품 안전 통합 교육 플랫폼</a></li>
                            <li><a href="javascript:void(0);">의약품 안전 통합 상담시스템</a>
                                <ul>
                                    <li><a href="javascript:void(0);">LNB 메뉴3_1</a></li>
                                    <li><a href="javascript:void(0);">LNB 메뉴3_2</a></li>
                                    <li><a href="javascript:void(0);">LNB 메뉴4_3</a></li>
                                </ul>
                            </li>
                            <li><a href="javascript:void(0);">안전 정보 관리 업무 지원 시스템</a>
                                <ul>
                                    <li><a href="javascript:void(0);">LNB 메뉴4_1</a></li>
                                    <li><a href="javascript:void(0);">LNB 메뉴4_2</a></li>
                                    <li><a href="javascript:void(0);">LNB 메뉴4_3</a></li>
                                </ul>
                            </li>
                            <li><a href="javascript:void(0);">약물 부작용 포털 및 업무 지원 </a></li>
                            <li><a href="javascript:void(0);">지능형 의약품 안전정보 통합분석</a></li>
                            <li><a href="javascript:void(0);">전문가 관리 시스템</a></li>
                            <li><a href="javascript:void(0);">설문 시스템</a></li>
                            <li><a href="javascript:void(0);">전자문서고</a></li>
                        </ul>
                    </div>
                    <!-- //lnb -->
                </div>
                <!-- //aside_inner -->
            </div>
            <!-- aside :: e -->

            <!-- content_wrap :: s -->
            <div class="content_wrap">
                <div class="location">
                    <div class="page_path">
                        <h2 class="tit">타이틀</h2>
                    </div>
                    <div class="local">
                        <span class="home"><span class="blind">홈</span></span>
                        <span class="route">뎁스1</span>
                        <span class="current">뎁스2</span>
                    </div>
                </div>
                <div class="content">
                <!-- 내용시작 -->
                 
                    <div class="sub_path">
                        <h2 class="tit">게시물 보기</h2>
                    </div>
                    <div class="tbl_wrap">
                        <table class="tbl_view">
                            <caption>회원 상세 정보</caption>
                            <colgroup>
                                <col style="width:200px">
                                <col>
                                <col style="width:200px">
                                <col>
                            </colgroup>
                            <tbody>
                                <tr>
                                    <th scope="row">이름</th>
                                    <td>김*전</td>
                                    <th scope="row">이메일</th>
                                    <td>on***ay#drugsafe.or.kr</td>
                                </tr>
                                <tr>
                                    <th scope="row">아이디</th>
                                    <td>dr**free</td>
                                    <th scope="row">전화번호</th>
                                    <td>010/****/1111</td>
                                </tr>
                                <tr>
                                    <th scope="row">회원유형</th>
                                    <td>14세 미만 / 일반 / 전문가</td>
                                    <th scope="row">가입일자</th>
                                    <td>2025-10-10</td>
                                </tr>
                                <tr>
                                    <th scope="row">가입상태</th>
                                    <td>정상 / 탈회</td>
                                    <th scope="row">탈회일자</th>
                                    <td>2026-01-01</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>

                    <div class="sub_path">
                        <h2 class="tit">법정 대리인</h2>
                    </div>
                    <div class="tbl_wrap">
                        <table class="tbl_view">
                            <caption>대리인 정보</caption>
                            <colgroup>
                                <col style="width:200px">
                                <col>
                                <col style="width:200px">
                                <col>
                            </colgroup>
                            <tbody>
                                <tr>
                                    <th scope="row">대리인 이름</th>
                                    <td>김*수</td>
                                    <th scope="row">대리인 전화번호</th>
                                    <td>010/****/1112</td>
                                </tr>
                                <tr>
                                    <th scope="row">본인과의 관계</th>
                                    <td colspan="3">부</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>  
                    <!-- //tbl_wrap -->

                    <div class="sub_path">
                        <h2 class="tit">전문가 정보</h2>
                    </div>
                    <div class="tbl_wrap">
                        <table class="tbl_view">
                            <caption>전문가 정보</caption>
                            <colgroup>
                                <col style="width:200px">
                                <col>
                                <col style="width:200px">
                                <col>
                            </colgroup>
                            <tbody>
                                <tr>
                                    <th scope="row">소속기관</th>
                                    <td>서울대학교 병원 (110/10/12345)</td>
                                    <th scope="row">기관 이메일</th>
                                    <td>on***ay#snuh.org</td>
                                </tr>
                                <tr>
                                    <th scope="row">재직여부</th>
                                    <td>재직 / 퇴직</td>
                                    <th scope="row">승인상태</th>
                                    <td>대기 / 승인 / 반려</td>
                                </tr>
                                <tr>
                                    <th scope="row">신청일자</th>
                                    <td>2025-11-10</td>
                                    <th scope="row">처리일자</th>
                                    <td>-</td>
                                </tr>
                                <tr>
                                    <th scope="row">반려사유</th>
                                    <td colspan="3"></td> </tr>
                            </tbody>
                        </table>
                    </div>  
                    <!-- //tbl_wrap -->

                    <div class="btn_area btn_r">
                        <button type="button" class="btn_default type02 la">목록</button>
                        <button type="button" class="btn_outline type03 la">마스킹해제</button>
                        <button type="button" class="btn_outline type03 la">회원탈퇴</button>
                        <button type="button" class="btn_outline type03 la">전문가탈퇴</button>
                    </div>

                <!-- //내용시작 -->    
                </div>
                <!-- //content -->
            </div>
            <!-- content_wrap :: e -->
        </div>
        <!-- E N D :: container -->
    </div>
    <!--//wrap -->

</body>
</html>',0,'3',NULL,NULL,'Y','20260205','20260219','https://www.youtube.com','Y',NULL,'','','2026-02-05 16:09:05.436528','','2026-02-10 13:05:36.839587'),
	 (3,'1','테스트 게시물 3','테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트테스트',0,'3',NULL,NULL,'N',NULL,NULL,'https://www.youtube.com','Y',NULL,'','','2026-02-05 16:15:31.620451','','2026-02-05 16:18:13.12077'),
	 (6,'1','테스트 게시물 6','헐퀴',0,'4',NULL,NULL,'N',NULL,NULL,'','Y',NULL,'','','2026-02-05 16:27:25.532639','','2026-02-05 16:27:45.075572'),
	 (2,'1','테스트 게시물 2','<!DOCTYPE HTML>
<html lang="ko">
<head>
    <title>KIDS :: pub - component</title>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=2.0, minimum-scale=1.0, user-scalable=no">
    <meta name="keywords" content="">
    <meta name="decription" content="">
    <meta name="author" content="">
    <link rel="icon" type="image/x-icon" href="../img/kids.ico">
    
    <!-- js -->
    <script type="text/javascript" src="../js/jquery-3.7.1.min.js"></script>
    <script type="text/javascript" src="../js/jquery-ui.min.js"></script>
    <script type="text/javascript" src="../js/bootstrap.min.js"></script>
    
    <!-- datepicker,datetimepicker -->
    <script type="text/javascript" src="../js/datepicker.js"></script>
    <script type="text/javascript" src="../js/jquery.datetimepicker.full.min.js"></script>
    <link rel="stylesheet" href="../css/jquery.datetimepicker.min.css" />
    
    <!-- select2 -->
    <script type="text/javascript" src="../js/select2.min.js"></script>
    <link rel="stylesheet" type="text/css" href="../css/select2.min.css">
    
    <!-- ui js -->
    <script type="text/javascript" src="../js/commonUI.js"></script>
    
    <!-- css -->
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" media="all">
    <link rel="stylesheet" type="text/css" href="../css/style.css">

    <!-- pub용 -->
    <style>
        .wrap_guide{position: relative;width: 100%;padding:20px;background: #ebebeb;}
        .tit_01{position:relative; font-size:16px;margin:0 0 20px 0;padding:0 0 10px 0;font-weight: bold;}
        .tit_01:after {content:''''; display:block; position:absolute; left:0; bottom:0; width:242px; height:1px; background:#222;}
        .tit_02 {/* counter-increment: section; */position:relative;font-weight: bold;margin:20px 0 0 0;padding:0 0 5px 10px;}
        .tit_02:before {/* content:counter(section) ''. ''; */content:''-''; display:block; position:absolute; left:0; top:0; }
        .bundle{background: #fff; border:1px solid #cacaca;padding:20px;border-top-color: #6e6e6e;}
        .bundle ~ .bundle{margin-top:20px;}
        .ex{position: relative;margin:10px 0 20px 0;padding:20px;border:1px dotted #939393;}
        .note {position: relative; padding:10px 20px 10px 40px; margin-bottom: 10px; line-height:1.8em; background:#ebebeb;box-shadow: 0 1px 3px rgba(0, 0, 0, 0.12), 0 1px 2px rgba(0, 0, 0, 0.24);}
        .note::before{content:"!";display:block;position:absolute;left:10px;top:12px;width:20px;height:20px;text-align: center; background:#f1ae0f;border-radius: 20px;}
        .row .col,
        .row [class^="col_"]{background-color: rgba(39, 41, 43, 0.03); border: 1px solid rgba(39, 41, 43, 0.1);}
    </style>
</head>
<body>

    <div class="wrap_guide">

        <div class="bundle">
            <p class="tit_01">버튼</p>
            <p class="tit_02">타입</p>
            
            <button type="button" class="btn_default">btn_default</button>
            <button type="button" class="btn_default type02">btn_default type02</button>
            <button type="button" class="btn_default type03">btn_default type03</button>

            <br><br>

            <button type="button" class="btn_outline">btn_outline</button>
            <button type="button" class="btn_outline type02">btn_outline type02</button>
            <button type="button" class="btn_outline type03">btn_outline type03</button>

            <div class="ex">
                <button type="button" class="btn_default">등록</button>
                <button type="button" class="btn_default">저장</button>
                
                
                <button type="button" class="btn_default type02">검색</button>
                <button type="button" class="btn_default type02">목록</button>
                
                <button type="button" class="btn_outline type04">보기</button>
                <button type="button" class="btn_outline type04">파일첨부</button>
                
                <button type="button" class="btn_outline type02">닫기</button>

                <button type="button" class="btn_outline type03">수정</button>
                <button type="button" class="btn_outline type03">취소</button>
                <button type="button" class="btn_outline type03">삭제</button>

                <button type="button" class="btn_outline type03">마스킹해제</button>
                <button type="button" class="btn_outline type03">회원탈퇴</button>
                <button type="button" class="btn_outline type03">전문가탈퇴</button>
            </div>

            <p class="tit_02">size</p>
            <p class="note">.sm .la 클래스 추가</p>
            <button type="button" class="btn_default sm">small</button>
            <button type="button" class="btn_outline sm">small</button>
            <button type="button" class="btn_default la">large</button>
            <button type="button" class="btn_outline la">large</button>

            <br> <br> 
        </div>

        <!-- ------------------------------------------------------- -->

        <div class="bundle">
            <p class="tit_01">폼태그</p>

            <p class="tit_02">radio , checkbox</p>
            <label class="label_radio">
                <input type="radio" id="" name="" value="">
                <span>선택</span>
            </label>
            <label class="label_radio">
                <input type="radio" id="" name="" value="" checked>
                <span>선택</span>
            </label>
            <label class="label_radio">
                <input type="radio" id="" name="" value="" checked disabled>
                <span>checked disabled</span>
            </label>
            <label class="label_radio">
                <input type="radio" id="" name="" value="" disabled>
                <span>disabled</span>
            </label>
            <br><br>
            <label class="label_check">
                <input type="checkbox" id="" name="">
                <span>체크</span>
            </label>
            <label class="label_check">
                <input type="checkbox" id="" name="" checked>
                <span>체크</span>
            </label>
            <label class="label_check">
                <input type="checkbox" id="" name="" checked disabled>
                <span>checked disabled</span>
            </label>
            <label class="label_check">
                <input type="checkbox" id="" name="" disabled>
                <span>disabled</span>
            </label>

            <p class="tit_02">radio , checkbox 텍스트 없는경우</p>
            <label class="label_radio label_radio_hidden">
                <input type="radio" id="" name="" value="">
                <span>선택</span>
            </label>
            <label class="label_check label_check_hidden">
                <input type="checkbox" id="" name="">
                <span>체크</span>
            </label>
            
            <p class="tit_02">스위치</p>
            <label class="label_switch">
                <input type="checkbox" role="switch">
                <span>스위치</span>
            </label>

            <p class="tit_02">스위치 텍스트 없는경우</p>
            <label class="label_switch">
                <input type="checkbox" role="switch">
                <span class="blind">고정여부</span>
            </label>

            <p class="tit_02">input readonly</p>
            <div class="field_input">
                <input type="text" id="" name="" value="readonly" readonly>
            </div>

            <p class="tit_02">input disabled</p>
            <div class="field_input">
                <input type="text" id="" name=""value="disabled" disabled>
            </div>
            
            <p class="tit_02">input clearable (인풋값 입력시 x 버튼)</p>
            <div class="field_input">
                <input type="text" id="" name="" value="" class="clearable">
            </div>
            
            
            <p class="tit_02">input error</p>
            <p class="note">input .inp_error 클래스추가</p>
            <div class="field_input">
                <input type="text" id="" name="" value="" class="inp_error">
            </div>
            <div class="inp_msg">
                <p class="error">일치하지않습니다.</p>
            </div>

            <p class="tit_02">input success</p>
            <p class="note">input .inp_success 클래스추가</p>
            <div class="field_input">
                <input type="text" id="" name="" value="" class="inp_success">
            </div>
            <div class="inp_msg">
                <p class="success">확인되었습니다.</p>
            </div>


            <p class="tit_02">select2.js 싱글,멀티</p>
            <div class="field_select">
                <select id="" class="singleSelect">
                    <option value="KO">한국</option>
                    <option value="JP">일본</option>
                    <option value="US">미국</option>
                    <option value="EN">영국</option>
                </select>
            </div>		

            <br>
            
            <div class="field_select">
                <select id="" multiple="multiple" class="multipleSelect w100">
                    <option value="JAN">January</option>
                    <option value="FEB">February</option>
                    <option value="MAR">March</option>
                    <option value="APR">April</option>
                    <option value="MAY">May</option>
                    <option value="JUN">June</option>
                </select>
            </div>

            <p class="tit_02">파일첨부</p>
            
            <div class="file_upload">
                <button type="button" id="addFileInput" class="btn_outline type04 btn_add">파일 추가</button>
                <div class="file_row">
                    <div class="field_file">
                        <input type="file" name="">
                        <button type="button" class="btn_clear"><span>삭제</span></button>
                    </div>
                </div>
                <div id="fileDiv"></div>
            </div>
            <div class="file_guide">(100px * 100px)</div>


            <p class="tit_02">첨부파일 목록</p>
            <div class="file_item">
                <a href="#" class="file_name">2025년도 사우회 회장 및 운영위원 선정(응답)결과.pdf</a>
                <span class="size">(42.0KB)</span>
            </div>
            <div class="file_item">
                <a href="#" class="file_name">2025년도 사우회 회장 및 운영위원 선정(응답)결과 파일명이 길어길어기얼 너무길어길다길어기러기러기러기러기러기길어길어길어너무길어길다길어기러기러기러기러기러기길어길어길어너무길어길다길어기러기러기러기러기러기길어길어길어너무길어길다길어기러기러기러기러기러기길어길어길어.pdf</a>
                <span class="size">(42.0KB)</span>
            </div>
            <div class="file_item">
                <a href="#" class="file_name">2025년도 사우회 회장 및 운영위원 선정(응답)결과.pdf</a>
                <span class="size">(42.0KB)</span>
            </div>

            <p class="tit_02">Tags Input</p>
            <div class="sort_btn_list">
                <div class="sort_btn">
                    <span class="sort">메인 관리</span>
                    <button type="button" class="btn_delete"><span class="ico_delete"><span class="blind">삭제</span></span></button>
                </div>
                <div class="sort_btn">
                    <span class="sort">게시판 관리</span>
                    <button type="button" class="btn_delete"><span class="ico_delete"><span class="blind">삭제</span></span></button>
                </div>
                <div class="sort_btn">
                    <span class="sort">약관법령 관리</span>
                    <button type="button" class="btn_delete"><span class="ico_delete"><span class="blind">삭제</span></span></button>
                </div>
            </div>


            <p class="tit_02">Datepicker (/js/datepicker.js)</p>
            <div class="field_date">
                <input type="text" placeholder="YYYY-MM-DD" class="datepicker">
                <button type="button" class="btn_calendar"><span class="blind">달력</span></button>
            </div>

            <p class="tit_02">Datepicker 기간</p>
            <div class="field_period">
                <div class="field_date">
                    <input type="text" placeholder="시작날짜" class="datepicker">
                    <button type="button" class="btn_calendar"><span class="blind">달력</span></button>
                </div>
                <span class="symbol">~</span>
                <div class="field_date">
                    <input type="text" placeholder="종료날짜" class="datepicker">
                    <button type="button" class="btn_calendar"><span class="blind">달력</span></button>
                </div>
            </div>

            <p class="tit_02">Datepicker + 시간(Select)</p>
            <div class="field_period">
                <div class="field_date">
                    <input type="text" placeholder="YYYY-MM-DD" class="datepicker">
                    <button type="button" class="btn_calendar"><span class="blind">달력</span></button>
                    <div class="time_group">
                        <select class="select_time"><option>00</option></select>
                        <span class="time_sep">:</span>
                        <select class="select_time"><option>00</option></select>
                    </div>
                </div>
                <span class="symbol">~</span>
                <div class="field_date">
                    <input type="text" placeholder="YYYY-MM-DD" class="datepicker">
                    <button type="button" class="btn_calendar"><span class="blind">달력</span></button>
                    <div class="time_group">
                        <select class="select_time"><option>00</option></select>
                        <span class="time_sep">:</span>
                        <select class="select_time"><option>00</option></select>
                    </div>
                </div>
            </div>

            <p class="tit_02">timepicker 적용버전</p>
            <div class="field_period">
                <div class="field_date">
                    <input type="text" placeholder="YYYY-MM-DD" class="datepicker">
                    <button type="button" class="btn_calendar"><span class="blind">달력</span></button>
                    <div class="time_group">
                        <div class="field_time"><input type="text" class="timepicker" placeholder="시간 선택"></div>
                    </div>
                </div>
                <span class="symbol">~</span>
                <div class="field_date">
                    <input type="text" placeholder="YYYY-MM-DD" class="datepicker">
                    <button type="button" class="btn_calendar"><span class="blind">달력</span></button>
                    <div class="time_group">
                        <div class="field_time"><input type="text" class="timepicker" placeholder="시간 선택"></div>
                    </div>
                </div>
            </div>

            <p class="tit_02">통합형 datetimepicker</p>
            <div class="field_datetime">
                <input id="datetimepicker1" class="datetimepicker" type="text" placeholder="날짜선택">
                <span class="symbol">~</span>
                <input id="datetimepicker2" class="datetimepicker" type="text" placeholder="날짜선택">
            </div>


            <p class="tit_02">전화번호</p>
            <div class="field_tel">
                <div class="field_select">
                    <select name="" id="" title="전화번호 앞자리"></select>
                </div>
                <span class="hyphen">-</span>
                <div class="field_input">
                    <input type="text" id="" name="" value="" title="전화번호 중간자리">
                </div>
                <span class="hyphen">-</span>
                <div class="field_input">
                    <input type="text" id="" name="" value="" title="전화번호 끝자리">
                </div>
            </div>

            <p class="tit_02">이메일</p>
            <div class="field_email">
                <div class="field_input email_id">
                    <input type="text" id="" name="" value="" title="이메일아이디 입력">
                </div>
                <span class="at">@</span>
                <div class="field_input email_domain">
                    <input type="text" id="" name="" value="" title="도메인 입력">
                </div>
                <div class="field_select email_domain_sel">
                    <select id="" name="" class="domain" title="도메인 선택">
                        <option value=""></option>
                    </select>
                </div>
            </div>

            <p class="tit_02">textarea</p>
            <div class="field_textarea">
                <textarea name="" id=""></textarea>
            </div>
            <div class="byteInfo"><!-- 글자수 넘어가면 .limit 클래스 추가 -->
                <span class="current limit">1006</span> / <span class="maxByte">1000</span>자
            </div>

            
        </div>

        <!-- ------------------------------------------------------- -->

        <div class="bundle">
            <p class="tit_01">게시판 하단버튼</p>
            <p class="tit_02">오른쪽 정렬</p>
            <div class="ex">
                <div class="btn_area btn_r">
                    <button type="button" class="btn_default la">버튼</button>
                    <button type="button" class="btn_default la">버튼</button>
                </div>
            </div>
            
            <p class="tit_02">왼쪽 정렬</p>
            <div class="ex">
                <div class="btn_area btn_l">
                    <button type="button" class="btn_default la">버튼</button>
                    <button type="button" class="btn_default la">버튼</button>
                </div>
            </div>

            <p class="tit_02">가운데 정렬</p>
            <div class="ex">
                <div class="btn_area btn_c">
                    <button type="button" class="btn_default la">버튼</button>
                    <button type="button" class="btn_default la">버튼</button>
                </div>
            </div>

            <p class="tit_02">양쪽 정렬</p>
            <div class="ex">
                <div class="btn_area">
                    <div class="btn_l">
                        <button type="button" class="btn_default btn_type1 la">버튼</button>
                    </div>
                    <div class="btn_r">
                        <button type="button" class="btn_default la">버튼</button>
                    </div>
                </div>
            </div>
        </div>

    </div>

</body>
</html>',0,'3',NULL,NULL,'Y','20260201','20260228','https://www.youtube.com','Y',NULL,'','','2026-02-05 16:11:48.65163','','2026-02-10 13:04:17.126135');
