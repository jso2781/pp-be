INSERT INTO kids_own.tb_ex_e_opnn_ans (agnd_cnstn_mbcmt_sn,opnn_sn,opnn_ans_sn,cnstn_opnn_ans_cn,atch_file_id,rgtr_id,reg_dt,mdfr_id,mdfcn_dt) VALUES
	 (1,1,1,'안녕하세요 . 담당자입니다. 
의견에 대해 답변드립니다 . 
요청하신 사항은 KARP-24-D 장애 사항이 맞는걸로 파악됩니다.!!

감사합니다. ',NULL,'SYSTEM','2026-02-20 06:05:26.359697','SYSTEM','2026-02-20 06:05:31.944228'),
	 (1,1,2,'네 알겠습니다 . 의견주셔서 감사합니다. ',NULL,'SYSTEM','2026-02-20 06:06:42.149715','SYSTEM','2026-02-20 06:06:42.149715');
