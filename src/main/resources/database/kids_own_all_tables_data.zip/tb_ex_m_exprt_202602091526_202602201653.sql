INSERT INTO kids_own.tb_ex_m_exprt_202602091526 (exprt_sn,exprt_flnm,exprt_brdt,exprt_gndr_cd,up_ogdp_nm,lwr_ogdp_nm,cnstn_mbcmt_id,use_yn,encpt_cnstn_mbcmt_telno,cnstn_mbcmt_eml_nm,rgtr_id,reg_dt,mdfr_id,mdfcn_dt) VALUES
	 (1,'홍길동','19991027','01','의약품','KIDS',NULL,'Y','01012341234','1234','admin','2025-12-09 17:12:00.724','admin','2025-12-09 17:12:00.724');
