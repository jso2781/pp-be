INSERT INTO kids_own.tb_pp_m_dgstfn_exmn (dgstfn_exmn_sn,menu_sn,dgstfn_scr,rgtr_id,reg_dt,mdfr_id,mdfcn_dt) VALUES
	 (1,96,4,'test','2025-12-31 00:00:00','test','2025-12-31 00:00:00'),
	 (2,102,3,'test','2025-12-31 00:00:00','test','2025-12-31 00:00:00'),
	 (3,102,4,'test','2025-12-31 00:00:00','test','2025-12-31 00:00:00'),
	 (4,102,5,'test','2026-02-01 00:00:00','test','2026-02-01 00:00:00');
