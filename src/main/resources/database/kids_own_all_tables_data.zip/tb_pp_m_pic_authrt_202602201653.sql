INSERT INTO kids_own.tb_pp_m_pic_authrt (emp_no,authrt_cd,pic_authrt_rmrk_cn,rgtr_id,reg_dt,mdfr_id,mdfcn_dt) VALUES
	 ('A9999','0004_A00',NULL,'choi','2026-02-13 13:19:19.533756','choi','2026-02-13 13:19:19.533756'),
	 ('A9999','DR_A02',NULL,'admin','2026-02-19 13:36:31.2325','admin','2026-02-19 13:36:31.2325');
