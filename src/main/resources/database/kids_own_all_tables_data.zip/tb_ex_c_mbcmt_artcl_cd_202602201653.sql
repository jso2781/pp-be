INSERT INTO kids_own.tb_ex_c_mbcmt_artcl_cd (cmt_sn,add_artcl_cd_sn,artcl_nm_1,rmrk_cn_1,artcl_nm_2,rmrk_cn_2,artcl_nm_3,rmrk_cn_3,artcl_nm_4,rmrk_cn_4,artcl_nm_5,rmrk_cn_5,use_yn,rgtr_id,reg_dt,mdfr_id,mdfcn_dt) VALUES
	 (1,1,'인성','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Y','SYSTEM','2026-02-10 01:08:12.114653','SYSTEM','2026-02-10 01:08:12.114653');
