INSERT INTO kids_own.tb_pp_m_conts (conts_sn,conts_ver_no,conts_ttl,conts_cn,conts_use_yn,rgtr_id,reg_dt,mdfr_id,mdfcn_dt) VALUES
	 ('cms0002',1,'이상사례란?','                <section class="pageCont-dur-intro">
                  <div class="info-summary-box">
                    <h3 class="info-summary-box__title">DUR (Drug Utilization Review)이란?</h3>
                    <div class="info-summary-box__desc">
                      <p>
                        의약품 적정사용(Drug Utilization Review, 이하 DUR)은 <strong>의약품을 병용하거나 소아·노인·임부·수유부에게 투여 시 
                        주의해야 할 정보를 사전에 알리고, 정해진 기준에 따라 약물 사용이 적절하게 이뤄지는지 점검하고 평가하는 
                        제도</strong>입니다.
                      </p>
                      <p>
                        부적절한 약물 사용을 사전에 방지함으로써 <strong>부작용을 예방</strong>하고 환자에게 제공하는 <strong>의료서비스의 질을 향상</strong>시키며
                        의약품을 <strong>안전하게 사용</strong>할 수 있는 환경을 조성하는데 그 목적이 있습니다.
                      </p>
                    </div>
                  </div> 

                  <h3 class="section-title">DUR 정보 제공 흐름</h3>
                  <p class="section-desc">
                    현재 한국의약품안전관리원에서 개발한 DUR 정보는 식품의약품안전처 고시 및 공고 등의 형태로 전 국민에게 제공되고, 
                    건강보험심사평가원 DUR 전산시스템(의약품안전사용서비스)를 통해 의료현장에 제공됩니다.
                  </p>

                  <div class="img-switcher">
                    
                    <img 
                      src="/img/dur_intro_img01.png" 
                      alt="한국의약품안전관리원 개발 정보가 식약처 고시를 거쳐 심평원 DUR 시스템으로 의료현장에 제공되는 과정 (PC)" 
                      class="responsive-img pc-only"
                    />
                    
                    <img 
                      src="/img/dur_intro_img01_m.png" 
                      alt="한국의약품안전관리원 개발 정보가 식약처 고시를 거쳐 심평원 DUR 시스템으로 의료현장에 제공되는 과정 (모바일)" 
                      class="responsive-img mo-only"
                    />
                  </div>

                  <h3 class="section-title">DUR 정보 정의</h3>
                  <ul class="definition-list">
                    
                    <li class="definition-list__item">
                      <div class="definition-list__icon">
                        <img src="/img/ico_dur_01.png" alt="병용금기 성분 아이콘" />
                      </div>
                      <div class="definition-list__text">
                        <span class="definition-list__title">1. 병용금기 성분</span>
                        <span class="definition-list__desc">
                          <strong>두 가지 이상의 의약품</strong>을 함께 사용하는 경우, 치료 효과의 변화 또는 심각한 부작용 발생 등의 우려가 있어 동시에 사용하지 않아야 하는 유효성분의 조합
                        </span>
                      </div>
                    </li>

                    
                    <li class="definition-list__item">
                      <div class="definition-list__icon">
                        <img src="/img/ico_dur_02.png" alt="특정연령대 금기 성분 아이콘" />
                      </div>
                      <div class="definition-list__text">
                        <span class="definition-list__title">2. 특정연령대 금기 성분</span>
                        <span class="definition-list__desc">
                          소아, 노인 등 특정연령대의 환자가 사용함에 있어 안전성이 확보되지 않았거나 심각한 부작용 발생 등의 우려가 있어 사용하지 않아야 하는 유효성분
                        </span>
                      </div>
                    </li>

                    
                    <li class="definition-list__item">
                      <div class="definition-list__icon">
                        <img src="/img/ico_dur_03.png" alt="임부금기 성분 아이콘" />
                      </div>
                      <div class="definition-list__text">
                        <span class="definition-list__title">3. 임부금기 성분</span>
                        <span class="definition-list__desc">
                          태아에게 매우 심각한 위해성(태아기형 또는 태아독성 등)을 유발하거나 유발할 가능성이 높아 임부에게 사용하는 것이 권장되지 않는 유효성분
                        </span>
                      </div>
                    </li>

                    
                    <li class="definition-list__item">
                      <div class="definition-list__icon">
                        <img src="/img/ico_dur_04.png" alt="용량주의 성분 아이콘" />
                      </div>
                      <div class="definition-list__text">
                        <span class="definition-list__title">4. 용량주의 성분</span>
                        <span class="definition-list__desc">
                          성인에게 특정 용량 초과 시 효과의 증가는 기대하기 어렵고 용량의존적 부작용 발생 가능성이 높아져 1일 최대용량에 대한 주의가 필요한 유효성분
                        </span>
                      </div>
                    </li>

                    
                    <li class="definition-list__item">
                      <div class="definition-list__icon">
                        <img src="/img/ico_dur_05.png" alt="투여기간주의 성분 아이콘" />
                      </div>
                      <div class="definition-list__text">
                        <span class="definition-list__title">5. 투여기간주의 성분</span>
                        <span class="definition-list__desc">
                          특정 투여기간 초과 시 효과의 증가는 기대하기 어렵고 부작용 발생 가능성이 높아져 1회 최대 투여기간에 대한 주의가 필요한 유효성분
                        </span>
                      </div>
                    </li>

                    
                    <li class="definition-list__item">
                      <div class="definition-list__icon">
                        <img src="/img/ico_dur_06.png" alt="효능군중복주의 성분 아이콘" />
                      </div>
                      <div class="definition-list__text">
                        <span class="definition-list__title">6. 효능군중복주의 성분</span>
                        <span class="definition-list__desc">
                          약리기전이 동일하거나 유사한 효능군 내에서 중복 투여할 때 추가적인 효과의 증가는 기대하기 어렵고 부작용 발생 가능성이 높아져 주의가 필요한 유효성분
                        </span>
                      </div>
                    </li>

                    
                    <li class="definition-list__item">
                      <div class="definition-list__icon">
                        <img src="/img/ico_dur_07.png" alt="노인주의 성분 아이콘" />
                      </div>
                      <div class="definition-list__text">
                        <span class="definition-list__title">7. 노인주의 성분</span>
                        <span class="definition-list__desc">
                          노인에서 부작용 발생 빈도 증가 등의 우려가 있어 주의가 필요한 유효성분
                        </span>
                      </div>
                    </li>

                    
                    <li class="definition-list__item">
                      <div class="definition-list__icon">
                        <img src="/img/ico_dur_08.png" alt="수유부주의 성분 아이콘" />
                      </div>
                      <div class="definition-list__text">
                        <span class="definition-list__title">8. 수유부주의 성분</span>
                        <span class="definition-list__desc">
                          수유 중의 소아에게 부작용 발생 등의 우려가 있어 수유부에게 사용 시 주의가 필요한 유효성분
                        </span>
                      </div>
                    </li>

                    
                    <li class="definition-list__item">
                      <div class="definition-list__icon">
                        <img src="/img/ico_dur_09.png" alt="분할주의 의약품 아이콘" />
                      </div>
                      <div class="definition-list__text">
                        <span class="definition-list__title">9. 분할주의 의약품</span>
                        <span class="definition-list__desc">
                          단위의 제형을 분할하여 복용할 경우 약효를 기대하기 어려운 의약품
                        </span>
                      </div>
                    </li>
                  </ul>

                  <h3 class="section-title">DUR 정보 현황</h3>
                  <div class="base-table-container">
                    <div class="base-table-meta">
                      <p class="update-date">(2025.07.14 기준)</p>
                    </div>
                    
                    <div class="table-responsive">
                      <table class="base-table">
                        <caption class="sr-only">DUR 정보 유형별 건수 및 고시/공고 현황</caption>
                        <colgroup>
                          <col style={{ width: ''25%'' }} />
                          <col style={{ width: ''45%'' }} />
                          <col style={{ width: ''30%'' }} />
                        </colgroup>
                        <thead>
                          <tr>
                            <th scope="col" colspan=''2''>정보 유형</th>
                            <th scope="col">정보 건수</th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr>
                            <th scope="row" rowspan=''3''>금기성분 고시</th>
                            <td>병용금기 (2004년~)</td>
                            <td>1,450</td>
                          </tr>
                          <tr>
                            <td>특정연령대금기 (2004년~)</td>
                            <td>207</td>
                          </tr>
                          <tr>
                            <td>임부금기 (2008년~)</td>
                            <td>1,210</td>
                          </tr>

                          <tr>
                            <th scope="row" rowspan=''6''>주의성분 공고</th>
                            <td>효능군중복주의 (2013년~)</td>
                            <td>392</td>
                          </tr>
                          <tr>
                            <td>용량주의 (2014년~)</td>
                            <td>331</td>
                          </tr>
                          <tr>
                            <td>투여기간주의 (2014년~)</td>
                            <td>60</td>
                          </tr>
                          <tr>
                            <td>노인주의 (2015년~)</td>
                            <td>108</td>
                          </tr>
                          <tr>
                            <td>수유부주의 (2024년~)</td>
                            <td>180</td>
                          </tr>
                          <tr>
                            <td>분할주의 (2015년~)</td>
                            <td>2,262(품목기준)</td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>

                  <h3 class="section-title">의약품 적정사용 자료 개발 및 홍보</h3>
                  <div class="info-action-list">
                    <div class="info-action-item">
                      <div class="info-action-item__text-group">
                        <strong class="info-action-item__title">
                          <span class="info-action-item__tag">[전문가 대상]</span> 의약품 적정사용 정보집
                        </strong>
                        <p class="info-action-item__desc">
                          전문가를 위한 의약품 안전사용 정보집을 발간하고 의약품 처방 조제 시 참고자료로 활용하도록 하고 있습니다.
                        </p>
                      </div>
                      <div className="info-action__btn">
	                  	<button type="button" className="btn-link-html">바로가기</button>
	                  </div>
                    </div>

                    <div class="info-action-item">
                      <div class="info-action-item__text-group">
                        <strong class="info-action-item__title">
                          <span class="info-action-item__tag">[대국민 대상]</span> 의약품 안전사용 교육자료
                        </strong>
                        <p class="info-action-item__desc">
                          전문가뿐 아니라 대국민 대상으로 다양한 주제의 의약품 안전사용 교육자료를 개발 배포함으로써 안전한 의약품 사용문화 조성에 이바지하고 있습니다.
                        </p>
                      </div>
                    </div>
                  </div>
                </section> ','Y','system','2026-02-10 10:10:58.184832','system','2026-02-10 10:10:58.184832'),
	 ('cms0001',1,'DUR 이해','                <section class="pageCont-dur-intro">
                  <div class="info-summary-box">
                    <h3 class="info-summary-box__title">DUR (Drug Utilization Review)이란?</h3>
                    <div class="info-summary-box__desc">
                      <p>
                        의약품 적정사용(Drug Utilization Review, 이하 DUR)은 <strong>의약품을 병용하거나 소아·노인·임부·수유부에게 투여 시 
                        주의해야 할 정보를 사전에 알리고, 정해진 기준에 따라 약물 사용이 적절하게 이뤄지는지 점검하고 평가하는 
                        제도</strong>입니다.
                      </p>
                      <p>
                        부적절한 약물 사용을 사전에 방지함으로써 <strong>부작용을 예방</strong>하고 환자에게 제공하는 <strong>의료서비스의 질을 향상</strong>시키며
                        의약품을 <strong>안전하게 사용</strong>할 수 있는 환경을 조성하는데 그 목적이 있습니다.
                      </p>
                    </div>
                  </div> 

                  <h3 class="section-title">DUR 정보 제공 흐름</h3>
                  <p class="section-desc">
                    현재 한국의약품안전관리원에서 개발한 DUR 정보는 식품의약품안전처 고시 및 공고 등의 형태로 전 국민에게 제공되고, 
                    건강보험심사평가원 DUR 전산시스템(의약품안전사용서비스)를 통해 의료현장에 제공됩니다.
                  </p>

                  <div class="img-switcher">
                    
                    <img 
                      src="/img/dur_intro_img01.png" 
                      alt="한국의약품안전관리원 개발 정보가 식약처 고시를 거쳐 심평원 DUR 시스템으로 의료현장에 제공되는 과정 (PC)" 
                      class="responsive-img pc-only"
                    />
                    
                    <img 
                      src="/img/dur_intro_img01_m.png" 
                      alt="한국의약품안전관리원 개발 정보가 식약처 고시를 거쳐 심평원 DUR 시스템으로 의료현장에 제공되는 과정 (모바일)" 
                      class="responsive-img mo-only"
                    />
                  </div>

                  <h3 class="section-title">DUR 정보 정의</h3>
                  <ul class="definition-list">
                    
                    <li class="definition-list__item">
                      <div class="definition-list__icon">
                        <img src="/img/ico_dur_01.png" alt="병용금기 성분 아이콘" />
                      </div>
                      <div class="definition-list__text">
                        <span class="definition-list__title">1. 병용금기 성분</span>
                        <span class="definition-list__desc">
                          <strong>두 가지 이상의 의약품</strong>을 함께 사용하는 경우, 치료 효과의 변화 또는 심각한 부작용 발생 등의 우려가 있어 동시에 사용하지 않아야 하는 유효성분의 조합
                        </span>
                      </div>
                    </li>

                    
                    <li class="definition-list__item">
                      <div class="definition-list__icon">
                        <img src="/img/ico_dur_02.png" alt="특정연령대 금기 성분 아이콘" />
                      </div>
                      <div class="definition-list__text">
                        <span class="definition-list__title">2. 특정연령대 금기 성분</span>
                        <span class="definition-list__desc">
                          소아, 노인 등 특정연령대의 환자가 사용함에 있어 안전성이 확보되지 않았거나 심각한 부작용 발생 등의 우려가 있어 사용하지 않아야 하는 유효성분
                        </span>
                      </div>
                    </li>

                    
                    <li class="definition-list__item">
                      <div class="definition-list__icon">
                        <img src="/img/ico_dur_03.png" alt="임부금기 성분 아이콘" />
                      </div>
                      <div class="definition-list__text">
                        <span class="definition-list__title">3. 임부금기 성분</span>
                        <span class="definition-list__desc">
                          태아에게 매우 심각한 위해성(태아기형 또는 태아독성 등)을 유발하거나 유발할 가능성이 높아 임부에게 사용하는 것이 권장되지 않는 유효성분
                        </span>
                      </div>
                    </li>

                    
                    <li class="definition-list__item">
                      <div class="definition-list__icon">
                        <img src="/img/ico_dur_04.png" alt="용량주의 성분 아이콘" />
                      </div>
                      <div class="definition-list__text">
                        <span class="definition-list__title">4. 용량주의 성분</span>
                        <span class="definition-list__desc">
                          성인에게 특정 용량 초과 시 효과의 증가는 기대하기 어렵고 용량의존적 부작용 발생 가능성이 높아져 1일 최대용량에 대한 주의가 필요한 유효성분
                        </span>
                      </div>
                    </li>

                    
                    <li class="definition-list__item">
                      <div class="definition-list__icon">
                        <img src="/img/ico_dur_05.png" alt="투여기간주의 성분 아이콘" />
                      </div>
                      <div class="definition-list__text">
                        <span class="definition-list__title">5. 투여기간주의 성분</span>
                        <span class="definition-list__desc">
                          특정 투여기간 초과 시 효과의 증가는 기대하기 어렵고 부작용 발생 가능성이 높아져 1회 최대 투여기간에 대한 주의가 필요한 유효성분
                        </span>
                      </div>
                    </li>

                    
                    <li class="definition-list__item">
                      <div class="definition-list__icon">
                        <img src="/img/ico_dur_06.png" alt="효능군중복주의 성분 아이콘" />
                      </div>
                      <div class="definition-list__text">
                        <span class="definition-list__title">6. 효능군중복주의 성분</span>
                        <span class="definition-list__desc">
                          약리기전이 동일하거나 유사한 효능군 내에서 중복 투여할 때 추가적인 효과의 증가는 기대하기 어렵고 부작용 발생 가능성이 높아져 주의가 필요한 유효성분
                        </span>
                      </div>
                    </li>

                    
                    <li class="definition-list__item">
                      <div class="definition-list__icon">
                        <img src="/img/ico_dur_07.png" alt="노인주의 성분 아이콘" />
                      </div>
                      <div class="definition-list__text">
                        <span class="definition-list__title">7. 노인주의 성분</span>
                        <span class="definition-list__desc">
                          노인에서 부작용 발생 빈도 증가 등의 우려가 있어 주의가 필요한 유효성분
                        </span>
                      </div>
                    </li>

                    
                    <li class="definition-list__item">
                      <div class="definition-list__icon">
                        <img src="/img/ico_dur_08.png" alt="수유부주의 성분 아이콘" />
                      </div>
                      <div class="definition-list__text">
                        <span class="definition-list__title">8. 수유부주의 성분</span>
                        <span class="definition-list__desc">
                          수유 중의 소아에게 부작용 발생 등의 우려가 있어 수유부에게 사용 시 주의가 필요한 유효성분
                        </span>
                      </div>
                    </li>

                    
                    <li class="definition-list__item">
                      <div class="definition-list__icon">
                        <img src="/img/ico_dur_09.png" alt="분할주의 의약품 아이콘" />
                      </div>
                      <div class="definition-list__text">
                        <span class="definition-list__title">9. 분할주의 의약품</span>
                        <span class="definition-list__desc">
                          단위의 제형을 분할하여 복용할 경우 약효를 기대하기 어려운 의약품
                        </span>
                      </div>
                    </li>
                  </ul>

                  <h3 class="section-title">DUR 정보 현황</h3>
                  <div class="base-table-container">
                    <div class="base-table-meta">
                      <p class="update-date">(2025.07.14 기준)</p>
                    </div>
                    
                    <div class="table-responsive">
                      <table class="base-table">
                        <caption class="sr-only">DUR 정보 유형별 건수 및 고시/공고 현황</caption>
                        <colgroup>
                          <col style={{ width: ''25%'' }} />
                          <col style={{ width: ''45%'' }} />
                          <col style={{ width: ''30%'' }} />
                        </colgroup>
                        <thead>
                          <tr>
                            <th scope="col" colspan=''2''>정보 유형</th>
                            <th scope="col">정보 건수</th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr>
                            <th scope="row" rowspan=''3''>금기성분 고시</th>
                            <td>병용금기 (2004년~)</td>
                            <td>1,450</td>
                          </tr>
                          <tr>
                            <td>특정연령대금기 (2004년~)</td>
                            <td>207</td>
                          </tr>
                          <tr>
                            <td>임부금기 (2008년~)</td>
                            <td>1,210</td>
                          </tr>

                          <tr>
                            <th scope="row" rowspan=''6''>주의성분 공고</th>
                            <td>효능군중복주의 (2013년~)</td>
                            <td>392</td>
                          </tr>
                          <tr>
                            <td>용량주의 (2014년~)</td>
                            <td>331</td>
                          </tr>
                          <tr>
                            <td>투여기간주의 (2014년~)</td>
                            <td>60</td>
                          </tr>
                          <tr>
                            <td>노인주의 (2015년~)</td>
                            <td>108</td>
                          </tr>
                          <tr>
                            <td>수유부주의 (2024년~)</td>
                            <td>180</td>
                          </tr>
                          <tr>
                            <td>분할주의 (2015년~)</td>
                            <td>2,262(품목기준)</td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>

                  <h3 class="section-title">의약품 적정사용 자료 개발 및 홍보</h3>
                  <div class="info-action-list">
                    <div class="info-action-item">
                      <div class="info-action-item__text-group">
                        <strong class="info-action-item__title">
                          <span class="info-action-item__tag">[전문가 대상]</span> 의약품 적정사용 정보집
                        </strong>
                        <p class="info-action-item__desc">
                          전문가를 위한 의약품 안전사용 정보집을 발간하고 의약품 처방 조제 시 참고자료로 활용하도록 하고 있습니다.
                        </p>
                      </div>
                      <div className="info-action__btn">
	                  	<button type="button" className="btn-link-html">바로가기</button>
	                  </div>
                    </div>

                    <div class="info-action-item">
                      <div class="info-action-item__text-group">
                        <strong class="info-action-item__title">
                          <span class="info-action-item__tag">[대국민 대상]</span> 의약품 안전사용 교육자료
                        </strong>
                        <p class="info-action-item__desc">
                          전문가뿐 아니라 대국민 대상으로 다양한 주제의 의약품 안전사용 교육자료를 개발 배포함으로써 안전한 의약품 사용문화 조성에 이바지하고 있습니다.
                        </p>
                      </div>
                    </div>
                  </div>
                </section> ','Y','system','2026-02-10 10:12:38.358164','system','2026-02-10 10:12:38.358164'),
	 ('cms0013',1,'업무처리절차','				<section class="pageCont-TaskProgress">
                    <div class="info-summary-box">
                      <h3 class="info-summary-box__title">정보공개제도 란?</h3>
                      <div class="info-summary-box__desc">
                        <p>국가기관·지방자치단체 등 공공기관이 업무 수행 중 생산·접수하여 보유· 관리하는 정보를 국민에게 공개함으로써, <br/><span class="fw-700">국민의 알권리를 보장하고 더 많은 정보를 바탕으로 국정운영에 대한 참여를 유도</span>하기 위한 제도입니다.</p>
                      </div>
                    </div> 
                    
                    <div class="category-anchor-tabs">
                      <ul class="tabs-list" role="tablist">
                        <li class="tab-item" role="none">
                          <a href="#anchor-sec1" id="tab1" class="tab-link active" role="tab" aria-selected="true" aria-controls="anchor-sec1">사전협의</a>
                        </li>
                        <li class="tab-item" role="none">
                          <a href="#anchor-sec2" id="tab2" class="tab-link" role="tab" aria-selected="false" aria-controls="anchor-sec2">활용결과 등록</a>
                        </li>
                        <li class="tab-item" role="none">
                          <a href="#anchor-sec3" id="tab3" class="tab-link" role="tab" aria-selected="false" aria-controls="anchor-sec3">시스템 이용 문의</a>
                        </li>
                      </ul>
                    </div>
                    <div class="anchor-contents-area">
                      <section id="anchor-sec1" class="tab-section" role="tabpanel" tabIndex={0} aria-labelledby="tab1">
                        <div class="inner-box">
                          <h3 class="section-title">정보공개법의 제정·시행</h3>
                          <div class="section-desc">
                            <p>국민의 알권리를 확대하고 국정운영의 투명성을 높이기 위해 지난 ''96년 &lt;공공기관의 정보공개에 관한 법률&gt; 을 제정·공포하고, ''98년 1월 1일부터 시행하였습니다.</p>  
                          </div>
                          <h3 class="section-title">정보공개법의 최초 제정(1996.12)과 시행(1998.01)</h3>
                          <div class="section-desc">
                            <p>정보공개 대상기관 중 공공기관의 정의를 명확히 하고, 국민의 알권리 확대 및 행정의
                                투명성 제고를 위하여 공개로 분류된 정보는 국민의 청구가 없더라도 사전에 공개하도록 하는 등 현행 제도의 운영상 나타난 일부 미비점을 개선 · 보완하는 한편, 법적 간
                                결성 · 함축성과 조화를 이루는 범위에서, 어려운 용어를 쉬운 우리말로 풀어쓰고 복잡한 문장은 체계를 정리하여 간결하게 다듬음으로써 쉽게 읽고 잘 이해할 수 있도록
                                2020년 12월 22일 최종 개정하였습니다.</p>
                          </div>
                        </div>
                      </section>
                      <section id="anchor-sec2" class="tab-section" role="tabpanel" tabIndex={0} aria-labelledby="tab2">
                        <div class="inner-box">
                          <h3 class="section-title">청구인</h3>
                          <div class="claimant-list">
                            <dl>
                              <dt>모든 국민</dt>
                              <dd>모든 국민은 청구인 본인 또는 그 대리인을 통하여 공공기관에 정보공개를 청구할 수 있습니다.</dd>
                            </dl>
                            <dl>
                              <dt>법인·단체</dt>
                              <dd>법인과 단체의 경우 대표자의 명의로 공공기관에 정보공개를 청구할 수 있습니다.</dd>
                            </dl>
                            <dl>
                              <dt>외국인</dt>
                              <dd>국내에 일정한 주소를 두고 거주하거나, 학술·연구를 위하여 일시적으로 체류하는 자, 국내에 사무소를 두고 있는 법인 또는 단체에 한해 정보공개를 청구할 수 있습니다.</dd>
                            </dl>
                          </div>
                          <h3 class="section-title">청구가능정보</h3>
                          <div class="section-desc">
                            <p class="txt-type-2">공공기관이 직무상 작성 또는 취득하여 관리하고 있는 문서(전자문서 포함)· 도면 · 사진 · 필름 · 테이프 · 슬라이드 및 기타 이에 준하는 매체 등에 기록된 사항</p>
                            <dl class="list-definition">
                              <dt>공공기관의 기록물관리에 관한 법률상 기록물과의 관계</dt>
                              <dd>
                                <p> "공공기관이 업무와 관련하여 생산 또는 접수한 문서 · 도서 · 대장 · 카드 · 도면 · 시청각물 · 전자문서 등 모든 형태의 기록정보자료" 인 기록물은 모두 정보공개청구의 대상이 되는 정보에 해당합니다.</p>
                              </dd>
                            </dl>
                          </div>
                          <h3 class="section-title">사전정보공표</h3>
                          <div class="section-desc">
                            <p class="txt-type-2">사전정보공표는 국민들이 정보공개를 청구하기 전에 국민이 필요로 하는 정보를 선제적·능동적 공개하는 제도입니다.</p>
                            <dl class="list-definition">
                              <dt>사전정보 대상</dt>
                              <dd>
                                <p>비공개 대상 정보 외에 국민이 알아야 할 필요가 있는 모든 정보 (공공기관의 정보공개에 관한 법률 제7조 제1항 및 제2항)</p>
                                <ul class="list-bullet-3">
                                    <li>국민생활에 매우 큰 영향을 미치는 정책에 관한 정보</li>
                                    <li>국가의 시책으로 시행하는 공사(工事) 등 대규모 예산이 투입되는 사업에 관한 정보</li>
                                    <li>예산집행의 내용과 사업평가 결과 등 행정감시를 위하여 필요한 정보</li>
                                    <li>그 밖에 공공기관의 장이 정하는 정보</li>
                                </ul>
                              </dd>
                              <dt>사전정보공표 방법</dt>
                              <dd>각 기관 홈페이지를 통해 최신정보를 공개합니다. 정보공개시스템에서는 각 기관의 사전정보의 목록을 제공합니다.</dd>
                            </dl>
                          </div>
                        </div>
                      </section>
                      <section id="anchor-sec3" class="tab-section" role="tabpanel" tabIndex={0} aria-labelledby="tab3">
                        <div class="inner-box">
                          <h3 class="section-title">청구절차</h3>
                          <div class="img-switcher">
                            <img src="/img/taskProgress_img01.png" alt="청구절차 도식화" class="responsive-img pc-only"/>
                            <img src="/img/taskProgress_img01_m.png"  alt="" aria-hidden="true" class="responsive-img mo-only"/>
                          </div>
                          <div class="sr-only">
                            <p>정보목록검색 - 원문정보조회</p>
                            정보목록검색 -정보공개청구 -공개여부결정(10일) - 정보공개
                          </div>
                          <div class="mb5"></div>
                          <div class="tar">
                            <a 
                              href="https://nedrug.mfds.go.kr/CCCBA03F010/getReport" 
                              class="btn-link-blank-html"
                              target="_blank" 
                              rel="noopener noreferrer"
                              title="바로가기(새 창 열림)"
                            >
                              정보공개포털 바로가기
                              <span class="ico-link-blank" aria-hidden="true"></span>
                              <span class="sr-only">(새 창 열림)</span>
                            </a>
                          </div>
                          <h3 class="section-title">정보공개 청구</h3>
                          <div class="section-desc">
                            <p class="txt-type-2">청구인은 원하는 정보가 있을 경우 정보공개시스템 (www.open.go.kr)에서 원문을 조회하거나 이를 보유 · 관리 하는 공공기관에 정보공개 청구서를 기재하여 제출합니다.</p>
                            <dl class="list-definition mb5">
                              <dt>청구서 기재사항</dt>
                              <dd>
                                <ul class="list-bullet-3">
                                    <li>청구인의 이름 · 주민등록번호 및 주소 청구하는 정보의 내용, 정보형태, 공개방법 등</li>
                                    <li>청구인이 공공기관에 우편 · 팩스 또는  직접 출석하여 제출하거나 정보공개시스템(www.open.go.kr)을 통해 청구서를 제출할 수 있습니다.</li>
                                </ul>
                              </dd>
                            </dl>
                            <p class="txt-type-3">청구를 받은 공공기관은 정보공개처리대장에 기록하고 청구인에게 접수증을 교부하고, 접수부서는 이를 담당부서 또는 소관기관에 이송하게 됩니다.</p>
                          </div>
                          <h3 class="section-title">공개여부의 결정</h3>
                          <div class="section-desc">
                            <p class="txt-type-2">공공기관은 청구를 받은 날부터 "10일" 이내에 공개여부를 결정해야 하며, 부득이한 경우 10일의 범위내에서 연장할 수 있습니다.</p>
                            <dl class="list-definition mb5">
                              <dt>공공기관은 청구정보가 제3자와 관련이 있는 경우 제3자에게 통보하고 필요한 경우 그 의견을 청취하여 결정하게 됩니다.</dt>
                              <dd>
                                <ul class="list-bullet-3">
                                    <li>공개청구량이 과다하여 정상적인 업무수행에 현저한 지장을 초래할 우려가 있는 경우 정보의 사본 · 복제물을 먼저 열람하게 한 후 일정기간별로 교부하되 2개월 이내에 완료하여야 합니다.</li>
                                    <li>비공개정보와 공개정보가 혼합되어 분리가능한 경우 공개청구의 취지에 부합하는 범위내에서 부분공개가 가능합니다.</li>
                                </ul>
                              </dd>
                            </dl>
                          </div>
                          <h3 class="section-title">공개여부 결정의 통지</h3>
                          <div class="section-desc">
                            <dl class="list-definition mb5">
                              <dt>공공기관이 정보의 공개를 결정한 때에는 공개일시 · 공개장소 등을 명시하여 청구인에게 통지하되, 공개를 결정한 날로부터 "10일" 이내에 공개해야 합니다.</dt>
                              <dd>
                                <ul class="list-bullet-3">
                                    <li>공개청구량이 과다하여 정상적인 업무수행에 현저한 지장을 초래할 우려가 있는 경우 정보의 사본 · 복제물을 먼저 열람하게 한 후 일정기간별로 교부하되 2개월 이내에 완료하여야 합니다.</li>
                                    <li>비공개정보와 공개정보가 혼합되어 분리가능한 경우 공개청구의 취지에 부합하는 범위내에서 부분공개가 가능합니다.</li>
                                </ul>
                              </dd>
                            </dl>
                            <p class="txt-type-2">공공기관이 정보를 비공개로 결정한 때에는 비공개사유·불복방법 등을 명시하여 청구인에게 지체없이 문서로 통지하여야 합니다.</p>
                            <dl class="list-definition mb5">
                              <dt>정보공개 방법</dt>
                              <dd>
                                <ul class="list-bullet-3">
                                  <li>문서, 도면, 카드, 사진 등 : 열람 또는 사본의 교부</li>
                                  <li>필름, 녹음 · 녹화테이프 등 : 시청 또는 인화물 · 복제물 교부</li>
                                  <li>마이크로필름, 슬라이드 등 : 시청·열람 또는 사본 · 복제본의 교부</li>
                                  <li>전자적 형태로 보유·관리하는 정보 : 파일을 복제하여 정보통신망을 활용한 정보공개시스템으로 송부, 매체에 저장하여 제공, 열람·시청 또는 사본·출력물의 제공</li>
                                </ul>
                              </dd>
                            </dl>
                          </div>
                        </div>
                      </section>
                    </div>
                  </section>
','Y','system','2026-02-10 10:12:38.358164','system','2026-02-10 10:12:38.358164'),
	 ('cms0020',1,'콘텐츠 테스트1','ㅅㄷㄴㅅ','Y','test','2026-02-12 16:27:00.078449','test','2026-02-12 16:27:00.078449'),
	 ('cms0023',1,'콘텐츠 테스트2','test','Y','test','2026-02-12 16:43:25.462368','test','2026-02-12 16:43:25.462368'),
	 ('cms0024',1,'콘텐츠 테스트3','test11123145662342425343463453453456','Y','test','2026-02-12 16:48:28.068418','test','2026-02-12 16:48:28.068418'),
	 ('cms0025',1,'콘텐츠 테스트3','test11123145662342425343463453453456

조금 변경함','Y','test','2026-02-12 16:59:09.529579','test','2026-02-12 16:59:09.529579'),
	 ('cms0026',1,'콘텐츠 테스트2','testkk','Y','test','2026-02-12 17:05:35.557881','test','2026-02-12 17:05:35.557881'),
	 ('cms0027',1,'콘텐츠 테스트2','testkkfdddd','Y','test','2026-02-12 17:13:44.523787','test','2026-02-12 17:13:44.523787'),
	 ('cms0028',1,'콘텐츠 테스트2','testkkfdddddssafasdfasdfasdffdsafasdfsdfasdf','N','test','2026-02-12 17:28:04.376995','test','2026-02-12 17:29:11.958085');
INSERT INTO kids_own.tb_pp_m_conts (conts_sn,conts_ver_no,conts_ttl,conts_cn,conts_use_yn,rgtr_id,reg_dt,mdfr_id,mdfcn_dt) VALUES
	 ('cms0028',3,'콘텐츠 테스트2','3','Y','test','2026-02-12 17:29:28.372962','test','2026-02-12 17:29:28.372962'),
	 ('cms0028',2,'콘텐츠 테스트2','testkkfdddddssafasdfasdfasdffdsafasdfsdfasdfsd;lakfjasldkfjl','N','test','2026-02-12 17:29:11.958085','test','2026-02-12 17:29:28.372962'),
	 ('cms0029',1,'테스트1','테슽스트스트스스트스스트트르펫스','N','test','2026-02-12 17:30:56.374748','test','2026-02-12 17:31:08.678358'),
	 ('cms0029',3,'테스트1','테슽스트스트스스트스스트트르펫스나아아아아ㅏ3','Y','test','2026-02-12 17:31:18.321837','test','2026-02-12 17:31:18.321837'),
	 ('cms0029',4,'테스트1','테슽스트스트스스트스스트트르펫스나아아아아ㅏ3','Y','test','2026-02-12 17:34:20.270114','test','2026-02-12 17:34:20.270114'),
	 ('cms0029',2,'테스트1','테슽스트스트스스트스스트트르펫스나아아아아ㅏ2','N','test','2026-02-12 17:31:08.678358','test','2026-02-12 17:34:20.270114');
