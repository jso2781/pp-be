INSERT INTO kids_own.tb_ex_e_rlt_dept (cmt_sn,reltd_dept_sn,dept_cd,rgtr_id,reg_dt,mdfr_id,mdfcn_dt) VALUES
	 (1,1,'0000081','SYSTEM','2026-02-10 01:05:37.757529','SYSTEM','2026-02-10 01:05:37.757529'),
	 (1,2,'0000004','SYSTEM','2026-02-11 02:27:33.884569','SYSTEM','2026-02-11 02:27:33.884569');
