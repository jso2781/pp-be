INSERT INTO kids_own.tb_ex_m_cnstn (cmt_sn,cnstn_sn,subcm_sn,agnd_clsf_cd,agnd_nm,cnstn_expln,cnstn_prd_bgng_ymd,cnstn_prd_knd_ymd,indiv_prd_cfmtn_yn,gd_sndng_yn,sbmsn_yn,dlbr_cmptn_yn,cnfdoc_atnd_ymd,cnfdoc_plc_nm,cnfdoc_cnstn_cst,grd_no,cnfdoc_plntf_cst_amt,cnfdoc_page_cnt,rgtr_id,reg_dt,mdfr_id,mdfcn_dt) VALUES
	 (1,2,NULL,'CC','KARP-24-C (진료비) ','★ 의약품부작용 전문위원회 서면자문을 작성하여 주실 떄에는, 자문의견을 뒷받침 할 수 있는 관련근거(근거문헌 및 임상경과 등)를 함께 기술하여 주십시오.
부작용 인정 여부에 따라 A혹은 B의 내용에 대한 회신 부탁드립니다.','20260212','20270323','N','N','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'SYSTEM','2026-02-12 04:19:55.959527','SYSTEM','2026-02-19 07:45:25.425941'),
	 (1,3,NULL,'B','KARP-24-D (장애)','의약품부작용 전문위원회 서면자문을 작성하여 주실 떄에는, 자문의견을 뒷받침 할 수 있는 관련근거(근거문헌 및 임상경과 등)을 함께 기술하여 주십시오. 
부작용 인정 여부에 따라 A.혹은 B의 내용에 대한 회신 부탁드립니다. 
','20260219','20260424','N','N','Y',NULL,'20260219','의약품안전원',200000,'32',200000,22,'SYSTEM','2026-02-19 07:47:35.043166','SYSTEM','2026-02-19 08:45:10.619526');
