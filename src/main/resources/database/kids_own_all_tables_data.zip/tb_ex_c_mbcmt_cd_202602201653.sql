INSERT INTO kids_own.tb_ex_c_mbcmt_cd (cmt_sn,cnstn_mbcmt_cd_sn,cnstn_mbcmt_group_cd,cnstn_mbcmt_group_cd_nm,use_yn,rgtr_id,reg_dt,mdfr_id,mdfcn_dt) VALUES
	 (1,1,'EXA','계','Y','SYSTEM','2026-02-10 01:04:32.677538','SYSTEM','2026-02-10 01:04:32.677538'),
	 (1,2,'EXB','분과','Y','SYSTEM','2026-02-10 01:04:32.677538','SYSTEM','2026-02-10 01:04:32.677538'),
	 (1,3,'EXC','지역','Y','SYSTEM','2026-02-10 01:04:32.677538','SYSTEM','2026-02-10 01:04:32.677538'),
	 (1,4,'EXD','안건','Y','SYSTEM','2026-02-10 01:04:32.677538','SYSTEM','2026-02-10 01:04:32.677538');
