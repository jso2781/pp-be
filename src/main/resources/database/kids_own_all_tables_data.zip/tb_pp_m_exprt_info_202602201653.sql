INSERT INTO kids_own.tb_pp_m_exprt_info (exprt_no,brno,mbr_no,encpt_exprt_flnm,encpt_exprt_inst_eml_nm,exprt_hdof_yn,aprv_stts_cd,aprv_prcs_dt,rjct_rsn,atch_file_group_id,rgtr_id,reg_dt,mdfr_id,mdfcn_dt) VALUES
	 ('police_drug_001','123456789 ','psj','박성주',NULL,'Y','A','2026-02-04 14:08:50.813346',NULL,NULL,'psj','2026-02-04 14:08:50.813346','psj','2026-02-04 14:08:50.813346');
