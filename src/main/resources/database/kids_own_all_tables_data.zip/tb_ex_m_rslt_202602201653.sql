INSERT INTO kids_own.tb_ex_m_rslt (cnstn_rslt_sn,agnd_cnstn_mbcmt_sn,cnstn_sn,cnstn_wrt_sn,cnstn_sbmsn_se_cd,sbmsn_yn,cnstn_rslt_cycl,cnstn_last_yn,rgtr_id,reg_dt,mdfr_id,mdfcn_dt) VALUES
	 (2,1,3,36,'01','N',1,'Y','SYSTEM','2026-02-20 06:11:55.293523','SYSTEM','2026-02-20 06:48:39.530539'),
	 (1,1,3,28,'01','N',1,'Y','SYSTEM','2026-02-20 06:09:27.763619','SYSTEM','2026-02-20 06:49:31.777833');
